# Burmalda Optimization (Fabric, Minecraft 1.21.11)

- Мелкие предметы в руках (first/third person), GUI не трогается
- Тотем бессмертия: новая текстура
- Звук тотема заменён на `burmalda.ogg`
- Один раз применяет настройки FPS в options.txt (бэкап: options.txt.burmalda-backup)

## Свой звук
Замени файл `src/main/resources/assets/burmalda_optimization/sounds/burmalda.ogg`
(моно, OGG Vorbis):
`ffmpeg -i input.mp3 -ac 1 -c:a libvorbis burmalda.ogg`

## Сборка
GitHub Actions: workflow уже лежит в `.github/workflows/build.yml`.
Готовый jar — в `build/libs/` (берём без `-sources`).
