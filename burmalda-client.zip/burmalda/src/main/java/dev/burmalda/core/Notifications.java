package dev.burmalda.core;

import java.util.ArrayList;
import java.util.List;

public final class Notifications {
    private Notifications() {}
    public record N(String text, boolean on, long t) {}
    public static final List<N> LIST = new ArrayList<>();
    public static void push(String module, boolean on) {
        LIST.add(new N(module, on, System.currentTimeMillis()));
        while (LIST.size() > 6) LIST.remove(0);
    }
}
