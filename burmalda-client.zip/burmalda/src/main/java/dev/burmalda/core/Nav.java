package dev.burmalda.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.*;

/** A* pathfinder (walk / step up / drop up to 3 / diagonals, avoids fluids & hazards) + path follower. */
public final class Nav {
    private Nav() {}
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private static final class Node {
        final BlockPos pos; Node parent; double g, f, h; boolean closed;
        Node(BlockPos p) { pos = p; }
    }

    public static List<BlockPos> path = new ArrayList<>();
    public static boolean active, arrived, failed;
    public static Vec3d goal;
    public static boolean sprint = true;
    public static int effort = 3500;

    private static double range;
    private static boolean eye, travel, noLos;
    private static int idx, replans, maxReplans = 6, stuck, sinceCheck;
    private static Vec3d lastPos;

    // ---------- API ----------
    /** Walk until within `range` of the goal (eye distance with line of sight if los, else feet distance). */
    public static boolean goNear(Vec3d g, double r, boolean los) { return begin(g, r, los, false, false); }
    /** Like goNear(los) but only the eye distance matters (obstacles in the way get mined by the caller). */
    public static boolean goNearEye(Vec3d g, double r) { return begin(g, r, true, false, true); }
    /** Long-distance walk (horizontal distance, repeated partial paths). */
    public static boolean travel(Vec3d g, double r) { return begin(g, r, false, true, false); }
    public static void reset() { stop(); arrived = false; failed = false; }

    public static void stop() {
        if (active) release();
        active = false;
        path = new ArrayList<>();
    }

    private static boolean begin(Vec3d g, double r, boolean los, boolean trav, boolean nl) {
        stop();
        goal = g; range = r; eye = los; travel = trav; noLos = nl;
        replans = 0; maxReplans = trav ? 60 : 6; arrived = false; failed = false; lastPos = null; stuck = 0; sinceCheck = 0;
        if (reachedNow()) { arrived = true; return true; }
        return plan();
    }

    private static void release() {
        mc.options.forwardKey.setPressed(false);
        mc.options.sprintKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
    }

    // ---------- goal checks ----------
    private static boolean reachedNow() {
        ClientPlayerEntity p = mc.player;
        Vec3d pos = p.getPos();
        if (travel) return Math.hypot(pos.x - goal.x, pos.z - goal.z) <= range;
        if (eye) return p.getEyePos().distanceTo(goal) <= range && (noLos || Util.see(p.getEyePos(), goal));
        return pos.distanceTo(goal) <= range;
    }
    private static boolean reachedNode(BlockPos n) {
        if (travel) return Math.hypot(n.getX() + 0.5 - goal.x, n.getZ() + 0.5 - goal.z) <= range;
        if (eye) {
            Vec3d e = new Vec3d(n.getX() + 0.5, n.getY() + 1.62, n.getZ() + 0.5);
            return e.distanceTo(goal) <= range && (noLos || Util.see(e, goal));
        }
        return new Vec3d(n.getX() + 0.5, n.getY(), n.getZ() + 0.5).distanceTo(goal) <= range;
    }
    private static double h(BlockPos n) {
        double d = travel ? Math.hypot(n.getX() + 0.5 - goal.x, n.getZ() + 0.5 - goal.z)
                : new Vec3d(n.getX() + 0.5, n.getY() + (eye ? 1.62 : 0), n.getZ() + 0.5).distanceTo(goal);
        return Math.max(0, d - range);
    }

    // ---------- search ----------
    private static boolean plan() {
        BlockPos s = Util.feet();
        List<BlockPos> r = search(s);
        if (r == null) { active = false; failed = true; return false; }
        path = r;
        idx = path.size() > 1 ? 1 : path.size();
        active = true; stuck = 0; lastPos = null; sinceCheck = 0;
        return true;
    }

    private static List<BlockPos> search(BlockPos start) {
        PriorityQueue<Node> open = new PriorityQueue<>(Comparator.comparingDouble(n -> n.f));
        HashMap<Long, Node> seen = new HashMap<>();
        Node s = new Node(start);
        s.h = h(start); s.f = s.h * 1.3;
        open.add(s); seen.put(start.asLong(), s);
        Node best = s;
        int n = 0;
        while (!open.isEmpty() && n++ < effort) {
            Node cur = open.poll();
            if (cur.closed) continue;
            cur.closed = true;
            if (reachedNode(cur.pos)) return build(cur);
            if (cur.h < best.h) best = cur;
            expand(cur, open, seen);
        }
        if (best != s && best.h < s.h - 1.5) return build(best);
        return null;
    }

    private static List<BlockPos> build(Node n) {
        LinkedList<BlockPos> l = new LinkedList<>();
        for (Node c = n; c != null; c = c.parent) l.addFirst(c.pos);
        return new ArrayList<>(l);
    }

    private static void push(PriorityQueue<Node> open, HashMap<Long, Node> seen, Node cur, BlockPos pos, double cost) {
        if (lavaBeside(pos)) cost += 4;
        double g = cur.g + cost;
        Node ex = seen.get(pos.asLong());
        if (ex != null && ex.g <= g) return;
        Node nn = new Node(pos);
        nn.parent = cur; nn.g = g; nn.h = h(pos); nn.f = g + nn.h * 1.3;
        seen.put(pos.asLong(), nn);
        open.add(nn);
    }

    private static boolean lavaBeside(BlockPos p) {
        return Util.lava(p.east()) || Util.lava(p.west()) || Util.lava(p.north()) || Util.lava(p.south()) || Util.lava(p.down());
    }

    private static final int[][] D4 = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    private static final int[][] DD = {{1, 1}, {1, -1}, {-1, 1}, {-1, -1}};

    private static void expand(Node cur, PriorityQueue<Node> open, HashMap<Long, Node> seen) {
        BlockPos n = cur.pos;
        for (int[] d : D4) {
            BlockPos f = n.add(d[0], 0, d[1]);
            if (Util.standable(f)) { push(open, seen, cur, f, 1.0); continue; }
            BlockPos u = f.up();
            if (Util.free(n.up(2)) && Util.standable(u)) { push(open, seen, cur, u, 1.7); continue; }
            if (Util.loaded(f) && Util.free(f) && Util.free(f.up())) {
                for (int k = 1; k <= 3; k++) {
                    BlockPos l = f.down(k);
                    if (Util.standable(l)) { push(open, seen, cur, l, 1.0 + 0.6 * k); break; }
                    if (!Util.free(l)) break;
                }
            }
        }
        for (int[] d : DD) {
            BlockPos a = n.add(d[0], 0, 0), b = n.add(0, 0, d[1]);
            if (!Util.free(a) || !Util.free(a.up()) || !Util.free(b) || !Util.free(b.up())) continue;
            BlockPos f = n.add(d[0], 0, d[1]);
            if (Util.standable(f)) push(open, seen, cur, f, 1.45);
        }
    }

    // ---------- follower ----------
    public static void tick() {
        if (!active) return;
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) { active = false; return; }
        if (reachedNow()) { release(); active = false; arrived = true; path = new ArrayList<>(); return; }
        if (idx >= path.size()) { finishPath(); return; }

        sinceCheck++;
        if (sinceCheck >= 20) {
            sinceCheck = 0;
            if (lastPos != null && p.getPos().distanceTo(lastPos) < 0.3 && !p.isUsingItem()) stuck++; else stuck = 0;
            lastPos = p.getPos();
            if (stuck >= 2) { stuck = 0; if (!replan()) return; }
        }

        BlockPos next = path.get(idx);
        if (!Util.standable(next) && idx > 0 && !Util.free(next)) { if (!replan()) return; return; }
        double tx = next.getX() + 0.5, tz = next.getZ() + 0.5;
        double dx = tx - p.getX(), dz = tz - p.getZ(), hd = Math.hypot(dx, dz);
        boolean last = idx == path.size() - 1;
        if (hd < (last ? 0.25 : 0.5) && Math.abs(p.getY() - next.getY()) < 1.3) { idx++; return; }
        if (idx + 1 < path.size()) { // corner cutting
            BlockPos nn = path.get(idx + 1);
            double d2 = Math.hypot(nn.getX() + 0.5 - p.getX(), nn.getZ() + 0.5 - p.getZ());
            if (hd < 1.0 && d2 < hd && Math.abs(nn.getY() - p.getY()) < 1.3) { idx++; return; }
        }
        if (hd > 5.0) { if (!replan()) return; return; }

        float want = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90);
        float diff = MathHelper.wrapDegrees(want - p.getYaw());
        Util.turnYaw(want, 40f);
        boolean jump = p.isTouchingWater() || (p.isOnGround() && ((next.getY() > p.getY() + 0.1 && hd < 1.4) || p.horizontalCollision));
        mc.options.forwardKey.setPressed(Math.abs(diff) < 70);
        mc.options.sprintKey.setPressed(sprint && Math.abs(diff) < 20 && hd > 1.5 && p.getHungerManager().getFoodLevel() > 6);
        mc.options.jumpKey.setPressed(jump);
    }

    private static void finishPath() {
        release();
        if (reachedNow()) { active = false; arrived = true; return; }
        if (++replans <= maxReplans && plan()) return;
        active = false; failed = true;
    }
    private static boolean replan() {
        if (++replans > maxReplans || !plan()) { active = false; failed = true; release(); return false; }
        return true;
    }
}
