package dev.burmalda.core;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Digs a 1x2 tunnel into the neighbouring feet-cell N (flat, or one step up/down) and walks into it. */
public final class Digger {
    private Digger() {}
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public enum Status { WORKING, DONE, BLOCKED }
    public static String reason = "";

    public static Status advance(BlockPos N) {
        ClientPlayerEntity p = mc.player;
        BlockPos F = Util.feet();
        int dy = N.getY() - F.getY();
        Vec3d nc = new Vec3d(N.getX() + 0.5, N.getY(), N.getZ() + 0.5);
        if (Math.hypot(p.getX() - nc.x, p.getZ() - nc.z) < 0.4 && Math.abs(p.getY() - N.getY()) < 1.0) return Status.DONE;
        if (Math.abs(N.getX() - F.getX()) + Math.abs(N.getZ() - F.getZ()) > 1 || Math.abs(dy) > 1) { reason = "bad step"; return Status.BLOCKED; }

        List<BlockPos> clear = new ArrayList<>();
        if (dy > 0) clear.add(F.up(2));
        clear.add(N.up());
        clear.add(N);
        for (BlockPos c : clear) {
            BlockState s = Util.state(c);
            if (!s.getFluidState().isEmpty()) { reason = "liquid ahead"; return Status.BLOCKED; }
            if (Util.solid(c)) {
                if (!Util.canBreak(c)) { reason = "unbreakable block"; return Status.BLOCKED; }
                if (Util.hazardNear(c, true)) { reason = "lava/water behind block"; return Status.BLOCKED; }
                Util.selectBestTool(s);
                Util.mine(c);
                return Status.WORKING;
            }
        }
        if (!Util.safeLanding(N)) { reason = "cave / unsafe floor"; return Status.BLOCKED; }
        Util.turnYaw(Util.yawTo(nc), 45f);
        mc.options.forwardKey.setPressed(true);
        if (dy > 0 && p.isOnGround()) mc.options.jumpKey.setPressed(true);
        return Status.WORKING;
    }

    public static void release() {
        mc.options.forwardKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
    }
}
