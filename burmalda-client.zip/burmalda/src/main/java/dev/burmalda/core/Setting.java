package dev.burmalda.core;

public abstract class Setting<T> {
    public final String name;
    public T value;
    protected Setting(String name, T value) { this.name = name; this.value = value; }

    public static class Bool extends Setting<Boolean> {
        public Bool(String n, boolean d) { super(n, d); }
        public boolean get() { return value; }
    }

    public static class Num extends Setting<Double> {
        public final double min, max, step;
        public Num(String n, double d, double min, double max, double step) { super(n, d); this.min = min; this.max = max; this.step = step; }
        public double get() { return value; }
        public int i() { return (int) Math.round(value); }
        public void set(double v) {
            v = Math.round(v / step) * step;
            value = Math.max(min, Math.min(max, v));
        }
    }

    public static class Mode extends Setting<String> {
        public final String[] modes;
        public Mode(String n, String d, String... modes) { super(n, d); this.modes = modes; }
        public boolean is(String m) { return value.equals(m); }
        public void cycle(int dir) {
            int i = 0;
            for (int k = 0; k < modes.length; k++) if (modes[k].equals(value)) i = k;
            value = modes[(i + dir + modes.length) % modes.length];
        }
    }
}
