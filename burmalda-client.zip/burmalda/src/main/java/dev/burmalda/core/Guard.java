package dev.burmalda.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.text.Text;

/** Singleplayer-only protection: nothing works and the client disconnects if the world is not a local one. */
public final class Guard {
    private Guard() {}

    public static boolean allowed() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.isInSingleplayer();
    }

    public static void tick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || allowed()) return;
        for (Module m : ModuleManager.ALL) m.setEnabled(false);
        mc.world.disconnect();
        mc.disconnect(new DisconnectedScreen(new TitleScreen(), Text.literal("Burmalda Client"),
                Text.literal("Burmalda Client works in singleplayer only.")));
    }
}
