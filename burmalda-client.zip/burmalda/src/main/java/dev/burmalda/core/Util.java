package dev.burmalda.core;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.function.Predicate;

public final class Util {
    private Util() {}
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    // ---------- world ----------
    public static BlockState state(BlockPos p) { return mc.world.getBlockState(p); }
    public static boolean loaded(BlockPos p) { return mc.world.getChunkManager().isChunkLoaded(p.getX() >> 4, p.getZ() >> 4); }
    public static boolean solid(BlockPos p) { return !state(p).getCollisionShape(mc.world, p).isEmpty(); }

    public static boolean hazardBlock(BlockState s) {
        Block b = s.getBlock();
        return b == Blocks.FIRE || b == Blocks.SOUL_FIRE || b == Blocks.COBWEB || b == Blocks.SWEET_BERRY_BUSH
                || b == Blocks.POWDER_SNOW || b == Blocks.NETHER_PORTAL || b == Blocks.END_PORTAL || b == Blocks.WITHER_ROSE
                || b == Blocks.MAGMA_BLOCK || b == Blocks.CAMPFIRE || b == Blocks.SOUL_CAMPFIRE || b == Blocks.CACTUS;
    }
    /** A cell the player body can occupy: no collision, no fluid, no hazard. */
    public static boolean free(BlockPos p) {
        BlockState s = state(p);
        return s.getCollisionShape(mc.world, p).isEmpty() && s.getFluidState().isEmpty() && !hazardBlock(s);
    }
    public static boolean standable(BlockPos feet) {
        if (!loaded(feet)) return false;
        return free(feet) && free(feet.up()) && solid(feet.down()) && !hazardBlock(state(feet.down()));
    }
    public static BlockPos feet() {
        BlockPos b = mc.player.getBlockPos();
        return solid(b) ? b.up() : b;
    }
    public static boolean lava(BlockPos p) { return state(p).getFluidState().isIn(FluidTags.LAVA); }
    public static boolean water(BlockPos p) { return state(p).getFluidState().isIn(FluidTags.WATER); }

    /** Is there lava (or water if asked) in the block or any of its 6 neighbours? */
    public static boolean hazardNear(BlockPos p, boolean includeWater) {
        if (lava(p) || (includeWater && water(p))) return true;
        for (Direction d : Direction.values()) {
            BlockPos n = p.offset(d);
            if (lava(n) || (includeWater && water(n))) return true;
        }
        return false;
    }
    public static boolean canBreak(BlockPos p) {
        BlockState s = state(p);
        return !s.isAir() && s.getHardness(mc.world, p) >= 0 && !s.hasBlockEntity();
    }
    public static boolean safeLanding(BlockPos feet) {
        for (int k = 1; k <= 4; k++) {
            BlockPos c = feet.down(k);
            if (solid(c)) return !hazardBlock(state(c));
            if (!state(c).getFluidState().isEmpty()) return false;
        }
        return false;
    }

    public static BlockHitResult ray(Vec3d a, Vec3d b) {
        return mc.world.raycast(new RaycastContext(a, b, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, mc.player));
    }
    /** True if nothing blocks the view (the goal block itself is allowed to be the first thing hit). */
    public static boolean see(Vec3d from, Vec3d to) {
        BlockHitResult r = ray(from, to);
        return r.getType() == HitResult.Type.MISS || r.getBlockPos().equals(BlockPos.ofFloored(to));
    }

    // ---------- ores ----------
    public static boolean isOre(BlockState s) {
        return s.isIn(BlockTags.COAL_ORES) || s.isIn(BlockTags.IRON_ORES) || s.isIn(BlockTags.GOLD_ORES) || s.isIn(BlockTags.COPPER_ORES)
                || s.isIn(BlockTags.DIAMOND_ORES) || s.isIn(BlockTags.EMERALD_ORES) || s.isIn(BlockTags.LAPIS_ORES)
                || s.isIn(BlockTags.REDSTONE_ORES) || s.isOf(Blocks.ANCIENT_DEBRIS) || s.isOf(Blocks.NETHER_QUARTZ_ORE) || s.isOf(Blocks.NETHER_GOLD_ORE);
    }
    public static int oreColor(BlockState s) {
        if (s.isIn(BlockTags.DIAMOND_ORES)) return 0xFF3CE6FF;
        if (s.isIn(BlockTags.EMERALD_ORES)) return 0xFF3CFF6A;
        if (s.isIn(BlockTags.GOLD_ORES) || s.isOf(Blocks.NETHER_GOLD_ORE)) return 0xFFFFD83C;
        if (s.isIn(BlockTags.IRON_ORES)) return 0xFFE0C4A8;
        if (s.isIn(BlockTags.REDSTONE_ORES)) return 0xFFFF3C3C;
        if (s.isIn(BlockTags.LAPIS_ORES)) return 0xFF3C5CFF;
        if (s.isIn(BlockTags.COPPER_ORES)) return 0xFFFF8A3C;
        if (s.isOf(Blocks.ANCIENT_DEBRIS)) return 0xFFB5702E;
        if (s.isOf(Blocks.NETHER_QUARTZ_ORE)) return 0xFFF0F0F0;
        return 0xFF9A9AAA;
    }

    // ---------- look / interact ----------
    public static void lookAt(Vec3d t) {
        ClientPlayerEntity p = mc.player;
        Vec3d d = t.subtract(p.getEyePos());
        p.setYaw((float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90));
        p.setPitch((float) -Math.toDegrees(Math.atan2(d.y, Math.hypot(d.x, d.z))));
    }
    public static float yawTo(Vec3d t) {
        Vec3d d = t.subtract(mc.player.getPos());
        return (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90);
    }
    public static void turnYaw(float target, float maxStep) {
        ClientPlayerEntity p = mc.player;
        p.setYaw(p.getYaw() + MathHelper.clamp(MathHelper.wrapDegrees(target - p.getYaw()), -maxStep, maxStep));
    }
    public static boolean mine(BlockPos pos) {
        ClientPlayerEntity p = mc.player;
        Vec3d c = Vec3d.ofCenter(pos), e = p.getEyePos();
        lookAt(c);
        Direction side = Direction.getFacing(e.x - c.x, e.y - c.y, e.z - c.z);
        boolean r = mc.interactionManager.updateBlockBreakingProgress(pos, side);
        p.swingHand(Hand.MAIN_HAND);
        return r;
    }
    public static void useOnBlock(BlockPos pos, Direction side) {
        Vec3d hit = Vec3d.ofCenter(pos).add(side.getOffsetX() * 0.5, side.getOffsetY() * 0.5, side.getOffsetZ() * 0.5);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(hit, side, pos, false));
        mc.player.swingHand(Hand.MAIN_HAND);
    }
    public static void msg(String s) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("[Burmalda] " + s), false);
    }

    // ---------- inventory ----------
    public static int findHotbar(Predicate<ItemStack> f) {
        for (int i = 0; i < 9; i++) {
            ItemStack s = mc.player.getInventory().getStack(i);
            if (!s.isEmpty() && f.test(s)) return i;
        }
        return -1;
    }
    /** Returns hotbar index, or -1 (and starts moving the item from the inventory into the hotbar). */
    public static int ensureHotbar(Predicate<ItemStack> f) {
        int h = findHotbar(f);
        if (h >= 0) return h;
        ClientPlayerEntity p = mc.player;
        for (int i = 9; i < 36; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (!s.isEmpty() && f.test(s)) {
                int dest = 7;
                for (int k = 8; k >= 0; k--) if (p.getInventory().getStack(k).isEmpty()) { dest = k; break; }
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, i, dest, SlotActionType.SWAP, p);
                return -1;
            }
        }
        return -1;
    }
    public static boolean selectItem(Predicate<ItemStack> f) {
        int h = ensureHotbar(f);
        if (h < 0) return false;
        mc.player.getInventory().selectedSlot = h;
        return true;
    }
    /** Selects the fastest hotbar tool for the block. Returns false if the block needs a tool we don't have. */
    public static boolean selectBestTool(BlockState st) {
        var inv = mc.player.getInventory();
        int best = -1;
        float bs = 1.0f;
        for (int i = 0; i < 9; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isEmpty()) continue;
            if (s.isDamageable() && s.getMaxDamage() - s.getDamage() <= 3) continue;
            float sp = s.getMiningSpeedMultiplier(st);
            if (sp > bs) { bs = sp; best = i; }
        }
        if (best >= 0) inv.selectedSlot = best;
        return !st.isToolRequired() || inv.getMainHandStack().isSuitableFor(st);
    }
    public static boolean hasToolFor(BlockState st) {
        if (!st.isToolRequired()) return true;
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).isSuitableFor(st)) return true;
        return false;
    }
    public static int freeSlots() {
        int n = 0;
        for (int i = 0; i < 36; i++) if (mc.player.getInventory().getStack(i).isEmpty()) n++;
        return n;
    }
    /** playerScreenHandler slot id for a PlayerInventory index (0..35). */
    public static int screenSlot(int invIndex) { return invIndex < 9 ? 36 + invIndex : invIndex; }
}
