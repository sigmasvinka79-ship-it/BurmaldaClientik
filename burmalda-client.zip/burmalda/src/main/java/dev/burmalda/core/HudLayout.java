package dev.burmalda.core;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/** Draggable HUD elements: each element has a saved offset from its default position. */
public final class HudLayout {
    private HudLayout() {}
    public static boolean editing;
    private static final Map<String, int[]> OFF = new HashMap<>();
    private static final Map<String, int[]> BOUNDS = new LinkedHashMap<>();
    private static String drag;
    private static int gx, gy;

    public static int ox(String id) { int[] o = OFF.get(id); return o == null ? 0 : o[0]; }
    public static int oy(String id) { int[] o = OFF.get(id); return o == null ? 0 : o[1]; }
    public static void beginFrame() { BOUNDS.clear(); }
    public static void reg(String id, int x, int y, int w, int h) { BOUNDS.put(id, new int[]{x, y, w, h}); }
    public static Map<String, int[]> bounds() { return BOUNDS; }
    public static String dragging() { return drag; }

    public static boolean press(double mx, double my) {
        String hit = null;
        for (Map.Entry<String, int[]> e : BOUNDS.entrySet()) {
            int[] b = e.getValue();
            if (mx >= b[0] && mx < b[0] + b[2] && my >= b[1] && my < b[1] + b[3]) hit = e.getKey();
        }
        if (hit == null) return false;
        int[] b = BOUNDS.get(hit);
        drag = hit; gx = (int) mx - b[0]; gy = (int) my - b[1];
        return true;
    }
    public static void dragTo(double mx, double my) {
        if (drag == null) return;
        int[] b = BOUNDS.get(drag);
        if (b == null) return;
        int nx = (int) mx - gx, ny = (int) my - gy;
        int[] o = OFF.computeIfAbsent(drag, k -> new int[2]);
        o[0] += nx - b[0]; o[1] += ny - b[1];
        b[0] = nx; b[1] = ny;
    }
    public static void release() { drag = null; }
    public static void reset() { OFF.clear(); }

    public static void save() { for (Map.Entry<String, int[]> e : OFF.entrySet()) Config.put("hud." + e.getKey(), e.getValue()[0] + "," + e.getValue()[1]); }
    public static void load() {
        for (String k : Config.keys()) {
            if (!k.startsWith("hud.")) continue;
            try { String[] a = Config.get(k).split(","); OFF.put(k.substring(4), new int[]{Integer.parseInt(a[0]), Integer.parseInt(a[1])}); } catch (Exception ignored) {}
        }
    }
}
