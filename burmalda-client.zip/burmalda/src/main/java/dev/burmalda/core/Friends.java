package dev.burmalda.core;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.Set;
import java.util.TreeSet;

/** Players that combat modules never target. */
public final class Friends {
    private Friends() {}
    public static final Set<String> NAMES = new TreeSet<>();
    public static boolean is(Entity e) { return e instanceof PlayerEntity p && NAMES.contains(p.getName().getString().toLowerCase()); }
    public static void save() { Config.put("friends", String.join(";", NAMES)); }
    public static void load() {
        NAMES.clear();
        String s = Config.get("friends");
        if (s != null) for (String n : s.split(";")) if (!n.isBlank()) NAMES.add(n.toLowerCase());
    }
}
