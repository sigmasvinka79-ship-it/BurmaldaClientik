package dev.burmalda.core;

import dev.burmalda.modules.farm.Builder;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

import java.io.File;

/** Chat commands (prefix "."): .bind add/remove/list/clear, .toggle, .build, .panic, .help */
public final class Commands {
    private Commands() {}
    private static final MinecraftClient mc = MinecraftClient.getInstance();

    private static void say(String s) { if (mc.player != null) mc.player.sendMessage(Text.literal("§d[Burmalda]§r " + s), false); }

    static Integer parseKey(String s) {
        s = s.toLowerCase();
        String t = switch (s) {
            case "lshift", "shift" -> "left.shift"; case "rshift" -> "right.shift";
            case "lctrl", "ctrl" -> "left.control"; case "rctrl" -> "right.control";
            case "lalt", "alt" -> "left.alt"; case "ralt" -> "right.alt";
            case "caps" -> "caps.lock"; case "pageup" -> "page.up"; case "pagedown" -> "page.down"; case "esc" -> "escape";
            default -> s.startsWith("kp") && s.length() > 2 ? "keypad." + s.substring(2) : s;
        };
        try { return InputUtil.fromTranslationKey("key.keyboard." + t).getCode(); } catch (Exception e) { return null; }
    }
    private static String keyLabel(int code) {
        try { return InputUtil.fromKeyCode(code, 0).getLocalizedText().getString().toUpperCase(); } catch (Exception e) { return "K" + code; }
    }

    /** returns true if the message was a command and must not be sent to chat */
    public static boolean handle(String raw) {
        if (!raw.startsWith(".") || raw.length() < 2 || !Guard.allowed()) return false;
        String[] a = raw.substring(1).trim().split("\\s+");
        switch (a[0].toLowerCase()) {
            case "help", "h" -> {
                say("Команды:");
                say(".bind add <модуль> <клавиша>  — назначить бинд (пример: .bind add KillAura r)");
                say(".bind remove <модуль>  — убрать бинд;  .bind list;  .bind clear");
                say(".toggle <модуль> (или .t) — вкл/выкл;  .panic — выключить всё");
                say(".build list | load <файл> | start | stop — автопостройка");
                say(".friend add|remove|list <ник> — друзья (их не бьют)");
                say(".config save|load <имя> — пресеты;  .hud reset — сбросить позиции HUD");
            }
            case "bind", "b" -> bind(a);
            case "toggle", "t" -> {
                Module m = a.length > 1 ? ModuleManager.byName(a[1]) : null;
                if (m == null) say("Модуль не найден."); else { m.toggle(); say(m.name + (m.enabled ? " §aвключён" : " §cвыключен")); }
            }
            case "panic" -> { for (Module m : ModuleManager.ALL) m.setEnabled(false); Nav.stop(); say("Все модули выключены."); }
            case "build" -> build(a);
            case "config", "cfg" -> {
                if (a.length >= 3 && a[1].equalsIgnoreCase("save")) say(Config.preset(a[2], true) ? "Пресет «" + a[2] + "» сохранён." : "Не удалось сохранить.");
                else if (a.length >= 3 && a[1].equalsIgnoreCase("load")) say(Config.preset(a[2], false) ? "Пресет «" + a[2] + "» загружен." : "Пресет не найден.");
                else { Config.save(); say("Настройки сохранены."); }
            }
            case "friend", "f" -> friend(a);
            case "hud" -> { HudLayout.reset(); Config.save(); say("Позиции HUD сброшены."); }
            default -> { say("Неизвестная команда. Напиши .help"); }
        }
        return true;
    }

    private static void friend(String[] a) {
        String sub = a.length > 1 ? a[1].toLowerCase() : "";
        switch (sub) {
            case "add" -> { if (a.length > 2) { Friends.NAMES.add(a[2].toLowerCase()); Config.save(); say("Друг добавлен: " + a[2]); } else say(".friend add <ник>"); }
            case "remove", "del" -> { if (a.length > 2) { Friends.NAMES.remove(a[2].toLowerCase()); Config.save(); say("Друг удалён: " + a[2]); } else say(".friend remove <ник>"); }
            case "list" -> say(Friends.NAMES.isEmpty() ? "Друзей нет." : "Друзья: " + String.join(", ", Friends.NAMES));
            default -> say("Использование: .friend add|remove|list <ник>");
        }
    }

    private static void bind(String[] a) {
        String sub = a.length > 1 ? a[1].toLowerCase() : "";
        switch (sub) {
            case "add" -> {
                if (a.length < 4) { say("Использование: .bind add <модуль> <клавиша>"); return; }
                Module m = ModuleManager.byName(a[2]);
                if (m == null) { say("Модуль «" + a[2] + "» не найден."); return; }
                Integer k = parseKey(a[3]);
                if (k == null) { say("Неизвестная клавиша «" + a[3] + "». Примеры: r, x, f6, lshift, space."); return; }
                m.key = k; Config.save();
                say("Бинд " + m.name + " → §e" + keyLabel(k));
            }
            case "remove", "del", "rem" -> {
                Module m = a.length > 2 ? ModuleManager.byName(a[2]) : null;
                if (m == null) { say("Использование: .bind remove <модуль>"); return; }
                m.key = -1; Config.save();
                say("Бинд " + m.name + " удалён.");
            }
            case "list" -> {
                int n = 0;
                for (Module m : ModuleManager.ALL) if (m.key >= 0) { say(m.name + " → §e" + keyLabel(m.key)); n++; }
                if (n == 0) say("Биндов нет.");
            }
            case "clear" -> { for (Module m : ModuleManager.ALL) m.key = -1; Config.save(); say("Все бинды удалены."); }
            default -> say("Использование: .bind add|remove|list|clear");
        }
    }

    private static void build(String[] a) {
        String sub = a.length > 1 ? a[1].toLowerCase() : "";
        Builder b = ModuleManager.get(Builder.class);
        switch (sub) {
            case "list" -> {
                File[] fs = Builder.dir().listFiles((d, n) -> n.endsWith(".nbt"));
                if (fs == null || fs.length == 0) say("Папка схем пуста: " + Builder.dir().getAbsolutePath() + " (кладите туда .nbt)");
                else for (File f : fs) say("• " + f.getName());
            }
            case "load" -> {
                if (a.length < 3) { say("Использование: .build load <файл>"); return; }
                Builder.file = a[2]; b.plan.value = "File"; say("Схема выбрана: " + a[2] + ". Включите модуль Builder или .build start.");
            }
            case "start" -> { Builder.started = true; if (!b.enabled) b.setEnabled(true); else say("Строительство запущено."); }
            case "stop" -> { b.setEnabled(false); say("Строительство остановлено."); }
            default -> say("Использование: .build list|load <файл>|start|stop");
        }
    }
}
