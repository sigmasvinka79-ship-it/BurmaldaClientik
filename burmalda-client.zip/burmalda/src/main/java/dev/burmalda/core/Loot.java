package dev.burmalda.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;

import java.util.HashSet;
import java.util.Set;
import java.util.function.Predicate;

public final class Loot {
    private Loot() {}
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static final Set<Integer> ignored = new HashSet<>();
    private static ItemEntity chasing;
    private static int cd, clear;

    public static ItemEntity nearest(Predicate<ItemStack> f, double r) {
        ItemEntity best = null; double bd = r * r;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof ItemEntity it) || !it.isAlive() || ignored.contains(it.getId()) || !f.test(it.getStack())) continue;
            double d = mc.player.squaredDistanceTo(it);
            if (d < bd) { bd = d; best = it; }
        }
        return best;
    }

    /** Walks to the nearest wanted drop. Returns true while it is busy collecting. */
    public static boolean collect(Predicate<ItemStack> f, double r) {
        if (++clear > 600) { clear = 0; ignored.clear(); }
        ItemEntity it = nearest(f, r);
        if (it == null) { if (chasing != null) { Nav.stop(); chasing = null; } return false; }
        double hd = Math.hypot(it.getX() - mc.player.getX(), it.getZ() - mc.player.getZ());
        if (hd < 1.2 && Math.abs(it.getY() - mc.player.getY()) < 2.0) {
            Nav.stop();
            Util.turnYaw(Util.yawTo(it.getPos()), 60f);
            mc.options.forwardKey.setPressed(true);
            chasing = it;
            return true;
        }
        if (Nav.failed && chasing == it) { ignored.add(it.getId()); Nav.reset(); chasing = null; return false; }
        if (chasing != it || (!Nav.active && --cd <= 0)) {
            cd = 12;
            Nav.goNear(it.getPos(), 0.8, false);
            chasing = it;
            if (Nav.failed) { ignored.add(it.getId()); Nav.reset(); chasing = null; return false; }
        }
        return true;
    }
}
