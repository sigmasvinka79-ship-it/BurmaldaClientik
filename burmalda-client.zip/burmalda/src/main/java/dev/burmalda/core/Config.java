package dev.burmalda.core;

import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Properties;
import java.util.Set;

/** Saves/loads settings, keybinds, enabled state of visual modules, HUD layout, friends and presets. */
public final class Config {
    private Config() {}
    private static final Properties extra = new Properties();
    private static final Set<String> PERSIST = Set.of("HUD", "TargetHUD", "TargetESP", "Trails", "OreESP", "ESP", "CombatFX", "JumpCircles",
            "PathESP", "Interface", "Ambience", "Particles", "Trajectory", "SeeInvisible", "Performance");

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("burmalda.properties"); }
    public static String get(String k) { return extra.getProperty(k); }
    public static void put(String k, String v) { extra.setProperty(k, v); }
    public static Set<String> keys() { return extra.stringPropertyNames(); }

    public static void load() {
        try {
            if (!Files.exists(file())) return;
            Properties pr = new Properties();
            try (InputStream in = Files.newInputStream(file())) { pr.load(in); }
            for (Module m : ModuleManager.ALL) {
                String k = "m." + m.name + ".";
                if (PERSIST.contains(m.name) && pr.containsKey(k + "on")) m.enabled = Boolean.parseBoolean(pr.getProperty(k + "on"));
                if (pr.containsKey(k + "key")) m.key = Integer.parseInt(pr.getProperty(k + "key"));
                for (Setting<?> s : m.settings) {
                    String v = pr.getProperty(k + s.name);
                    if (v == null) continue;
                    try {
                        if (s instanceof Setting.Bool b) b.value = Boolean.parseBoolean(v);
                        else if (s instanceof Setting.Num n) n.set(Double.parseDouble(v));
                        else if (s instanceof Setting.Mode md) for (String o : md.modes) if (o.equals(v)) md.value = v;
                    } catch (Exception ignored) {}
                }
            }
            for (String key : pr.stringPropertyNames()) if (key.startsWith("x.")) extra.setProperty(key.substring(2), pr.getProperty(key));
            HudLayout.load();
            Friends.load();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public static void save() {
        try {
            HudLayout.save();
            Friends.save();
            Properties pr = new Properties();
            for (Module m : ModuleManager.ALL) {
                String k = "m." + m.name + ".";
                if (PERSIST.contains(m.name)) pr.setProperty(k + "on", String.valueOf(m.enabled));
                pr.setProperty(k + "key", String.valueOf(m.key));
                for (Setting<?> s : m.settings) pr.setProperty(k + s.name, String.valueOf(s.value));
            }
            for (String key : extra.stringPropertyNames()) pr.setProperty("x." + key, extra.getProperty(key));
            try (OutputStream out = Files.newOutputStream(file())) { pr.store(out, "Burmalda Client"); }
        } catch (Exception e) { e.printStackTrace(); }
    }

    /** Presets: save = copy current config to a named file, load = copy it back and apply. */
    public static boolean preset(String name, boolean save) {
        try {
            Path p = FabricLoader.getInstance().getConfigDir().resolve("burmalda_" + name.replaceAll("[^A-Za-z0-9_-]", "") + ".properties");
            if (save) { save(); Files.copy(file(), p, StandardCopyOption.REPLACE_EXISTING); return true; }
            if (!Files.exists(p)) return false;
            Files.copy(p, file(), StandardCopyOption.REPLACE_EXISTING);
            load();
            return true;
        } catch (Exception e) { return false; }
    }
}
