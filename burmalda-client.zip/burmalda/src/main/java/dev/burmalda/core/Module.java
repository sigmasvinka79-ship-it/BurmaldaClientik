package dev.burmalda.core;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public enum Category {
        COMBAT("Combat"), RENDER("Render"), PLAYER("Player"), WORLD("World"), FARM("Farm");
        public final String label;
        Category(String l) { label = l; }
    }

    protected static final MinecraftClient mc = MinecraftClient.getInstance();
    public final String name;
    public final Category category;
    public boolean enabled, expanded, wasDown;
    /** true for modules that steer the player (mining, farming...). Only one such module should drive movement. */
    public boolean controller;
    public int key = -1;
    public final List<Setting<?>> settings = new ArrayList<>();

    protected Module(String name, Category category) { this.name = name; this.category = category; }

    protected Setting.Bool bool(String n, boolean d) { var s = new Setting.Bool(n, d); settings.add(s); return s; }
    protected Setting.Num num(String n, double d, double min, double max, double step) { var s = new Setting.Num(n, d, min, max, step); settings.add(s); return s; }
    protected Setting.Mode mode(String n, String d, String... all) { var s = new Setting.Mode(n, d, all); settings.add(s); return s; }

    public void toggle() { setEnabled(!enabled); }
    public void setEnabled(boolean v) {
        if (v == enabled) return;
        if (v && !Guard.allowed()) return;
        enabled = v;
        if (v) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    public void onRender2D(DrawContext ctx) {}
    public void onRender3D(WorldRenderContext ctx) {}
}
