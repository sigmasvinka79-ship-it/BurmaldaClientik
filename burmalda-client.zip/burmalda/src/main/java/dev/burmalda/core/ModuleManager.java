package dev.burmalda.core;

import dev.burmalda.modules.combat.*;
import dev.burmalda.modules.farm.*;
import dev.burmalda.modules.player.*;
import dev.burmalda.modules.render.*;
import dev.burmalda.modules.world.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    public static final List<Module> ALL = new ArrayList<>();
    private ModuleManager() {}

    private static void add(Module m, String group) { m.group = group; ALL.add(m); }

    public static void init() {
        add(new KillAura(), "Attack"); add(new TriggerBot(), "Attack"); add(new AimAssist(), "Attack"); add(new AutoShoot(), "Attack"); add(new Criticals(), "Attack");
        add(new AutoWeapon(), "Defense"); add(new AutoTotem(), "Defense"); add(new AutoShield(), "Defense"); add(new AutoArmor(), "Defense");
        add(new AutoPot(), "Defense"); add(new Velocity(), "Defense");

        add(new Sprint(), "Basic"); add(new ElytraHelper(), "Basic"); add(new NoFall(), "Safety"); add(new Safety(), "Safety");

        add(new Hud(), "Interface"); add(new TargetHud(), "Interface"); add(new CombatFx(), "Interface");
        add(new Ambience(), "World"); add(new Particles(), "World"); add(new TargetEsp(), "World"); add(new Trails(), "World");
        add(new JumpCircles(), "World"); add(new OreEsp(), "World"); add(new Esp(), "World"); add(new PathEsp(), "World");
        add(new Trajectory(), "World"); add(new SeeInvisible(), "World");

        add(new AutoEat(), "Survival"); add(new AutoTool(), "Survival"); add(new AutoFish(), "Survival"); add(new AutoRepair(), "Survival"); add(new AutoEnchant(), "Survival");
        add(new AutoLoot(), "Inventory"); add(new AutoStore(), "Inventory");

        add(new AutoMine(), "Mining"); add(new Tunnel(), "Mining"); add(new StructureFinder(), "Navigation"); add(new Home(), "Navigation");

        add(new MobFarm(), "Mobs"); add(new AutoBreed(), "Mobs"); add(new AutoFarm(), "Crops"); add(new Builder(), "Crops");

        add(new Performance(), "Client"); add(new Interface(), "Client"); add(new Zoom(), "Tools"); add(new Fullbright(), "Tools");
        Config.load();
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> c) {
        for (Module m : ALL) if (c.isInstance(m)) return (T) m;
        return null;
    }
    public static List<Module> of(Module.Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : ALL) if (m.category == c) out.add(m);
        return out;
    }
    public static Module byName(String n) {
        String k = n.toLowerCase().replaceAll("[^a-z0-9]", "");
        for (Module m : ALL) if (m.name.toLowerCase().replaceAll("[^a-z0-9]", "").equals(k)) return m;
        return null;
    }
    public static boolean controllerActive() {
        for (Module m : ALL) if (m.enabled && m.controller) return true;
        return false;
    }

    private static void fail(Module m, Throwable t) {
        t.printStackTrace();
        m.enabled = false;
        try { m.onDisable(); } catch (Throwable ignored) {}
        Nav.stop();
        Util.msg(m.name + " отключён из-за ошибки: " + t.getClass().getSimpleName());
    }

    public static void tick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        Guard.tick();
        if (!Guard.allowed()) return;
        if (mc.currentScreen == null && mc.getWindow() != null) {
            for (Module m : ALL) {
                if (m.key < 0) continue;
                boolean down = InputUtil.isKeyPressed(mc.getWindow().getHandle(), m.key);
                if (down && !m.wasDown) m.toggle();
                m.wasDown = down;
            }
        }
        if (mc.player == null || mc.world == null) { Nav.stop(); return; }
        for (Module m : ALL) {
            if (!m.enabled) continue;
            if (m.controller && !(m instanceof AutoStore) && AutoStore.working) continue;
            try { m.onTick(); } catch (Throwable t) { fail(m, t); }
        }
        try { Nav.tick(); } catch (Throwable t) { t.printStackTrace(); Nav.stop(); }
    }

    public static void render2d(DrawContext ctx) {
        if (!Guard.allowed()) return;
        for (Module m : ALL) {
            if (!m.enabled) continue;
            try { m.onRender2D(ctx); } catch (Throwable t) { fail(m, t); }
        }
    }

    public static void render3d(WorldRenderContext ctx) {
        if (!Guard.allowed()) return;
        for (Module m : ALL) {
            if (!m.enabled) continue;
            try { m.onRender3D(ctx); } catch (Throwable t) { fail(m, t); }
        }
    }
}
