package dev.burmalda.core;

import dev.burmalda.modules.combat.*;
import dev.burmalda.modules.farm.*;
import dev.burmalda.modules.player.*;
import dev.burmalda.modules.render.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    public static final List<Module> ALL = new ArrayList<>();
    private ModuleManager() {}

    public static void init() {
        ALL.add(new KillAura());
        ALL.add(new AutoWeapon());
        ALL.add(new AutoTotem());
        ALL.add(new Hud());
        ALL.add(new TargetHud());
        ALL.add(new TargetEsp());
        ALL.add(new Trails());
        ALL.add(new AutoEat());
        ALL.add(new AutoFish());
        ALL.add(new MobFarm());
        ALL.add(new StructureFinder());
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> c) {
        for (Module m : ALL) if (c.isInstance(m)) return (T) m;
        return null;
    }

    public static List<Module> of(Module.Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : ALL) if (m.category == c) out.add(m);
        return out;
    }

    public static void tick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        Guard.tick();
        if (!Guard.allowed()) return;
        if (mc.currentScreen == null && mc.getWindow() != null) {
            for (Module m : ALL) {
                if (m.key < 0) continue;
                boolean down = InputUtil.isKeyPressed(mc.getWindow().getHandle(), m.key);
                if (down && !m.wasDown) m.toggle();
                m.wasDown = down;
            }
        }
        if (mc.player == null || mc.world == null) return;
        for (Module m : ALL) if (m.enabled) m.onTick();
    }

    public static void render2d(DrawContext ctx) {
        if (!Guard.allowed()) return;
        for (Module m : ALL) if (m.enabled) m.onRender2D(ctx);
    }

    public static void render3d(WorldRenderContext ctx) {
        if (!Guard.allowed()) return;
        for (Module m : ALL) if (m.enabled) m.onRender3D(ctx);
    }
}
