package dev.burmalda.core;

import dev.burmalda.modules.combat.*;
import dev.burmalda.modules.farm.*;
import dev.burmalda.modules.player.*;
import dev.burmalda.modules.render.*;
import dev.burmalda.modules.world.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    public static final List<Module> ALL = new ArrayList<>();
    private ModuleManager() {}

    public static void init() {
        // combat
        ALL.add(new KillAura()); ALL.add(new AutoWeapon()); ALL.add(new AutoTotem()); ALL.add(new AutoShoot());
        ALL.add(new TriggerBot()); ALL.add(new AimAssist()); ALL.add(new AutoShield()); ALL.add(new AutoArmor()); ALL.add(new AutoPot());
        // render
        ALL.add(new Hud()); ALL.add(new TargetHud()); ALL.add(new TargetEsp()); ALL.add(new Trails());
        ALL.add(new OreEsp()); ALL.add(new Esp()); ALL.add(new CombatFx()); ALL.add(new JumpCircles());
        ALL.add(new PathEsp()); ALL.add(new Fullbright()); ALL.add(new Zoom()); ALL.add(new Interface());
        // player
        ALL.add(new AutoEat()); ALL.add(new Sprint()); ALL.add(new NoFall()); ALL.add(new AutoFish()); ALL.add(new AutoLoot()); ALL.add(new AutoStore());
        ALL.add(new AutoTool()); ALL.add(new Safety()); ALL.add(new AutoEnchant()); ALL.add(new AutoRepair());
        // world
        ALL.add(new AutoMine()); ALL.add(new Tunnel()); ALL.add(new StructureFinder()); ALL.add(new Home());
        // farm
        ALL.add(new MobFarm()); ALL.add(new AutoFarm()); ALL.add(new AutoBreed()); ALL.add(new Builder());
        Config.load();
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T get(Class<T> c) {
        for (Module m : ALL) if (c.isInstance(m)) return (T) m;
        return null;
    }
    public static List<Module> of(Module.Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : ALL) if (m.category == c) out.add(m);
        return out;
    }
    public static Module byName(String n) {
        String k = n.toLowerCase().replaceAll("[^a-z0-9]", "");
        for (Module m : ALL) if (m.name.toLowerCase().replaceAll("[^a-z0-9]", "").equals(k)) return m;
        return null;
    }
    public static boolean controllerActive() {
        for (Module m : ALL) if (m.enabled && m.controller) return true;
        return false;
    }

    private static void fail(Module m, Throwable t) {
        t.printStackTrace();
        m.enabled = false;
        try { m.onDisable(); } catch (Throwable ignored) {}
        Nav.stop();
        Util.msg(m.name + " was disabled after an error: " + t.getClass().getSimpleName());
    }

    public static void tick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        Guard.tick();
        if (!Guard.allowed()) return;
        if (mc.currentScreen == null && mc.getWindow() != null) {
            for (Module m : ALL) {
                if (m.key < 0) continue;
                boolean down = InputUtil.isKeyPressed(mc.getWindow().getHandle(), m.key);
                if (down && !m.wasDown) m.toggle();
                m.wasDown = down;
            }
        }
        if (mc.player == null || mc.world == null) { Nav.stop(); return; }
        for (Module m : ALL) {
            if (!m.enabled) continue;
            if (m.controller && !(m instanceof AutoStore) && AutoStore.working) continue;
            try { m.onTick(); } catch (Throwable t) { fail(m, t); }
        }
        try { Nav.tick(); } catch (Throwable t) { t.printStackTrace(); Nav.stop(); }
    }

    public static void render2d(DrawContext ctx) {
        if (!Guard.allowed()) return;
        for (Module m : ALL) {
            if (!m.enabled) continue;
            try { m.onRender2D(ctx); } catch (Throwable t) { fail(m, t); }
        }
    }

    public static void render3d(WorldRenderContext ctx) {
        if (!Guard.allowed()) return;
        for (Module m : ALL) {
            if (!m.enabled) continue;
            try { m.onRender3D(ctx); } catch (Throwable t) { fail(m, t); }
        }
    }
}
