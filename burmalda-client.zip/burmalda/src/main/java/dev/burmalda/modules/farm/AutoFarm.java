package dev.burmalda.modules.farm;

import dev.burmalda.core.Loot;
import dev.burmalda.core.Module;
import dev.burmalda.core.Nav;
import dev.burmalda.core.Setting;
import dev.burmalda.core.Util;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CropBlock;
import net.minecraft.block.NetherWartBlock;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.Set;

/** Harvests ripe crops (wheat, carrots, potatoes, beetroot, nether wart, sugar cane, melons, pumpkins), replants and collects drops. */
public class AutoFarm extends Module {
    final Setting.Mode crop = mode("Crop", "All", "All", "Wheat", "Carrots", "Potatoes", "Beetroot", "Nether wart", "Sugar cane", "Melon/Pumpkin");
    final Setting.Num radius = num("Radius", 12, 4, 24, 1);
    final Setting.Bool replant = bool("Replant", true);
    final Setting.Bool pickup = bool("Pick up drops", true);

    private BlockPos target, plant;
    private Item seed, plantItem;
    private final Set<BlockPos> bad = new HashSet<>();
    private int scanCd, navCd, tries;

    public AutoFarm() { super("AutoFarm", Category.FARM); controller = true; }

    @Override public void onEnable() { target = null; plant = null; bad.clear(); Nav.reset(); }
    @Override public void onDisable() { Nav.stop(); }

    private boolean cropOk(Block b) {
        return switch (crop.value) {
            case "All" -> true;
            case "Wheat" -> b == Blocks.WHEAT;
            case "Carrots" -> b == Blocks.CARROTS;
            case "Potatoes" -> b == Blocks.POTATOES;
            case "Beetroot" -> b == Blocks.BEETROOTS;
            case "Nether wart" -> b == Blocks.NETHER_WART;
            case "Sugar cane" -> b == Blocks.SUGAR_CANE;
            default -> b == Blocks.MELON || b == Blocks.PUMPKIN;
        };
    }
    private boolean ready(BlockPos pos, BlockState s) {
        Block b = s.getBlock();
        if (!cropOk(b)) return false;
        if (b instanceof CropBlock cb) return cb.isMature(s);
        if (b == Blocks.NETHER_WART) return s.get(NetherWartBlock.AGE) >= 3;
        if (b == Blocks.SUGAR_CANE) return Util.state(pos.down()).isOf(Blocks.SUGAR_CANE);
        return b == Blocks.MELON || b == Blocks.PUMPKIN;
    }
    private static Item seedFor(Block b) {
        if (b == Blocks.WHEAT) return Items.WHEAT_SEEDS;
        if (b == Blocks.CARROTS) return Items.CARROT;
        if (b == Blocks.POTATOES) return Items.POTATO;
        if (b == Blocks.BEETROOTS) return Items.BEETROOT_SEEDS;
        if (b == Blocks.NETHER_WART) return Items.NETHER_WART;
        return null;
    }

    private BlockPos find() {
        BlockPos c = mc.player.getBlockPos();
        int r = radius.i();
        Vec3d eye = mc.player.getEyePos();
        BlockPos best = null; double bd = 1e18;
        for (BlockPos pos : BlockPos.iterate(c.add(-r, -3, -r), c.add(r, 3, r))) {
            BlockState s = mc.world.getBlockState(pos);
            if (s.isAir() || bad.contains(pos) || !ready(pos, s)) continue;
            double d = Vec3d.ofCenter(pos).squaredDistanceTo(eye);
            if (d < bd) { bd = d; best = pos.toImmutable(); }
        }
        return best;
    }

    @Override
    public void onTick() {
        var p = mc.player;
        mc.options.forwardKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);

        if (plant != null) { doPlant(); return; }

        if (target != null && !ready(target, Util.state(target))) {
            BlockPos floor = target.down();
            boolean farmland = Util.state(floor).isOf(Blocks.FARMLAND) || Util.state(floor).isOf(Blocks.SOUL_SAND);
            if (replant.get() && seed != null && Util.state(target).isAir() && farmland) { plant = target; plantItem = seed; tries = 0; }
            target = null; seed = null; Nav.reset();
            if (plant != null) return;
        }
        if (target == null) {
            if (pickup.get() && Loot.collect(s -> true, 7)) return;
            if (scanCd-- > 0) return;
            scanCd = 10;
            target = find();
            if (target != null) seed = seedFor(Util.state(target).getBlock());
            Nav.reset();
            if (target == null) return;
        }

        Vec3d c = Vec3d.ofCenter(target);
        if (p.getEyePos().distanceTo(c) <= 4.2) {
            Nav.stop();
            Util.selectBestTool(Util.state(target));
            Util.mine(target);
            return;
        }
        if (Nav.active) return;
        if (Nav.failed) { bad.add(target); target = null; Nav.reset(); return; }
        if (navCd-- <= 0) { navCd = 10; Nav.goNear(c, 3.6, false); if (Nav.failed) { bad.add(target); target = null; Nav.reset(); } }
    }

    private void doPlant() {
        var p = mc.player;
        if (!Util.state(plant).isAir()) { plant = null; return; }
        Vec3d c = Vec3d.ofCenter(plant);
        if (p.getEyePos().distanceTo(c) > 4.2) {
            if (Nav.failed) { plant = null; Nav.reset(); return; }
            if (!Nav.active) Nav.goNear(c, 3.6, false);
            return;
        }
        Nav.stop();
        Item it = plantItem;
        if (!Util.selectItem(s -> s.isOf(it))) { if (++tries > 12) plant = null; return; }
        BlockPos floor = plant.down();
        Util.lookAt(Vec3d.ofCenter(floor).add(0, 0.5, 0));
        Util.useOnBlock(floor, Direction.UP);
        plant = null;
    }
}
