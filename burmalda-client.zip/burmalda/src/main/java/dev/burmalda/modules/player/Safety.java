package dev.burmalda.modules.player;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import dev.burmalda.core.Util;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** Water-bucket MLG, lava escape and auto respawn. */
public class Safety extends Module {
    final Setting.Bool mlg = bool("Water MLG", true);
    final Setting.Bool lava = bool("Lava escape", true);
    final Setting.Bool respawn = bool("Auto respawn", true);
    private boolean placed, escaping;
    private int cd;

    public Safety() { super("Safety", Category.PLAYER); }

    @Override
    public void onDisable() { if (escaping) { mc.options.jumpKey.setPressed(false); mc.options.forwardKey.setPressed(false); } escaping = false; placed = false; }

    @Override
    public void onTick() {
        var p = mc.player;
        if (respawn.get() && mc.currentScreen instanceof DeathScreen) { p.requestRespawn(); return; }

        if (mlg.get()) {
            if (!placed && p.fallDistance > 5 && !p.isTouchingWater() && !p.isOnGround() && !p.getAbilities().flying && !p.isFallFlying()) {
                var r = mc.world.raycast(new RaycastContext(p.getPos(), p.getPos().add(0, -6, 0), RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
                if (r.getType() == HitResult.Type.BLOCK && p.getY() - r.getPos().y < 4.5) {
                    int h = Util.findHotbar(s -> s.isOf(Items.WATER_BUCKET));
                    if (h >= 0) {
                        p.getInventory().selectedSlot = h;
                        p.setPitch(90);
                        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                        placed = true; cd = 0;
                    }
                }
            } else if (placed && (p.isOnGround() || p.isTouchingWater())) {
                if (++cd >= 2) {
                    int h = Util.findHotbar(s -> s.isOf(Items.BUCKET));
                    if (h >= 0) { p.getInventory().selectedSlot = h; p.setPitch(90); mc.interactionManager.interactItem(p, Hand.MAIN_HAND); }
                    placed = false; cd = 0;
                }
            }
        }

        if (lava.get() && p.isInLava()) {
            escaping = true;
            mc.options.jumpKey.setPressed(true);
            BlockPos safe = nearestSafe(p.getBlockPos());
            if (safe != null) {
                Util.turnYaw(Util.yawTo(Vec3d.ofBottomCenter(safe)), 70f);
                mc.options.forwardKey.setPressed(true);
            }
        } else if (escaping) {
            escaping = false;
            mc.options.jumpKey.setPressed(false);
            mc.options.forwardKey.setPressed(false);
        }
    }

    private static BlockPos nearestSafe(BlockPos c) {
        BlockPos best = null; double bd = 1e9;
        for (int dx = -6; dx <= 6; dx++) for (int dz = -6; dz <= 6; dz++) for (int dy = -2; dy <= 2; dy++) {
            BlockPos q = c.add(dx, dy, dz);
            if (!Util.standable(q)) continue;
            double d = q.getSquaredDistance(c);
            if (d < bd) { bd = d; best = q; }
        }
        return best;
    }
}
