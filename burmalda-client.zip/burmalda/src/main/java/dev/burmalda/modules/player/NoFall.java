package dev.burmalda.modules.player;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

public class NoFall extends Module {
    final Setting.Num dist = num("Fall distance", 2.5, 1, 10, 0.5);

    public NoFall() { super("NoFall", Category.MOVEMENT); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p.fallDistance > dist.get() && !p.isOnGround() && !p.isFallFlying() && !p.getAbilities().flying)
            p.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true));
    }
}
