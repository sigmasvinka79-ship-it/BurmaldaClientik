package dev.burmalda.modules.combat;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import dev.burmalda.modules.player.AutoEat;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.item.Items;

/** Raises the offhand shield while an enemy is close or KillAura has a target. */
public class AutoShield extends Module {
    final Setting.Num range = num("Range", 4.5, 2, 8, 0.5);
    private boolean blocking;

    public AutoShield() { super("AutoShield", Category.COMBAT); }

    @Override public void onDisable() { if (blocking) mc.options.useKey.setPressed(false); blocking = false; }

    @Override
    public void onTick() {
        var p = mc.player;
        if (AutoEat.busy) return;
        var off = p.getOffHandStack();
        boolean threat = KillAura.target != null;
        if (!threat) for (Entity e : mc.world.getEntities())
            if (e instanceof Monster && e.isAlive() && p.distanceTo(e) < range.get()) { threat = true; break; }
        if (off.isOf(Items.SHIELD) && threat && !p.getItemCooldownManager().isCoolingDown(off.getItem())) {
            mc.options.useKey.setPressed(true); blocking = true;
        } else if (blocking) { mc.options.useKey.setPressed(false); blocking = false; }
    }
}
