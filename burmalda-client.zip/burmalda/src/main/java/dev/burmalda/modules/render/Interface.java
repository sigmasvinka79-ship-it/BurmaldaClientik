package dev.burmalda.modules.render;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import dev.burmalda.ui.Gfx;

/** Colour theme + animation speed for the whole client. */
public class Interface extends Module {
    final Setting.Mode theme = mode("Theme", "Lilac", "Lilac", "Purple", "Ocean", "Sunset", "Mint", "Blood", "Rainbow");
    final Setting.Num anim = num("Anim speed", 5, 1, 10, 1);

    public Interface() { super("Interface", Category.MISC); enabled = true; }

    @Override
    public void onTick() {
        Gfx.setTheme(theme.value);
        Gfx.speed = 1500.0 / anim.get();
    }
}
