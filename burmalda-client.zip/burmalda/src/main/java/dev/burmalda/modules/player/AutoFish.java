package dev.burmalda.modules.player;

import dev.burmalda.core.Module;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

public class AutoFish extends Module {
    private int cd;

    public AutoFish() { super("AutoFish", Category.PLAYER); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (cd > 0) { cd--; return; }
        if (!p.getMainHandStack().isOf(Items.FISHING_ROD)) {
            for (int i = 0; i < 9; i++) if (p.getInventory().getStack(i).isOf(Items.FISHING_ROD)) { p.getInventory().selectedSlot = i; cd = 5; return; }
            return;
        }
        var hook = p.fishHook;
        if (hook == null) {
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND); // cast
            cd = 20;
        } else if (hook.age > 20 && hook.isTouchingWater() && hook.getVelocity().y < -0.08) {
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND); // reel in
            cd = 15;
        }
    }
}
