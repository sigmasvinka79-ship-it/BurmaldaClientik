package dev.burmalda.modules.combat;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import dev.burmalda.core.Util;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

/** Equips the best armor found in the inventory. */
public class AutoArmor extends Module {
    final Setting.Num delay = num("Delay", 5, 1, 20, 1);
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private int cd;

    public AutoArmor() { super("AutoArmor", Category.COMBAT); }

    private static double score(ItemStack s) {
        double d = 0;
        for (var e : s.getOrDefault(DataComponentTypes.ATTRIBUTE_MODIFIERS, AttributeModifiersComponent.DEFAULT).modifiers()) {
            if (e.attribute().equals(EntityAttributes.GENERIC_ARMOR)) d += e.modifier().value();
            else if (e.attribute().equals(EntityAttributes.GENERIC_ARMOR_TOUGHNESS)) d += e.modifier().value() * 0.5;
        }
        if (s.isDamageable()) d += 0.5 * (1.0 - (double) s.getDamage() / s.getMaxDamage());
        return d;
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (cd-- > 0 || mc.currentScreen != null) return;
        int sync = p.playerScreenHandler.syncId;
        for (int i = 0; i < 4; i++) {
            ItemStack cur = p.getEquippedStack(SLOTS[i]);
            double bs = cur.isEmpty() ? -1 : score(cur);
            int best = -1;
            for (int j = 0; j < 36; j++) {
                ItemStack st = p.getInventory().getStack(j);
                if (!(st.getItem() instanceof ArmorItem ai) || ai.getSlotType() != SLOTS[i]) continue;
                double sc = score(st);
                if (sc > bs + 0.01) { bs = sc; best = j; }
            }
            if (best < 0) continue;
            if (!cur.isEmpty()) {
                if (Util.freeSlots() == 0) continue;
                mc.interactionManager.clickSlot(sync, 5 + i, 0, SlotActionType.QUICK_MOVE, p);
            } else mc.interactionManager.clickSlot(sync, Util.screenSlot(best), 0, SlotActionType.QUICK_MOVE, p);
            cd = delay.i();
            return;
        }
    }
}
