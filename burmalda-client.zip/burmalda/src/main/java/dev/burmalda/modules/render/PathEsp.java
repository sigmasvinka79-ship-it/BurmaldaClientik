package dev.burmalda.modules.render;

import dev.burmalda.core.Module;
import dev.burmalda.core.Nav;
import dev.burmalda.ui.Gfx;
import dev.burmalda.ui.Render3D;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/** Draws the route the pathfinder is following. */
public class PathEsp extends Module {
    public PathEsp() { super("PathESP", Category.RENDER); }

    @Override
    public void onRender3D(WorldRenderContext ctx) {
        List<BlockPos> path = Nav.path;
        if (!Nav.active || path.size() < 2) return;
        Render3D.Through.begin(ctx);
        for (int i = 1; i < path.size(); i++) {
            BlockPos a = path.get(i - 1), b = path.get(i);
            Render3D.Through.line(new Vec3d(a.getX() + 0.5, a.getY() + 0.1, a.getZ() + 0.5),
                    new Vec3d(b.getX() + 0.5, b.getY() + 0.1, b.getZ() + 0.5), Gfx.accent(i * 0.25));
        }
        Render3D.Through.end();
    }
}
