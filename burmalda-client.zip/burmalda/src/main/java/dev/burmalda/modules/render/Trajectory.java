package dev.burmalda.modules.render;

import dev.burmalda.core.Module;
import dev.burmalda.ui.Gfx;
import dev.burmalda.ui.Render3D;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** Predicted flight path of pearls, snowballs, potions, bows and tridents you are holding. */
public class Trajectory extends Module {
    public Trajectory() { super("Trajectory", Category.RENDER); }

    @Override
    public void onRender3D(WorldRenderContext ctx) {
        var p = mc.player;
        ItemStack s = p.getMainHandStack();
        double speed, grav; float off = 0;
        if (s.isOf(Items.ENDER_PEARL) || s.isOf(Items.SNOWBALL) || s.isOf(Items.EGG)) { speed = 1.5; grav = 0.03; }
        else if (s.isOf(Items.SPLASH_POTION) || s.isOf(Items.LINGERING_POTION)) { speed = 0.5; grav = 0.05; off = -20; }
        else if (s.isOf(Items.EXPERIENCE_BOTTLE)) { speed = 0.7; grav = 0.07; off = -20; }
        else if (s.isOf(Items.BOW) && p.isUsingItem()) {
            float pull = BowItem.getPullProgress(p.getItemUseTime());
            if (pull < 0.1f) return;
            speed = pull * 3.0; grav = 0.05;
        } else if (s.isOf(Items.TRIDENT) && p.isUsingItem()) { speed = 2.5; grav = 0.05; }
        else return;
        Vec3d pos = p.getEyePos().add(0, -0.1, 0), vel = Vec3d.fromPolar(p.getPitch() + off, p.getYaw()).multiply(speed);
        Render3D.Through.begin(ctx);
        int col = Gfx.accent(0);
        for (int i = 0; i < 120; i++) {
            Vec3d next = pos.add(vel);
            var hit = mc.world.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
            if (hit.getType() == HitResult.Type.BLOCK) {
                Render3D.Through.line(pos, hit.getPos(), col);
                Render3D.Through.box(new Box(hit.getPos().subtract(0.2, 0.2, 0.2), hit.getPos().add(0.2, 0.2, 0.2)), 0xFFFFFFFF);
                break;
            }
            Render3D.Through.line(pos, next, Gfx.alpha(col, 230 - i));
            vel = vel.multiply(0.99).add(0, -grav, 0);
            pos = next;
        }
        Render3D.Through.end();
    }
}
