package dev.burmalda.modules.player;

import dev.burmalda.core.Loot;
import dev.burmalda.core.Module;
import dev.burmalda.core.ModuleManager;
import dev.burmalda.core.Nav;
import dev.burmalda.core.Setting;
import dev.burmalda.core.Util;
import dev.burmalda.modules.combat.KillAura;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Picks up nearby drops when idle and can throw junk out when the inventory gets full. */
public class AutoLoot extends Module {
    public static final Set<Item> JUNK = new HashSet<>(List.of(Items.COBBLESTONE, Items.COBBLED_DEEPSLATE, Items.DIRT, Items.GRAVEL,
            Items.ANDESITE, Items.DIORITE, Items.GRANITE, Items.TUFF, Items.NETHERRACK, Items.ROTTEN_FLESH, Items.SPIDER_EYE,
            Items.POISONOUS_POTATO, Items.DEEPSLATE, Items.CALCITE));

    final Setting.Num radius = num("Radius", 8, 3, 20, 1);
    final Setting.Bool junk = bool("Drop junk", false);
    final Setting.Num fullSlots = num("Drop when free <=", 4, 1, 20, 1);
    private int cd;

    public AutoLoot() { super("AutoLoot", Category.PLAYER); }

    @Override public void onDisable() { Nav.stop(); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (junk.get() && cd-- <= 0 && Util.freeSlots() <= fullSlots.i()) {
            for (int i = 0; i < 36; i++) {
                ItemStack s = p.getInventory().getStack(i);
                if (!s.isEmpty() && JUNK.contains(s.getItem())) {
                    mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, Util.screenSlot(i), 1, SlotActionType.THROW, p);
                    cd = 4;
                    break;
                }
            }
        }
        if (KillAura.target != null || ModuleManager.controllerActive() || AutoStore.working) return;
        Loot.collect(s -> !junk.get() || !JUNK.contains(s.getItem()), radius.get());
    }
}
