package dev.burmalda.modules.player;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import dev.burmalda.core.Util;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

/** Enable (or bind it) to swap chestplate <-> elytra. While elytra are worn it fires fireworks when you get slow. */
public class ElytraHelper extends Module {
    final Setting.Bool firework = bool("Auto firework", true);
    private int cd, wait;

    public ElytraHelper() { super("ElytraHelper", Category.MOVEMENT); }

    @Override
    public void onEnable() {
        var p = mc.player;
        boolean wearing = p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA);
        int idx = -1;
        for (int j = 0; j < 36; j++) {
            ItemStack st = p.getInventory().getStack(j);
            boolean ok = wearing ? (st.getItem() instanceof ArmorItem ai && ai.getSlotType() == EquipmentSlot.CHEST) : st.isOf(Items.ELYTRA);
            if (ok) { idx = j; break; }
        }
        if (idx < 0) { Util.msg(wearing ? "Нет нагрудника в инвентаре." : "Нет элитр в инвентаре."); enabled = false; return; }
        int sync = p.playerScreenHandler.syncId, slot = Util.screenSlot(idx);
        mc.interactionManager.clickSlot(sync, slot, 0, SlotActionType.PICKUP, p);
        mc.interactionManager.clickSlot(sync, 6, 0, SlotActionType.PICKUP, p);
        mc.interactionManager.clickSlot(sync, slot, 0, SlotActionType.PICKUP, p);
        wait = 4; cd = 0;
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (wait > 0) { wait--; return; }
        if (!p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) { setEnabled(false); return; }
        if (cd-- > 0 || !firework.get()) return;
        if (p.isFallFlying() && p.getVelocity().length() < 0.9 && !p.isUsingItem()) {
            int h = Util.findHotbar(s -> s.isOf(Items.FIREWORK_ROCKET));
            if (h >= 0) { p.getInventory().selectedSlot = h; mc.interactionManager.interactItem(p, Hand.MAIN_HAND); cd = 40; }
        }
    }
}
