package dev.burmalda.modules.combat;

import dev.burmalda.core.Module;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/** Sends a tiny fake hop right before every attack so it lands as a critical hit. */
public class Criticals extends Module {
    public Criticals() { super("Criticals", Category.COMBAT); }

    public void pre(PlayerEntity pl) {
        var p = mc.player;
        if (p == null || pl != p || !p.isOnGround() || p.isTouchingWater() || p.isInLava() || p.isClimbing()) return;
        var h = p.networkHandler;
        h.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(p.getX(), p.getY() + 0.0625, p.getZ(), false));
        h.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(p.getX(), p.getY(), p.getZ(), false));
    }
}
