package dev.burmalda.modules.render;

import dev.burmalda.core.Module;
import net.minecraft.entity.Entity;

public class SeeInvisible extends Module {
    public SeeInvisible() { super("SeeInvisible", Category.RENDER); }

    @Override
    public void onTick() {
        for (Entity e : mc.world.getEntities()) if (e != mc.player && e.isInvisible()) e.setInvisible(false);
    }
}
