package dev.burmalda.modules.combat;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {
    final Setting.Num hp = num("Health <=", 20, 4, 20, 1);
    int cd;

    public AutoTotem() { super("AutoTotem", Category.COMBAT); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (cd-- > 0 || p.getHealth() > hp.get() || p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        for (int i = 0; i < 36; i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                int slot = i < 9 ? 36 + i : i; // playerScreenHandler slot id
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
                cd = 5;
                return;
            }
        }
    }
}
