package dev.burmalda.modules.combat;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Hits whatever is under the crosshair as soon as the cooldown is ready (no rotation). */
public class TriggerBot extends Module {
    final Setting.Num range = num("Range", 3.0, 2.0, 4.0, 0.1);
    final Setting.Num sharp = num("Sharpness", 0.95, 0.1, 1.0, 0.01);
    final Setting.Bool players = bool("Players", true);
    final Setting.Bool hostile = bool("Hostile", true);

    public TriggerBot() { super("TriggerBot", Category.COMBAT); }

    @Override
    public void onTick() {
        var p = mc.player;
        Entity e = mc.targetedEntity;
        if (!(e instanceof LivingEntity le) || !le.isAlive() || e instanceof ArmorStandEntity || mc.interactionManager == null) return;
        if (!((e instanceof PlayerEntity && players.get()) || (e instanceof Monster && hostile.get()))) return;
        if (p.distanceTo(e) > range.get() + 0.5) return;
        if (p.isUsingItem() && !p.getActiveItem().isOf(Items.SHIELD)) return;
        if (p.getAttackCooldownProgress(0.5f) < sharp.get()) return;
        mc.interactionManager.attackEntity(p, e);
        p.swingHand(Hand.MAIN_HAND);
        KillAura.sinceAttack = 0;
    }
}
