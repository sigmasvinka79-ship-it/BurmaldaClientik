package dev.burmalda.modules.render;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;

public class Zoom extends Module {
    final Setting.Num fovSet = num("FOV", 30, 30, 80, 1);
    private Integer saved;

    public Zoom() { super("Zoom", Category.RENDER); }

    @Override
    public void onTick() {
        if (saved == null) saved = mc.options.getFov().getValue();
        mc.options.getFov().setValue(fovSet.i());
    }
    @Override
    public void onDisable() {
        if (saved != null) mc.options.getFov().setValue(saved);
        saved = null;
    }
}
