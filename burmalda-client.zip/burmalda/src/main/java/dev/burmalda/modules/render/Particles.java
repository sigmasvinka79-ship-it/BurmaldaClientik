package dev.burmalda.modules.render;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;

/** Ambient particles around you (stars, snow, hearts, flames, magic) and an optional trail behind you. */
public class Particles extends Module {
    final Setting.Mode type = mode("Type", "Stars", "Stars", "Snow", "Hearts", "Flames", "Magic");
    final Setting.Num amount = num("Amount", 3, 1, 12, 1);
    final Setting.Num radius = num("Radius", 8, 3, 16, 1);
    final Setting.Bool behind = bool("Behind you", false);

    public Particles() { super("Particles", Category.RENDER); }

    @Override
    public void onTick() {
        var p = mc.player;
        ParticleEffect pe = switch (type.value) {
            case "Snow" -> ParticleTypes.SNOWFLAKE;
            case "Hearts" -> ParticleTypes.HEART;
            case "Flames" -> ParticleTypes.FLAME;
            case "Magic" -> ParticleTypes.ENCHANT;
            default -> ParticleTypes.END_ROD;
        };
        double r = radius.get();
        if (behind.get()) {
            if (p.getVelocity().horizontalLengthSquared() > 0.002)
                for (int i = 0; i < amount.i(); i++)
                    mc.world.addParticle(pe, p.getX() + (Math.random() - 0.5) * 0.4, p.getY() + 0.1 + Math.random() * 0.4, p.getZ() + (Math.random() - 0.5) * 0.4, 0, 0.02, 0);
            return;
        }
        for (int i = 0; i < amount.i(); i++)
            mc.world.addParticle(pe, p.getX() + (Math.random() * 2 - 1) * r, p.getY() + Math.random() * 5 - 1, p.getZ() + (Math.random() * 2 - 1) * r, 0, 0.015, 0);
    }
}
