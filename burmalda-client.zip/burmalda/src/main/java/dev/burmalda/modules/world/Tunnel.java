package dev.burmalda.modules.world;

import dev.burmalda.core.Digger;
import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import dev.burmalda.core.Util;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** Digs a 1x2 tunnel in the direction you face: straight, or a staircase down/up to a target Y. Places torches. */
public class Tunnel extends Module {
    final Setting.Mode mode = mode("Mode", "Straight", "Straight", "Stairs down", "Stairs up");
    final Setting.Num length = num("Length", 64, 8, 256, 8);
    final Setting.Num targetY = num("Target Y", -58, -60, 120, 1);
    final Setting.Bool torches = bool("Torches", true);
    final Setting.Num gap = num("Torch gap", 8, 4, 16, 1);
    private int dx, dz, steps, lastTorch;
    private BlockPos lastF;

    public Tunnel() { super("Tunnel", Category.WORLD); controller = true; }

    @Override
    public void onEnable() {
        Direction d = mc.player.getHorizontalFacing();
        dx = d.getOffsetX(); dz = d.getOffsetZ(); steps = 0; lastTorch = -1; lastF = null;
    }
    @Override public void onDisable() { Digger.release(); }

    @Override
    public void onTick() {
        Digger.release();
        BlockPos F = Util.feet();
        if (lastF == null || !lastF.equals(F)) { if (lastF != null) steps++; lastF = F; }
        if (steps >= length.i()) { Util.msg("Tunnel finished."); setEnabled(false); return; }
        int dy = 0;
        if (mode.is("Stairs down") && F.getY() > targetY.i()) dy = -1;
        if (mode.is("Stairs up") && F.getY() < targetY.i()) dy = 1;
        if (torches.get() && steps > 0 && steps % gap.i() == 0 && lastTorch != steps && mc.player.isOnGround()) {
            lastTorch = steps;
            if (Util.selectItem(s -> s.isOf(Items.TORCH))) { Util.useOnBlock(F.down(), Direction.UP); return; }
        }
        Digger.Status st = Digger.advance(F.add(dx, dy, dz));
        if (st == Digger.Status.BLOCKED) { Util.msg("Tunnel stopped: " + Digger.reason); setEnabled(false); }
    }
}
