package dev.burmalda.modules.render;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import dev.burmalda.core.Util;
import dev.burmalda.ui.Render3D;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.ArrayList;
import java.util.List;

/** X-ray style highlight through walls. The world is scanned one horizontal layer per tick (no lag spikes). */
public class OreEsp extends Module {
    private record Hit(BlockPos pos, int col) {}

    final Setting.Mode what = mode("Target", "All ores", "All ores", "Diamond", "Iron", "Gold", "Copper", "Coal", "Redstone", "Lapis", "Emerald", "Debris", "Chests", "Spawners");
    final Setting.Num radius = num("Radius", 20, 8, 32, 1);
    private List<Hit> cache = new ArrayList<>(), building = new ArrayList<>();
    private int layer = -1, cd;
    private BlockPos center;

    public OreEsp() { super("OreESP", Category.RENDER); }

    private boolean match(BlockState s) {
        return switch (what.value) {
            case "All ores" -> Util.isOre(s);
            case "Diamond" -> s.isIn(BlockTags.DIAMOND_ORES);
            case "Iron" -> s.isIn(BlockTags.IRON_ORES);
            case "Gold" -> s.isIn(BlockTags.GOLD_ORES) || s.isOf(Blocks.NETHER_GOLD_ORE);
            case "Copper" -> s.isIn(BlockTags.COPPER_ORES);
            case "Coal" -> s.isIn(BlockTags.COAL_ORES);
            case "Redstone" -> s.isIn(BlockTags.REDSTONE_ORES);
            case "Lapis" -> s.isIn(BlockTags.LAPIS_ORES);
            case "Emerald" -> s.isIn(BlockTags.EMERALD_ORES);
            case "Debris" -> s.isOf(Blocks.ANCIENT_DEBRIS);
            case "Chests" -> s.isOf(Blocks.CHEST) || s.isOf(Blocks.TRAPPED_CHEST) || s.isOf(Blocks.ENDER_CHEST) || s.isOf(Blocks.BARREL);
            default -> s.isOf(Blocks.SPAWNER);
        };
    }
    private int color(BlockState s) {
        if (s.isOf(Blocks.SPAWNER)) return 0xFFB03CFF;
        if (s.isOf(Blocks.CHEST) || s.isOf(Blocks.TRAPPED_CHEST) || s.isOf(Blocks.ENDER_CHEST) || s.isOf(Blocks.BARREL)) return 0xFFFFC83C;
        return Util.oreColor(s);
    }

    @Override
    public void onTick() {
        if (layer < 0) {
            if (cd-- > 0) return;
            center = mc.player.getBlockPos(); layer = 0; building = new ArrayList<>();
        }
        int r = radius.i(), y = center.getY() - r + layer;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int x = -r; x <= r; x++) for (int z = -r; z <= r; z++) {
            m.set(center.getX() + x, y, center.getZ() + z);
            BlockState s = mc.world.getBlockState(m);
            if (s.isAir() || !match(s) || building.size() > 600) continue;
            building.add(new Hit(m.toImmutable(), color(s)));
        }
        if (++layer > 2 * r) { cache = building; layer = -1; cd = 15; }
    }

    @Override
    public void onRender3D(WorldRenderContext ctx) {
        if (cache.isEmpty()) return;
        Render3D.Through.begin(ctx);
        for (Hit h : cache) Render3D.Through.box(new Box(h.pos()), h.col());
        Render3D.Through.end();
    }
}
