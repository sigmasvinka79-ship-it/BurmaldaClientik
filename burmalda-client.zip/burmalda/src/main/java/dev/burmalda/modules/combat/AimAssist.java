package dev.burmalda.modules.combat;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Smoothly pulls your aim towards the nearest enemy inside the FOV. */
public class AimAssist extends Module {
    final Setting.Num speed = num("Speed", 6, 1, 20, 1);
    final Setting.Num fov = num("FOV", 70, 10, 180, 5);
    final Setting.Num range = num("Range", 4.5, 2, 8, 0.5);
    final Setting.Bool onlyAttack = bool("Only while attacking", true);
    final Setting.Bool players = bool("Players", true);
    final Setting.Bool hostile = bool("Hostile", true);

    public AimAssist() { super("AimAssist", Category.COMBAT); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (onlyAttack.get() && !mc.options.attackKey.isPressed()) return;
        Entity best = null; double bd = 1e9;
        for (Entity e : mc.world.getEntities()) {
            if (e == p || !(e instanceof LivingEntity le) || !le.isAlive() || e instanceof ArmorStandEntity || dev.burmalda.core.Friends.is(e)) continue;
            if (!((e instanceof PlayerEntity && players.get()) || (e instanceof Monster && hostile.get()))) continue;
            double d = p.distanceTo(e);
            if (d > range.get()) continue;
            Vec3d a = e.getPos().add(0, e.getHeight() * 0.6, 0).subtract(p.getEyePos());
            float yaw = (float) (Math.toDegrees(Math.atan2(a.z, a.x)) - 90);
            double diff = Math.abs(MathHelper.wrapDegrees(yaw - p.getYaw()));
            if (diff > fov.get() / 2 || diff + d * 0.1 >= bd) continue;
            bd = diff + d * 0.1; best = e;
        }
        if (best == null) return;
        Vec3d a = best.getPos().add(0, best.getHeight() * 0.6, 0).subtract(p.getEyePos());
        float yaw = (float) (Math.toDegrees(Math.atan2(a.z, a.x)) - 90), pitch = (float) -Math.toDegrees(Math.atan2(a.y, Math.hypot(a.x, a.z)));
        float s = (float) speed.get();
        p.setYaw(p.getYaw() + MathHelper.clamp(MathHelper.wrapDegrees(yaw - p.getYaw()), -s, s));
        p.setPitch(p.getPitch() + MathHelper.clamp(pitch - p.getPitch(), -s * 0.6f, s * 0.6f));
    }
}
