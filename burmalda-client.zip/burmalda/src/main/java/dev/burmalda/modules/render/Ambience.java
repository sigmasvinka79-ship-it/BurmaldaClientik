package dev.burmalda.modules.render;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import net.minecraft.util.math.Vec3d;

/** Custom sky / clouds / stars (via a mixin on ClientWorld) and optional time lock + brightness. */
public class Ambience extends Module {
    final Setting.Mode sky = mode("Sky", "Purple", "Purple", "Pink", "Blue", "Teal", "Vanilla");
    final Setting.Mode time = mode("Time", "Server", "Server", "Day", "Dusk", "Night");
    final Setting.Bool stars = bool("Stars", true);
    final Setting.Bool clouds = bool("Clouds", true);
    final Setting.Bool bright = bool("Brightness", true);

    private static volatile boolean active;
    private static volatile Vec3d skyC, cloudC;
    private static volatile float starB = -1;

    public static Vec3d sky() { return active ? skyC : null; }
    public static Vec3d clouds() { return active ? cloudC : null; }
    public static float stars() { return active ? starB : -1f; }

    public Ambience() { super("Ambience", Category.RENDER); enabled = true; }

    @Override public void onDisable() { active = false; }

    @Override
    public void onTick() {
        switch (sky.value) {
            case "Pink" -> { skyC = new Vec3d(0.62, 0.34, 0.58); cloudC = new Vec3d(1.0, 0.86, 0.95); }
            case "Blue" -> { skyC = new Vec3d(0.27, 0.40, 0.72); cloudC = new Vec3d(0.88, 0.93, 1.0); }
            case "Teal" -> { skyC = new Vec3d(0.18, 0.50, 0.55); cloudC = new Vec3d(0.88, 1.0, 0.98); }
            default -> { skyC = new Vec3d(0.40, 0.30, 0.58); cloudC = new Vec3d(0.93, 0.88, 1.0); }
        }
        active = !sky.is("Vanilla");
        starB = stars.get() ? 0.85f : -1f;
        if (!clouds.get()) cloudC = null;
        switch (time.value) {
            case "Day" -> mc.world.setTimeOfDay(6000L);
            case "Dusk" -> mc.world.setTimeOfDay(12700L);
            case "Night" -> mc.world.setTimeOfDay(18000L);
            default -> { }
        }
        if (bright.get() && mc.options.getGamma().getValue() < 1.0) mc.options.getGamma().setValue(1.0);
    }
}
