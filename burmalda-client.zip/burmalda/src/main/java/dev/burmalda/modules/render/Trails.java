package dev.burmalda.modules.render;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import dev.burmalda.ui.Gfx;
import dev.burmalda.ui.Render3D;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;

public class Trails extends Module {
    final Setting.Num length = num("Length", 60, 10, 200, 5);
    final Setting.Mode style = mode("Style", "Line", "Line", "Ribbon", "Dots");
    private final ArrayDeque<Vec3d> pts = new ArrayDeque<>();

    public Trails() { super("Trails", Category.RENDER); }

    @Override public void onDisable() { pts.clear(); }

    @Override
    public void onTick() {
        Vec3d p = mc.player.getPos().add(0, 0.1, 0);
        if (pts.isEmpty() || pts.peekLast().squaredDistanceTo(p) > 0.0025) pts.addLast(p);
        while (pts.size() > length.i()) pts.removeFirst();
    }

    @Override
    public void onRender3D(WorldRenderContext ctx) {
        if (pts.size() < 2 || ctx.consumers() == null) return;
        var vc = ctx.consumers().getBuffer(RenderLayer.getLines());
        var e = ctx.matrixStack().peek();
        Vec3d cam = ctx.camera().getPos();
        List<Vec3d> l = new ArrayList<>(pts);
        for (int i = 1; i < l.size(); i++) {
            int col = Gfx.alpha(Gfx.accent(i * 0.12), (int) (255.0 * i / l.size()));
            Vec3d a = l.get(i - 1), b = l.get(i);
            switch (style.value) {
                case "Ribbon" -> {
                    Render3D.line(vc, e, cam, a, b, col);
                    Render3D.line(vc, e, cam, a.add(0, 0.5, 0), b.add(0, 0.5, 0), col);
                    if (i % 3 == 0) Render3D.line(vc, e, cam, b, b.add(0, 0.5, 0), col);
                }
                case "Dots" -> {
                    if (i % 3 == 0) {
                        Render3D.line(vc, e, cam, b.add(-0.08, 0, 0), b.add(0.08, 0, 0), col);
                        Render3D.line(vc, e, cam, b.add(0, -0.08, 0), b.add(0, 0.08, 0), col);
                        Render3D.line(vc, e, cam, b.add(0, 0, -0.08), b.add(0, 0, 0.08), col);
                    }
                }
                default -> Render3D.line(vc, e, cam, a, b, col);
            }
        }
    }
}
