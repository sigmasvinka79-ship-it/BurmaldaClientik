package dev.burmalda.modules.render;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import dev.burmalda.ui.Gfx;
import dev.burmalda.ui.Render3D;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Boxes and tracers drawn through walls. */
public class Esp extends Module {
    final Setting.Bool players = bool("Players", true);
    final Setting.Bool hostile = bool("Hostile", true);
    final Setting.Bool passive = bool("Passive", false);
    final Setting.Bool items = bool("Items", false);
    final Setting.Bool boxes = bool("Boxes", true);
    final Setting.Bool tracers = bool("Tracers", true);
    final Setting.Num range = num("Range", 48, 10, 128, 2);

    public Esp() { super("ESP", Category.RENDER); }

    @Override
    public void onRender3D(WorldRenderContext ctx) {
        float td = mc.getRenderTickCounter().getTickDelta(true);
        Vec3d from = ctx.camera().getPos().add(mc.player.getRotationVec(td).multiply(0.6));
        Render3D.Through.begin(ctx);
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || e instanceof ArmorStandEntity || mc.player.distanceTo(e) > range.get()) continue;
            int col;
            if (e instanceof PlayerEntity) { if (!players.get()) continue; col = Gfx.accent(0); }
            else if (e instanceof Monster) { if (!hostile.get()) continue; col = 0xFFFF4040; }
            else if (e instanceof LivingEntity) { if (!passive.get()) continue; col = 0xFF50E060; }
            else if (e instanceof ItemEntity) { if (!items.get()) continue; col = 0xFFFFD040; }
            else continue;
            Box b = e.getBoundingBox().offset(e.getLerpedPos(td).subtract(e.getPos()));
            if (boxes.get()) Render3D.Through.box(b, col);
            if (tracers.get()) Render3D.Through.line(from, b.getCenter(), col);
        }
        Render3D.Through.end();
    }
}
