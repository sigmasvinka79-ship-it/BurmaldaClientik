package dev.burmalda.modules.combat;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import dev.burmalda.core.Util;
import dev.burmalda.modules.player.AutoEat;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Throws a splash Healing potion at your feet when HP is low. */
public class AutoPot extends Module {
    final Setting.Num hp = num("Health <=", 8, 2, 19, 1);
    private int cd;
    private boolean ready;

    public AutoPot() { super("AutoPot", Category.COMBAT); }

    private static boolean healing(ItemStack s) {
        return s.isOf(Items.SPLASH_POTION) && String.valueOf(s.get(DataComponentTypes.POTION_CONTENTS)).toLowerCase().contains("healing");
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (cd-- > 0) return;
        if (p.getHealth() > hp.get() || AutoEat.busy) { ready = false; return; }
        if (!ready) {
            if (!Util.selectItem(AutoPot::healing)) return;
            p.setPitch(90);
            ready = true;
            return;
        }
        ready = false;
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        cd = 15;
    }
}
