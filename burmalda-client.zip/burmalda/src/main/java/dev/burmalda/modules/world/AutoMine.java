package dev.burmalda.modules.world;

import dev.burmalda.core.Digger;
import dev.burmalda.core.Loot;
import dev.burmalda.core.Module;
import dev.burmalda.core.ModuleManager;
import dev.burmalda.core.Nav;
import dev.burmalda.core.Setting;
import dev.burmalda.core.Util;
import dev.burmalda.modules.player.AutoEat;
import dev.burmalda.modules.player.AutoLoot;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Finds the chosen block type nearby, walks to it (A*), mines it; buried ores are reached by digging a safe stair tunnel. */
public class AutoMine extends Module {
    final Setting.Mode what = mode("Target", "Diamond", "Diamond", "Iron", "Coal", "Gold", "Copper", "Redstone", "Lapis", "Emerald",
            "Debris", "Quartz", "All ores", "Logs", "Sand");
    final Setting.Num radius = num("Radius", 16, 6, 32, 1);
    final Setting.Bool tunnel = bool("Tunnel to buried", true);
    final Setting.Bool pickup = bool("Pick up drops", true);
    final Setting.Bool replant = bool("Replant saplings", true);
    final Setting.Bool avoidWater = bool("Avoid water", true);

    private BlockPos target;
    private final Set<BlockPos> bad = new HashSet<>();
    private final List<BlockPos> replantList = new ArrayList<>();
    private boolean pathFailed, warnedTool;
    private int scanCd, navCd, plantTries;

    public AutoMine() { super("AutoMine", Category.WORLD); controller = true; }

    @Override
    public void onEnable() {
        target = null; bad.clear(); replantList.clear(); pathFailed = false; warnedTool = false; Nav.reset();
        for (Class<? extends Module> c : List.of(AutoEat.class)) { Module m = ModuleManager.get(c); if (m != null) m.setEnabled(true); }
    }
    @Override public void onDisable() { Nav.stop(); Digger.release(); target = null; }

    private boolean logsMode() { return what.is("Logs") || what.is("Sand"); }

    private boolean matches(BlockState s) {
        return switch (what.value) {
            case "Diamond" -> s.isIn(BlockTags.DIAMOND_ORES);
            case "Iron" -> s.isIn(BlockTags.IRON_ORES);
            case "Coal" -> s.isIn(BlockTags.COAL_ORES);
            case "Gold" -> s.isIn(BlockTags.GOLD_ORES) || s.isOf(Blocks.NETHER_GOLD_ORE);
            case "Copper" -> s.isIn(BlockTags.COPPER_ORES);
            case "Redstone" -> s.isIn(BlockTags.REDSTONE_ORES);
            case "Lapis" -> s.isIn(BlockTags.LAPIS_ORES);
            case "Emerald" -> s.isIn(BlockTags.EMERALD_ORES);
            case "Debris" -> s.isOf(Blocks.ANCIENT_DEBRIS);
            case "Quartz" -> s.isOf(Blocks.NETHER_QUARTZ_ORE);
            case "All ores" -> Util.isOre(s);
            case "Logs" -> s.isIn(BlockTags.LOGS);
            default -> s.isIn(BlockTags.SAND);
        };
    }
    private boolean exposed(BlockPos p) {
        for (Direction d : Direction.values()) if (!Util.solid(p.offset(d))) return true;
        return false;
    }

    private BlockPos find() {
        BlockPos c = mc.player.getBlockPos();
        int r = radius.i();
        Vec3d eye = mc.player.getEyePos();
        BlockPos best = null; double bs = 1e18; boolean noTool = false;
        for (BlockPos pos : BlockPos.iterate(c.add(-r, -r, -r), c.add(r, r, r))) {
            BlockState s = mc.world.getBlockState(pos);
            if (s.isAir() || !matches(s) || bad.contains(pos)) continue;
            if (!Util.hasToolFor(s)) { noTool = true; continue; }
            double score = Vec3d.ofCenter(pos).squaredDistanceTo(eye) + (exposed(pos) ? 0 : 150);
            if (score < bs) { bs = score; best = pos.toImmutable(); }
        }
        if (best == null && noTool && !warnedTool) { warnedTool = true; Util.msg("You need a suitable pickaxe in the hotbar."); }
        return best;
    }

    @Override
    public void onTick() {
        var p = mc.player;
        Digger.release();
        if (AutoEat.busy) { Nav.stop(); return; }

        if (target != null && !matches(Util.state(target))) { // it was mined
            if (what.is("Logs") && replant.get() && Util.state(target.down()).isIn(BlockTags.DIRT)) replantList.add(target.down());
            target = null; pathFailed = false; Nav.reset();
        }
        if (target == null) {
            if (pickup.get() && Loot.collect(s -> !AutoLoot.JUNK.contains(s.getItem()), 10)) return;
            if (what.is("Logs") && replant.get() && doReplant()) return;
            if (scanCd-- > 0) return;
            scanCd = 10;
            target = find();
            pathFailed = false; Nav.reset();
            if (target == null) return;
        }

        Vec3d eye = p.getEyePos(), c = Vec3d.ofCenter(target);
        if (eye.distanceTo(c) <= 4.3) {
            BlockHitResult hit = Util.ray(eye, c);
            BlockPos mb = hit.getType() == HitResult.Type.BLOCK ? hit.getBlockPos() : target;
            if (!Util.canBreak(mb) || Util.hazardNear(mb, avoidWater.get())) { bad.add(target); target = null; Nav.reset(); return; }
            Nav.stop();
            BlockState ms = Util.state(mb);
            if (!Util.selectBestTool(ms) && mb.equals(target)) { bad.add(target); target = null; return; }
            Util.mine(mb);
            return;
        }

        if (!pathFailed) {
            if (Nav.active) return;
            if (Nav.failed) { pathFailed = true; }
            else if (navCd-- <= 0) {
                navCd = 10;
                if (logsMode()) Nav.goNearEye(c, 3.9); else Nav.goNear(c, 3.9, true);
                if (Nav.failed) pathFailed = true;
                return;
            } else return;
        }
        if (!tunnel.get() || logsMode()) { bad.add(target); target = null; Nav.reset(); return; }
        Nav.stop();
        BlockPos F = Util.feet(), T = target;
        int dx = T.getX() - F.getX(), dz = T.getZ() - F.getZ();
        int sx = 0, sz = 0;
        if (Math.abs(dx) >= Math.abs(dz) && dx != 0) sx = Integer.signum(dx);
        else if (dz != 0) sz = Integer.signum(dz);
        else sx = 1;
        int wantY = T.getY() - 1, dy = Integer.signum(wantY - F.getY());
        BlockPos N = F.add(sx, dy, sz);
        Digger.Status st = Digger.advance(N);
        if (st == Digger.Status.BLOCKED) { Util.msg("Skipping ore: " + Digger.reason); bad.add(target); target = null; Digger.release(); }
    }

    private boolean doReplant() {
        if (replantList.isEmpty()) return false;
        var p = mc.player;
        BlockPos dirt = replantList.get(0);
        BlockPos above = dirt.up();
        if (!Util.state(above).isAir()) { replantList.remove(0); return false; }
        Vec3d c = Vec3d.ofCenter(above);
        if (p.getEyePos().distanceTo(c) > 4.0) {
            if (Nav.failed) { Nav.reset(); replantList.remove(0); return false; }
            if (!Nav.active) Nav.goNear(c, 3.5, true);
            return true;
        }
        Nav.stop();
        if (!Util.selectItem(s -> s.isIn(ItemTags.SAPLINGS))) {
            if (++plantTries > 15) { replantList.clear(); plantTries = 0; }
            return replantList.size() > 0;
        }
        plantTries = 0;
        Util.lookAt(Vec3d.ofCenter(dirt).add(0, 0.5, 0));
        Util.useOnBlock(dirt, Direction.UP);
        replantList.remove(0);
        return true;
    }
}
