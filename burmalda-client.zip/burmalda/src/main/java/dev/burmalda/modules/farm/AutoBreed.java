package dev.burmalda.modules.farm;

import dev.burmalda.core.Module;
import dev.burmalda.core.Nav;
import dev.burmalda.core.Setting;
import dev.burmalda.core.Util;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.AbstractHorseEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

/** Feeds adult animals to breed them, shears sheep and culls extra adults above a per-species cap. */
public class AutoBreed extends Module {
    final Setting.Num radius = num("Radius", 14, 6, 30, 1);
    final Setting.Num cap = num("Max adults/species", 10, 2, 40, 1);
    final Setting.Bool shear = bool("Shear sheep", true);
    final Setting.Bool cull = bool("Cull extras", true);

    private final Map<Integer, Integer> cool = new HashMap<>();
    private int tickNo, navCd;
    private AnimalEntity chasing;

    public AutoBreed() { super("AutoBreed", Category.FARM); controller = true; }

    @Override public void onEnable() { cool.clear(); Nav.reset(); chasing = null; }
    @Override public void onDisable() { Nav.stop(); }

    private boolean useOn(AnimalEntity e, Predicate<ItemStack> item, boolean attack) {
        var p = mc.player;
        if (p.distanceTo(e) > 2.8) {
            if (Nav.failed) { cool.put(e.getId(), tickNo + 200); Nav.reset(); return true; }
            if (chasing != e || (!Nav.active && --navCd <= 0)) { chasing = e; navCd = 10; Nav.goNear(e.getPos(), 2.2, false); }
            return true;
        }
        Nav.stop();
        if (!Util.selectItem(item)) { cool.put(e.getId(), tickNo + 100); return false; }
        Util.lookAt(e.getPos().add(0, e.getHeight() * 0.5, 0));
        if (attack) {
            if (p.getAttackCooldownProgress(0.5f) < 0.9f) return true;
            mc.interactionManager.attackEntity(p, e);
        } else {
            mc.interactionManager.interactEntity(p, e, Hand.MAIN_HAND);
            cool.put(e.getId(), tickNo + 60);
        }
        p.swingHand(Hand.MAIN_HAND);
        return true;
    }

    @Override
    public void onTick() {
        tickNo++;
        var p = mc.player;
        mc.options.forwardKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);

        Map<EntityType<?>, List<AnimalEntity>> groups = new HashMap<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof AnimalEntity a) || a instanceof TameableEntity || a instanceof AbstractHorseEntity || !a.isAlive()) continue;
            if (p.distanceTo(a) > radius.get()) continue;
            groups.computeIfAbsent(a.getType(), k -> new ArrayList<>()).add(a);
        }
        if (groups.isEmpty()) return;

        if (shear.get() && Util.findHotbar(s -> s.isOf(Items.SHEARS)) >= 0) {
            for (List<AnimalEntity> l : groups.values()) for (AnimalEntity a : l)
                if (a instanceof SheepEntity sh && !sh.isBaby() && !sh.isSheared() && cool.getOrDefault(a.getId(), 0) < tickNo)
                    if (useOn(a, s -> s.isOf(Items.SHEARS), false)) return;
        }

        for (List<AnimalEntity> l : groups.values()) {
            List<AnimalEntity> ready = new ArrayList<>();
            int lovers = 0;
            for (AnimalEntity a : l) {
                if (a.isBaby()) continue;
                if (a.isInLove()) lovers++;
                else if (a.getBreedingAge() == 0 && cool.getOrDefault(a.getId(), 0) < tickNo) ready.add(a);
            }
            if (!ready.isEmpty() && ready.size() + lovers >= 2) {
                AnimalEntity a = ready.stream().min((x, y) -> Double.compare(p.distanceTo(x), p.distanceTo(y))).get();
                if (useOn(a, s -> a.isBreedingItem(s), false)) return;
            }
        }

        if (cull.get()) {
            for (List<AnimalEntity> l : groups.values()) {
                List<AnimalEntity> adults = new ArrayList<>();
                for (AnimalEntity a : l) if (!a.isBaby() && !a.isInLove()) adults.add(a);
                if (adults.size() > cap.i()) {
                    AnimalEntity v = adults.stream().min((x, y) -> Double.compare(p.distanceTo(x), p.distanceTo(y))).get();
                    if (useOn(v, s -> s.getItem() instanceof SwordItem, true)) return;
                }
            }
        }
        Nav.stop();
    }
}
