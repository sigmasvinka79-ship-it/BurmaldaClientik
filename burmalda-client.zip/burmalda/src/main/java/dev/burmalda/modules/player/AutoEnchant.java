package dev.burmalda.modules.player;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import dev.burmalda.core.Util;
import net.minecraft.block.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.EnchantmentScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** Stand next to an enchanting table: enchants every enchantable item in the inventory (needs lapis + XP). */
public class AutoEnchant extends Module {
    final Setting.Num option = num("Option (1-3)", 3, 1, 3, 1);
    final Setting.Num delay = num("Delay", 4, 1, 20, 1);
    private int cd, wait;

    public AutoEnchant() { super("AutoEnchant", Category.PLAYER); }

    @Override public void onEnable() { cd = 0; wait = 0; }

    private void finish(String why) {
        Util.msg(why);
        mc.player.closeHandledScreen();
        setEnabled(false);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (cd-- > 0) return;
        if (!(p.currentScreenHandler instanceof EnchantmentScreenHandler h)) {
            BlockPos t = null;
            BlockPos c = p.getBlockPos();
            for (BlockPos q : BlockPos.iterate(c.add(-4, -3, -4), c.add(4, 3, 4)))
                if (Util.state(q).isOf(Blocks.ENCHANTING_TABLE)) { t = q.toImmutable(); break; }
            if (t == null) { Util.msg("No enchanting table within reach."); setEnabled(false); return; }
            Util.useOnBlock(t, Direction.UP);
            cd = 12;
            return;
        }
        int id = h.syncId, opt = option.i() - 1;
        ItemStack in = h.getSlot(0).getStack();
        if (!in.isEmpty() && !in.isEnchantable()) { // finished item -> take it back
            mc.interactionManager.clickSlot(id, 0, 0, SlotActionType.QUICK_MOVE, p);
            cd = delay.i(); wait = 0;
            return;
        }
        if (in.isEmpty()) {
            for (int i = 2; i < h.slots.size(); i++) {
                ItemStack s = h.getSlot(i).getStack();
                if (!s.isEmpty() && s.isEnchantable()) {
                    mc.interactionManager.clickSlot(id, i, 0, SlotActionType.QUICK_MOVE, p);
                    cd = delay.i();
                    return;
                }
            }
            finish("Nothing left to enchant.");
            return;
        }
        ItemStack lap = h.getSlot(1).getStack();
        if (lap.isEmpty()) {
            for (int i = 2; i < h.slots.size(); i++) {
                if (h.getSlot(i).getStack().isOf(Items.LAPIS_LAZULI)) {
                    mc.interactionManager.clickSlot(id, i, 0, SlotActionType.QUICK_MOVE, p);
                    cd = delay.i();
                    return;
                }
            }
            finish("Out of lapis lazuli.");
            return;
        }
        int cost = h.enchantmentPower[opt];
        if (cost <= 0) { if (++wait > 20) finish("The table offers no enchantment for this item."); return; }
        if (p.experienceLevel < cost || lap.getCount() < opt + 1) { finish("Not enough XP levels or lapis."); return; }
        mc.interactionManager.clickButton(id, opt);
        cd = delay.i() + 2;
    }
}
