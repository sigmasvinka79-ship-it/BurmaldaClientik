package dev.burmalda.modules.player;

import dev.burmalda.core.Module;
import dev.burmalda.core.Util;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

/** While you hold attack on a block, picks the fastest tool from the hotbar. */
public class AutoTool extends Module {
    public AutoTool() { super("AutoTool", Category.PLAYER); }

    @Override
    public void onTick() {
        if (AutoEat.busy || !mc.options.attackKey.isPressed()) return;
        if (mc.crosshairTarget instanceof BlockHitResult bh && bh.getType() == HitResult.Type.BLOCK)
            Util.selectBestTool(Util.state(bh.getBlockPos()));
    }
}
