package dev.burmalda.modules.farm;

import dev.burmalda.core.Module;
import dev.burmalda.core.Nav;
import dev.burmalda.core.Setting;
import dev.burmalda.core.Util;
import dev.burmalda.modules.player.AutoEat;
import dev.burmalda.ui.Gfx;
import dev.burmalda.ui.Render3D;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.item.HoeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Auto-builder. Built-in plans (crop farms, sugar cane farm, shelter) or any vanilla structure .nbt placed in
 * .minecraft/burmalda/schematics (use .build load <name>). Walks around, places blocks bottom-up, hoes farmland,
 * uses water buckets and plants seeds. In creative it can give itself the needed blocks.
 */
public class Builder extends Module {
    public final Setting.Mode plan = mode("Plan", "Wheat farm", "Wheat farm", "Carrot farm", "Potato farm", "Beetroot farm", "Sugar cane farm", "Shelter", "File");
    final Setting.Num rot = num("Rotation", 0, 0, 3, 1);
    final Setting.Bool auto = bool("Auto start", true);
    final Setting.Bool creative = bool("Creative fill", true);
    final Setting.Bool clear = bool("Clear area", false);

    public static volatile String file = "";
    public static volatile boolean started;

    private Plans.Blueprint bp;
    private BlockPos origin, lookedFor;
    private List<Plans.Entry> todo = new ArrayList<>();
    private final Map<BlockPos, Integer> tries = new HashMap<>();
    private final Set<String> missing = new LinkedHashSet<>();
    private int cd, rebuild;

    public Builder() { super("Builder", Category.FARM); controller = true; }

    public static File dir() { File d = Plans.dir().toFile(); d.mkdirs(); return d; }

    @Override
    public void onEnable() {
        try {
            Plans.Blueprint b = plan.is("File") ? Plans.load(file) : Plans.builtin(plan.value);
            int q = (mc.player.getHorizontalFacing().getHorizontal() + rot.i()) % 4;
            bp = b.rotated(q);
        } catch (Exception e) {
            Util.msg("Не удалось загрузить схему «" + file + "»: положите .nbt в " + dir().getAbsolutePath());
            enabled = false;
            return;
        }
        Direction d = mc.player.getHorizontalFacing();
        BlockPos f = Util.feet();
        int depth = d.getAxis() == Direction.Axis.X ? bp.sx : bp.sz;
        int cx = f.getX() + d.getOffsetX() * (2 + depth / 2 + 1), cz = f.getZ() + d.getOffsetZ() * (2 + depth / 2 + 1);
        origin = new BlockPos(cx - bp.sx / 2, f.getY() - 1, cz - bp.sz / 2);
        tries.clear(); missing.clear(); todo = new ArrayList<>(); cd = 0; rebuild = 0; lookedFor = null;
        started = auto.get();
        Util.msg("План «" + Gfx_name() + "»: " + bp.list.size() + " блоков. " + (started ? "Строю!" : "Предпросмотр. Напиши .build start"));
    }
    private String Gfx_name() { return plan.is("File") ? file : plan.value; }

    @Override
    public void onDisable() { Nav.stop(); started = false; mc.options.backKey.setPressed(false); }

    // ---------- helpers ----------
    private static boolean isDirt(BlockState s) { return s.isOf(Blocks.DIRT) || s.isOf(Blocks.GRASS_BLOCK) || s.isOf(Blocks.DIRT_PATH); }
    private static Direction facing(BlockState s) {
        if (s.contains(Properties.HORIZONTAL_FACING)) return s.get(Properties.HORIZONTAL_FACING);
        if (s.contains(Properties.FACING)) return s.get(Properties.FACING);
        return null;
    }
    private static boolean skip(BlockState t) { return t.contains(Properties.DOUBLE_BLOCK_HALF) && t.get(Properties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.UPPER; }
    private static boolean matches(BlockState t, BlockState cur) {
        if (cur.getBlock() != t.getBlock()) return false;
        Direction f = facing(t);
        return f == null || f == facing(cur);
    }
    private static Item itemFor(BlockState s) { return s.getBlock() == Blocks.WATER ? Items.WATER_BUCKET : s.getBlock().asItem(); }
    private int count(Item it) {
        int n = 0;
        for (int i = 0; i < 36; i++) { ItemStack s = mc.player.getInventory().getStack(i); if (s.isOf(it)) n += s.getCount(); }
        return n;
    }
    private void bump(BlockPos p) { tries.merge(p, 1, Integer::sum); }

    private void recompute() {
        List<Plans.Entry> l = new ArrayList<>();
        for (Plans.Entry e : bp.list) {
            BlockPos wp = origin.add(e.pos());
            if (!Util.loaded(wp) || skip(e.state()) || tries.getOrDefault(wp, 0) >= 6) continue;
            BlockState cur = Util.state(wp), t = e.state();
            if (t.isAir()) { if (clear.get() && !cur.isAir()) l.add(e); continue; }
            if (matches(t, cur)) continue;
            l.add(e);
        }
        Vec3d pp = mc.player.getPos();
        l.sort(Comparator.comparingInt((Plans.Entry e) -> e.pos().getY()).thenComparingDouble(e -> Vec3d.ofCenter(origin.add(e.pos())).squaredDistanceTo(pp)));
        todo = l;
    }

    @Override
    public void onTick() {
        mc.options.backKey.setPressed(false);
        if (bp == null) return;
        if (rebuild-- <= 0) { rebuild = 10; recompute(); }
        if (!started || AutoEat.busy) return;
        if (cd-- > 0) return;
        if (todo.isEmpty()) {
            Util.msg("Постройка завершена!" + (missing.isEmpty() ? "" : " Не хватало: " + String.join(", ", missing)));
            setEnabled(false);
            return;
        }
        act(todo.get(0));
    }

    private boolean ensureItem(Item item, BlockPos wp) {
        if (Util.selectItem(s -> s.isOf(item))) return true;
        if (count(item) > 0) { cd = 2; return false; }
        var p = mc.player;
        if (creative.get() && p.isCreative()) {
            mc.interactionManager.clickCreativeStack(new ItemStack(item, 64), 36 + p.getInventory().selectedSlot);
            cd = 2;
            return false;
        }
        missing.add(item.getName().getString());
        tries.put(wp, 99);
        return false;
    }

    private void act(Plans.Entry e) {
        var p = mc.player;
        BlockPos wp = origin.add(e.pos());
        BlockState t = e.state(), cur = Util.state(wp);
        Vec3d c = Vec3d.ofCenter(wp);
        if (p.getEyePos().distanceTo(c) > 4.2) {
            if (Nav.failed) { tries.merge(wp, 3, Integer::sum); Nav.reset(); return; }
            if (!Nav.active) Nav.goNearEye(c, 3.8);
            return;
        }
        Nav.stop();
        if (!t.getCollisionShape(mc.world, wp).isEmpty() && p.getBoundingBox().intersects(new Box(wp))) { mc.options.backKey.setPressed(true); return; }
        Block tb = t.getBlock();
        boolean wrong = !cur.isAir() && cur.getBlock() != tb && !cur.isReplaceable() && !(tb == Blocks.FARMLAND && isDirt(cur));
        if (t.isAir() || wrong) {
            if (!Util.canBreak(wp)) { tries.put(wp, 99); return; }
            Util.selectBestTool(cur);
            Util.mine(wp);
            return;
        }
        if (tb == Blocks.FARMLAND) {
            if (isDirt(cur)) {
                if (!Util.selectItem(s -> s.getItem() instanceof HoeItem)) { missing.add("Мотыга"); tries.put(wp, 99); return; }
                Util.useOnBlock(wp, Direction.UP);
                bump(wp); cd = 4;
                return;
            }
            place(wp, Blocks.DIRT.getDefaultState());
            return;
        }
        place(wp, t);
    }

    private void place(BlockPos wp, BlockState state) {
        var p = mc.player;
        Item item = itemFor(state);
        if (item == Items.AIR) { tries.put(wp, 99); return; }
        if (!ensureItem(item, wp)) return;
        Vec3d eye = p.getEyePos();
        BlockPos C = null; Direction S = null; Vec3d hp = null;
        for (Direction d : new Direction[]{Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP}) {
            BlockPos n = wp.offset(d);
            BlockState ns = Util.state(n);
            if (ns.isAir() || !ns.getFluidState().isEmpty() || ns.isReplaceable() || !Util.solid(n)) continue;
            Direction side = d.getOpposite();
            Vec3d h = Vec3d.ofCenter(n).add(side.getOffsetX() * 0.5, side.getOffsetY() * 0.5, side.getOffsetZ() * 0.5);
            if (eye.distanceTo(h) > 4.4) continue;
            BlockHitResult r = Util.ray(eye, h.add(h.subtract(eye).normalize().multiply(0.05)));
            if (r.getType() != HitResult.Type.BLOCK || !r.getBlockPos().equals(n)) continue;
            C = n; S = side; hp = h;
            break;
        }
        if (C == null) { bump(wp); cd = 6; return; }
        boolean bucket = item == Items.WATER_BUCKET;
        if (!wp.equals(lookedFor)) { // first tick: aim, so the server knows our rotation
            Direction f = facing(state);
            if (f != null && !bucket) {
                Direction look = tries.getOrDefault(wp, 0) % 2 == 0 ? f.getOpposite() : f;
                if (look.getAxis().isHorizontal()) p.setYaw(look.asRotation());
                p.setPitch(look == Direction.UP ? -90 : look == Direction.DOWN ? 90 : 0);
            } else Util.lookAt(hp);
            lookedFor = wp;
            return;
        }
        lookedFor = null;
        if (bucket) mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        else { mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hp, S, C, false)); p.swingHand(Hand.MAIN_HAND); }
        bump(wp);
        cd = 3;
    }

    @Override
    public void onRender3D(WorldRenderContext ctx) {
        if (todo.isEmpty() || origin == null) return;
        Render3D.Through.begin(ctx);
        int n = 0;
        for (Plans.Entry e : todo) {
            if (n++ > 350) break;
            Render3D.Through.box(new Box(origin.add(e.pos())).contract(0.12), Gfx.alpha(Gfx.accent(n * 0.1), 150));
        }
        Render3D.Through.end();
    }
}
