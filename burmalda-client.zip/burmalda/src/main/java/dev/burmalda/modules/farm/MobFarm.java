package dev.burmalda.modules.farm;

import dev.burmalda.core.Module;
import dev.burmalda.core.ModuleManager;
import dev.burmalda.core.Setting;
import dev.burmalda.modules.combat.AutoWeapon;
import dev.burmalda.modules.combat.KillAura;
import dev.burmalda.modules.player.AutoEat;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.stream.StreamSupport;

/**
 * Rule-based mob farm bot: hunt -> loot -> retreat/heal. No pathfinding yet (straight-line movement),
 * so it is meant for open areas / mob farms / grinders.
 */
public class MobFarm extends Module {
    final Setting.Num retreatHp = num("Retreat HP", 8, 2, 19, 1);
    final Setting.Num resumeHp = num("Resume HP", 16, 4, 20, 1);
    final Setting.Num scan = num("Scan range", 16, 6, 32, 1);
    final Setting.Mode loot = mode("Loot", "Gunpowder", "Gunpowder", "Bone", "String", "Any");
    final Setting.Bool creeperSafe = bool("Creeper spacing", true);
    private boolean healing;

    public MobFarm() { super("MobFarm", Category.FARM); }

    @Override
    public void onEnable() {
        healing = false;
        for (Class<? extends Module> c : java.util.List.of(KillAura.class, AutoWeapon.class, AutoEat.class)) ModuleManager.get(c).setEnabled(true);
    }
    @Override public void onDisable() { release(); }

    private void release() {
        mc.options.forwardKey.setPressed(false); mc.options.backKey.setPressed(false);
        mc.options.jumpKey.setPressed(false); mc.options.sprintKey.setPressed(false);
    }
    private void face(Vec3d t) {
        Vec3d d = t.subtract(mc.player.getPos());
        mc.player.setYaw((float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90));
    }
    private boolean wants(Item i) {
        return switch (loot.value) {
            case "Gunpowder" -> i == Items.GUNPOWDER;
            case "Bone" -> i == Items.BONE;
            case "String" -> i == Items.STRING;
            default -> true;
        };
    }

    @Override
    public void onTick() {
        release();
        var p = mc.player;
        if (p.getHealth() <= retreatHp.get()) healing = true;
        else if (p.getHealth() >= resumeHp.get()) healing = false;

        Entity mob = StreamSupport.stream(mc.world.getEntities().spliterator(), false)
                .filter(e -> e instanceof Monster && e.isAlive() && p.distanceTo(e) <= scan.get())
                .min(Comparator.comparingDouble(p::distanceTo)).orElse(null);

        if (healing) { // run away from nearest hostile, AutoEat heals when safe
            if (mob != null && p.distanceTo(mob) < 10) {
                face(p.getPos().multiply(2).subtract(mob.getPos()));
                mc.options.forwardKey.setPressed(true); mc.options.sprintKey.setPressed(true);
            }
            return;
        }
        if (mob != null) {
            double d = p.distanceTo(mob);
            face(mob.getPos());
            if (mob instanceof CreeperEntity && creeperSafe.get() && d < 2.6) mc.options.backKey.setPressed(true);
            else if (d > 2.4) { mc.options.forwardKey.setPressed(true); mc.options.sprintKey.setPressed(true); }
            if (p.horizontalCollision) mc.options.jumpKey.setPressed(true);
            return;
        }
        ItemEntity item = StreamSupport.stream(mc.world.getEntities().spliterator(), false)
                .filter(e -> e instanceof ItemEntity ie && wants(ie.getStack().getItem()) && p.distanceTo(e) <= 14)
                .map(e -> (ItemEntity) e).min(Comparator.comparingDouble(p::distanceTo)).orElse(null);
        if (item != null) {
            face(item.getPos());
            p.setPitch(0);
            mc.options.forwardKey.setPressed(true); mc.options.sprintKey.setPressed(true);
            if (p.horizontalCollision) mc.options.jumpKey.setPressed(true);
        }
    }
}
