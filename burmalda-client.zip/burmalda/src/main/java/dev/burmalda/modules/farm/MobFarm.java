package dev.burmalda.modules.farm;

import dev.burmalda.core.Loot;
import dev.burmalda.core.Module;
import dev.burmalda.core.ModuleManager;
import dev.burmalda.core.Nav;
import dev.burmalda.core.Setting;
import dev.burmalda.core.Util;
import dev.burmalda.modules.combat.AutoShoot;
import dev.burmalda.modules.combat.AutoWeapon;
import dev.burmalda.modules.combat.KillAura;
import dev.burmalda.modules.player.AutoEat;
import dev.burmalda.modules.player.AutoLoot;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/**
 * Rule-based mob bot: walks to mobs with the A* pathfinder, fights (keeps distance from creepers),
 * retreats and heals when HP is low, then collects the chosen loot. Optional leash around the start point.
 */
public class MobFarm extends Module {
    final Setting.Num retreatHp = num("Retreat HP", 8, 2, 19, 1);
    final Setting.Num resumeHp = num("Resume HP", 16, 4, 20, 1);
    final Setting.Num scan = num("Scan range", 20, 6, 32, 1);
    final Setting.Num leash = num("Leash (0 = off)", 0, 0, 40, 1);
    final Setting.Mode loot = mode("Loot", "Gunpowder", "Gunpowder", "Bone", "String", "Any");
    final Setting.Bool creeperSafe = bool("Creeper spacing", true);
    final Setting.Bool useBow = bool("Use bow", false);

    private boolean healing;
    private Vec3d anchor;
    private int navCd, state;

    public MobFarm() { super("MobFarm", Category.FARM); controller = true; }

    @Override
    public void onEnable() {
        healing = false; anchor = mc.player.getPos(); state = 0; Nav.reset();
        for (Class<? extends Module> c : List.of(KillAura.class, AutoWeapon.class, AutoEat.class)) ModuleManager.get(c).setEnabled(true);
        if (useBow.get()) ModuleManager.get(AutoShoot.class).setEnabled(true);
    }
    @Override public void onDisable() { KillAura.pause = false; Nav.stop(); release(); }

    private void release() {
        mc.options.forwardKey.setPressed(false); mc.options.backKey.setPressed(false);
        mc.options.jumpKey.setPressed(false); mc.options.sprintKey.setPressed(false);
    }
    private void setState(int s) { if (s != state) { Nav.reset(); state = s; navCd = 0; } }

    private boolean wants(Item i) {
        if (AutoLoot.JUNK.contains(i) && !loot.is("Any")) return false;
        return switch (loot.value) {
            case "Gunpowder" -> i == Items.GUNPOWDER;
            case "Bone" -> i == Items.BONE;
            case "String" -> i == Items.STRING;
            default -> true;
        };
    }

    private Vec3d flee(Entity mob) {
        var p = mc.player;
        Vec3d away = p.getPos().subtract(mob.getPos()).multiply(1, 0, 1);
        if (away.lengthSquared() < 1e-6) away = new Vec3d(1, 0, 0);
        BlockPos c = BlockPos.ofFloored(p.getPos().add(away.normalize().multiply(10)));
        BlockPos best = null; double bd = 1e9;
        for (int dx = -3; dx <= 3; dx++) for (int dz = -3; dz <= 3; dz++) for (int dy = -3; dy <= 3; dy++) {
            BlockPos q = c.add(dx, dy, dz);
            if (!Util.standable(q)) continue;
            double d = q.getSquaredDistance(c);
            if (d < bd) { bd = d; best = q; }
        }
        return best == null ? p.getPos() : Vec3d.ofBottomCenter(best);
    }

    @Override
    public void onTick() {
        var p = mc.player;
        release();
        if (AutoEat.busy) { Nav.stop(); return; }
        if (p.getHealth() <= retreatHp.get()) healing = true;
        else if (p.getHealth() >= resumeHp.get()) healing = false;
        KillAura.pause = healing;

        Entity mob = null; double bd = scan.get() * scan.get();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof Monster) || e instanceof EndermanEntity || !e.isAlive()) continue;
            double d = p.squaredDistanceTo(e);
            if (d < bd) { bd = d; mob = e; }
        }

        if (healing) {
            setState(2);
            if (mob != null && p.distanceTo(mob) < 12) {
                if (!Nav.active && --navCd <= 0) { navCd = 20; Nav.goNear(flee(mob), 1.5, false); }
            } else Nav.stop();
            return;
        }
        if (mob != null) {
            double d = p.distanceTo(mob);
            if (d > 6.0) {
                setState(1);
                if (Nav.active && Nav.goal != null && Nav.goal.distanceTo(mob.getPos()) > 4) Nav.reset();
                if (!Nav.active && --navCd <= 0) { navCd = 8; Nav.goNear(mob.getPos(), 3.0, false); if (Nav.failed) Nav.reset(); }
                return;
            }
            setState(5);
            Nav.stop();
            Util.turnYaw(Util.yawTo(mob.getPos()), 50f);
            if (mob instanceof CreeperEntity && creeperSafe.get() && d < 2.6) mc.options.backKey.setPressed(true);
            else if (d > 2.2) { mc.options.forwardKey.setPressed(true); mc.options.sprintKey.setPressed(true); }
            if (p.horizontalCollision) mc.options.jumpKey.setPressed(true);
            return;
        }
        setState(3);
        if (Loot.collect(s -> wants(s.getItem()), 16)) return;
        if (leash.get() > 0 && p.getPos().distanceTo(anchor) > leash.get()) {
            setState(4);
            if (!Nav.active && --navCd <= 0) { navCd = 20; Nav.goNear(anchor, 2.0, false); if (Nav.failed) Nav.reset(); }
        }
    }
}
