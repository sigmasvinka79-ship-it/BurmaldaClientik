package dev.burmalda.modules.render;

import dev.burmalda.core.Module;
import dev.burmalda.ui.Gfx;
import dev.burmalda.ui.Render3D;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public class JumpCircles extends Module {
    private static final class Ring { final Vec3d pos; final long t; Ring(Vec3d p, long t) { pos = p; this.t = t; } }
    private final List<Ring> rings = new ArrayList<>();
    private boolean wasGround = true;

    public JumpCircles() { super("JumpCircles", Category.RENDER); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (wasGround && !p.isOnGround() && p.getVelocity().y > 0.2) rings.add(new Ring(p.getPos(), System.currentTimeMillis()));
        wasGround = p.isOnGround();
        long now = System.currentTimeMillis();
        rings.removeIf(r -> now - r.t > 900);
    }

    @Override
    public void onRender3D(WorldRenderContext ctx) {
        if (rings.isEmpty() || ctx.consumers() == null) return;
        var vc = ctx.consumers().getBuffer(RenderLayer.getLines());
        var e = ctx.matrixStack().peek();
        Vec3d cam = ctx.camera().getPos();
        long now = System.currentTimeMillis();
        for (Ring r : rings) {
            double k = (now - r.t) / 900.0, rad = 0.3 + k * 1.6;
            int a = (int) (255 * (1 - k));
            for (int i = 0; i < 32; i++) {
                double a1 = i * 2 * Math.PI / 32, a2 = (i + 1) * 2 * Math.PI / 32;
                Render3D.line(vc, e, cam,
                        r.pos.add(Math.cos(a1) * rad, 0.02, Math.sin(a1) * rad),
                        r.pos.add(Math.cos(a2) * rad, 0.02, Math.sin(a2) * rad), Gfx.alpha(Gfx.accent(i * 0.2), a));
            }
        }
    }
}
