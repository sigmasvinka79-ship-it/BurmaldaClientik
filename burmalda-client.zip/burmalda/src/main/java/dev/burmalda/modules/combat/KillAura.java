package dev.burmalda.modules.combat;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.Comparator;
import java.util.stream.StreamSupport;

public class KillAura extends Module {
    public static LivingEntity target;
    public static int sinceAttack = 1000;
    /** set by other modules (e.g. MobFarm while retreating) to stop attacking */
    public static boolean pause;

    final Setting.Num range = num("Range", 3.0, 2.0, 4.0, 0.1);
    final Setting.Num fov = num("FOV", 180, 30, 360, 10);
    final Setting.Num sharp = num("Sharpness", 0.92, 0.10, 1.0, 0.01); // required attack-cooldown fraction
    final Setting.Num jitter = num("Delay jitter", 0, 0, 4, 1);
    final Setting.Num rotSpeed = num("Rot speed", 60, 5, 180, 5);
    final Setting.Mode rotMode = mode("Rotation", "Smooth", "Smooth", "Snap", "Off");
    final Setting.Mode aimMode = mode("Aim point", "Center", "Center", "Nearest");
    final Setting.Mode priority = mode("Priority", "Distance", "Distance", "Health", "Angle");
    final Setting.Bool sticky = bool("Sticky target", true);
    final Setting.Bool walls = bool("Through walls", false);
    final Setting.Mode crit = mode("Crits", "Off", "Off", "Wait fall", "Auto jump");
    final Setting.Bool sprintReset = bool("Sprint reset", false);
    private boolean jumping;
    final Setting.Bool weaponOnly = bool("Weapon only", false);
    final Setting.Bool players = bool("Players", true);
    final Setting.Bool hostile = bool("Hostile", true);
    final Setting.Bool passive = bool("Passive", false);
    final Setting.Bool friendly = bool("Ignore pets/villagers", true);
    private int jitterLeft;

    public KillAura() { super("KillAura", Category.COMBAT); }

    @Override public void onDisable() { target = null; }

    private static double reach(ClientPlayerEntity p, Entity e) {
        Vec3d eye = p.getEyePos();
        Box b = e.getBoundingBox();
        return eye.distanceTo(new Vec3d(MathHelper.clamp(eye.x, b.minX, b.maxX), MathHelper.clamp(eye.y, b.minY, b.maxY), MathHelper.clamp(eye.z, b.minZ, b.maxZ)));
    }
    private static float yawTo(ClientPlayerEntity p, Vec3d t) {
        Vec3d d = t.subtract(p.getEyePos());
        return (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90);
    }
    private static float pitchTo(ClientPlayerEntity p, Vec3d t) {
        Vec3d d = t.subtract(p.getEyePos());
        return (float) -Math.toDegrees(Math.atan2(d.y, Math.hypot(d.x, d.z)));
    }
    private Vec3d aimPoint(ClientPlayerEntity p, Entity e) {
        Box b = e.getBoundingBox();
        Vec3d c = new Vec3d((b.minX + b.maxX) / 2, b.minY + e.getHeight() * 0.6, (b.minZ + b.maxZ) / 2);
        if (aimMode.is("Center")) return c;
        Vec3d eye = p.getEyePos();
        Vec3d near = new Vec3d(MathHelper.clamp(eye.x, b.minX, b.maxX), MathHelper.clamp(eye.y, b.minY + 0.1, b.maxY - 0.1), MathHelper.clamp(eye.z, b.minZ, b.maxZ));
        return near.lerp(c, 0.3);
    }
    private boolean valid(ClientPlayerEntity p, Entity e) {
        if (e == p || !(e instanceof LivingEntity le) || !le.isAlive() || e instanceof ArmorStandEntity) return false;
        if (reach(p, e) > range.get()) return false;
        Vec3d aim = aimPoint(p, e);
        if (Math.abs(MathHelper.wrapDegrees(yawTo(p, aim) - p.getYaw())) > fov.get() / 2) return false;
        if (!walls.get() && mc.world.raycast(new RaycastContext(p.getEyePos(), aim, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, p)).getType() != HitResult.Type.MISS) return false;
        if (e instanceof PlayerEntity) return players.get();
        if (e instanceof Monster) return hostile.get();
        if (friendly.get() && ((e instanceof TameableEntity t && t.isTamed()) || e instanceof VillagerEntity || e instanceof IronGolemEntity)) return false;
        return e instanceof MobEntity && passive.get();
    }
    private static boolean isWeapon(ItemStack s) {
        return s.getItem() instanceof SwordItem || s.getItem() instanceof AxeItem || s.isOf(Items.MACE) || s.isOf(Items.TRIDENT);
    }

    @Override
    public void onTick() {
        sinceAttack++;
        if (jumping) { mc.options.jumpKey.setPressed(false); jumping = false; }
        ClientPlayerEntity p = mc.player;
        if (mc.interactionManager == null) return;
        if (pause || (weaponOnly.get() && !isWeapon(p.getMainHandStack()))) { target = null; return; }

        if (!(sticky.get() && target != null && target.isAlive() && valid(p, target))) {
            Comparator<Entity> cmp = switch (priority.value) {
                case "Health" -> Comparator.comparingDouble(e -> ((LivingEntity) e).getHealth());
                case "Angle" -> Comparator.comparingDouble(e -> Math.abs(MathHelper.wrapDegrees(yawTo(p, e.getPos()) - p.getYaw())));
                default -> Comparator.comparingDouble(e -> reach(p, e));
            };
            target = StreamSupport.stream(mc.world.getEntities().spliterator(), false)
                    .filter(e -> valid(p, e)).min(cmp).map(e -> (LivingEntity) e).orElse(null);
        }
        if (target == null) return;
        if (crit.is("Auto jump") && p.isOnGround() && p.getAttackCooldownProgress(0.5f) >= sharp.get() - 0.15) { mc.options.jumpKey.setPressed(true); jumping = true; }

        Vec3d aim = aimPoint(p, target);
        float ty = yawTo(p, aim), tp = pitchTo(p, aim);
        if (!rotMode.is("Off")) {
            if (rotMode.is("Snap")) { p.setYaw(ty); p.setPitch(tp); }
            else {
                float s = (float) rotSpeed.get();
                p.setYaw(p.getYaw() + MathHelper.clamp(MathHelper.wrapDegrees(ty - p.getYaw()), -s, s));
                p.setPitch(p.getPitch() + MathHelper.clamp(tp - p.getPitch(), -s * 0.6f, s * 0.6f));
            }
        }
        if (p.isUsingItem() && !p.getActiveItem().isOf(Items.SHIELD)) return;
        if (!rotMode.is("Off") && Math.abs(MathHelper.wrapDegrees(ty - p.getYaw())) > 25) return;
        if (p.getAttackCooldownProgress(0.5f) < sharp.get()) return;
        if (jitterLeft > 0) { jitterLeft--; return; }
        if (!crit.is("Off") && !canCrit(p)) return;
        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
        sinceAttack = 0;
        if (sprintReset.get()) p.setSprinting(false);
        jitterLeft = jitter.i() == 0 ? 0 : (int) (Math.random() * (jitter.i() + 1));
    }

    public static boolean canCrit(ClientPlayerEntity p) {
        return p.fallDistance > 0 && !p.isOnGround() && !p.isClimbing() && !p.isTouchingWater()
                && !p.hasStatusEffect(StatusEffects.BLINDNESS) && !p.hasVehicle();
    }
}
