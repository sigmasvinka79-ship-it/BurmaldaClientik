package dev.burmalda.modules.combat;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.stream.StreamSupport;

public class KillAura extends Module {
    public static LivingEntity target;

    final Setting.Num range = num("Range", 3.0, 2.0, 4.0, 0.1);
    final Setting.Num fov = num("FOV", 180, 30, 360, 10);
    final Setting.Num sharp = num("Sharpness", 0.92, 0.10, 1.0, 0.01); // required attack-cooldown fraction
    final Setting.Num rotSpeed = num("Rot speed", 60, 5, 180, 5);
    final Setting.Mode rotMode = mode("Rotation", "Smooth", "Smooth", "Snap", "Off");
    final Setting.Mode priority = mode("Priority", "Distance", "Distance", "Health", "Angle");
    final Setting.Bool critsOnly = bool("Crits only", false);
    final Setting.Bool players = bool("Players", true);
    final Setting.Bool hostile = bool("Hostile", true);
    final Setting.Bool passive = bool("Passive", false);

    public KillAura() { super("KillAura", Category.COMBAT); }

    @Override public void onDisable() { target = null; }

    private static double reach(ClientPlayerEntity p, Entity e) {
        Vec3d eye = p.getEyePos();
        var b = e.getBoundingBox();
        return eye.distanceTo(new Vec3d(MathHelper.clamp(eye.x, b.minX, b.maxX), MathHelper.clamp(eye.y, b.minY, b.maxY), MathHelper.clamp(eye.z, b.minZ, b.maxZ)));
    }
    private static float yawTo(ClientPlayerEntity p, Vec3d t) {
        Vec3d d = t.subtract(p.getEyePos());
        return (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90);
    }
    private static float pitchTo(ClientPlayerEntity p, Vec3d t) {
        Vec3d d = t.subtract(p.getEyePos());
        return (float) -Math.toDegrees(Math.atan2(d.y, Math.hypot(d.x, d.z)));
    }
    private boolean valid(ClientPlayerEntity p, Entity e) {
        if (e == p || !(e instanceof LivingEntity le) || !le.isAlive() || e instanceof ArmorStandEntity) return false;
        if (reach(p, e) > range.get()) return false;
        float diff = Math.abs(MathHelper.wrapDegrees(yawTo(p, e.getPos().add(0, e.getHeight() * 0.6, 0)) - p.getYaw()));
        if (diff > fov.get() / 2) return false;
        if (e instanceof PlayerEntity) return players.get();
        if (e instanceof Monster) return hostile.get();
        return e instanceof MobEntity && passive.get();
    }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (mc.interactionManager == null) return;
        Comparator<Entity> cmp = switch (priority.value) {
            case "Health" -> Comparator.comparingDouble(e -> ((LivingEntity) e).getHealth());
            case "Angle" -> Comparator.comparingDouble(e -> Math.abs(MathHelper.wrapDegrees(yawTo(p, e.getPos()) - p.getYaw())));
            default -> Comparator.comparingDouble(e -> reach(p, e));
        };
        target = StreamSupport.stream(mc.world.getEntities().spliterator(), false)
                .filter(e -> valid(p, e)).min(cmp).map(e -> (LivingEntity) e).orElse(null);
        if (target == null) return;

        Vec3d aim = target.getPos().add(0, target.getHeight() * 0.6, 0);
        float ty = yawTo(p, aim), tp = pitchTo(p, aim);
        if (!rotMode.is("Off")) {
            if (rotMode.is("Snap")) { p.setYaw(ty); p.setPitch(tp); }
            else {
                float s = (float) rotSpeed.get();
                p.setYaw(p.getYaw() + MathHelper.clamp(MathHelper.wrapDegrees(ty - p.getYaw()), -s, s));
                p.setPitch(p.getPitch() + MathHelper.clamp(tp - p.getPitch(), -s * 0.6f, s * 0.6f));
            }
        }
        if (p.isUsingItem()) return;
        if (!rotMode.is("Off") && Math.abs(MathHelper.wrapDegrees(ty - p.getYaw())) > 25) return;
        if (p.getAttackCooldownProgress(0.5f) < sharp.get()) return;
        if (critsOnly.get() && !canCrit(p)) return;
        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
    }

    public static boolean canCrit(ClientPlayerEntity p) {
        return p.fallDistance > 0 && !p.isOnGround() && !p.isClimbing() && !p.isTouchingWater()
                && !p.hasStatusEffect(StatusEffects.BLINDNESS) && !p.hasVehicle();
    }
}
