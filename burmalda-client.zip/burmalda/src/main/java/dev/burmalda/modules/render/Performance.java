package dev.burmalda.modules.render;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import net.minecraft.client.option.ParticlesMode;

/**
 * Adaptive tuning: if FPS stays under the target it steps down options that are almost invisible (far entities, particle
 * count); when FPS recovers it steps back up. Restores your own values when switched off. For big gains install Sodium +
 * Lithium + FerriteCore + ImmediatelyFast + Entity Culling (see README).
 */
public class Performance extends Module {
    final Setting.Num target = num("Target FPS", 90, 30, 240, 5);
    final Setting.Bool particles = bool("Smart particles", true);
    final Setting.Bool entities = bool("Entity scaling", true);
    private int level, low, high, t;
    private double savedScale = 1.0;
    private ParticlesMode savedParticles = ParticlesMode.ALL;

    public Performance() { super("Performance", Category.MISC); }

    @Override
    public void onEnable() {
        level = 0; low = 0; high = 0; t = 0;
        savedScale = mc.options.getEntityDistanceScaling().getValue();
        savedParticles = mc.options.getParticles().getValue();
    }
    @Override public void onDisable() { if (mc.options != null) { apply(0); } }

    private void apply(int lv) {
        if (entities.get() || lv == 0) {
            double s = lv == 0 ? savedScale : lv == 1 ? Math.min(savedScale, 1.0) : lv == 2 ? Math.min(savedScale, 0.75) : Math.min(savedScale, 0.5);
            mc.options.getEntityDistanceScaling().setValue(s);
        }
        if (particles.get() || lv == 0) mc.options.getParticles().setValue(lv >= 3 ? ParticlesMode.MINIMAL : lv == 2 ? ParticlesMode.DECREASED : savedParticles);
    }

    @Override
    public void onTick() {
        if (++t < 20) return;
        t = 0;
        int fps = mc.getCurrentFps();
        if (fps < target.get() * 0.85) { low++; high = 0; } else if (fps > target.get() * 1.3) { high++; low = 0; } else { low = 0; high = 0; }
        if (low >= 3 && level < 3) { level++; low = 0; apply(level); }
        else if (high >= 10 && level > 0) { level--; high = 0; apply(level); }
    }
}
