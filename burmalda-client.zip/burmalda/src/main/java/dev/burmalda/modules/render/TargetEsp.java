package dev.burmalda.modules.render;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import dev.burmalda.ui.Gfx;
import dev.burmalda.ui.Render3D;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

public class TargetEsp extends Module {
    final Setting.Mode style = mode("Style", "Rings", "Rings", "Box");

    public TargetEsp() { super("TargetESP", Category.RENDER); }

    @Override
    public void onRender3D(WorldRenderContext ctx) {
        LivingEntity t = TargetHud.current();
        if (t == null || !t.isAlive() || ctx.consumers() == null) return;
        var vc = ctx.consumers().getBuffer(RenderLayer.getLines());
        var e = ctx.matrixStack().peek();
        Vec3d cam = ctx.camera().getPos();
        Vec3d pos = t.getLerpedPos(mc.getRenderTickCounter().getTickDelta(true));
        double h = t.getHeight(), r = t.getWidth() * 0.9 + 0.1, time = System.currentTimeMillis() / 1000.0;
        if (style.is("Box")) {
            Render3D.box(vc, e, cam, t.getBoundingBox().offset(pos.subtract(t.getPos())), Gfx.accent(0));
            return;
        }
        int seg = 40;
        for (int k = 0; k < 2; k++) {
            double y = pos.y + (Math.sin(time * 2.2 + k * Math.PI) + 1) / 2 * h;
            for (int i = 0; i < seg; i++) {
                double a1 = i * 2 * Math.PI / seg, a2 = (i + 1) * 2 * Math.PI / seg;
                Render3D.line(vc, e, cam,
                        new Vec3d(pos.x + Math.cos(a1) * r, y, pos.z + Math.sin(a1) * r),
                        new Vec3d(pos.x + Math.cos(a2) * r, y, pos.z + Math.sin(a2) * r), Gfx.accent(i * 0.2 + k));
            }
        }
    }
}
