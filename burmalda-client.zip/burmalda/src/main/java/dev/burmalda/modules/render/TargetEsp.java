package dev.burmalda.modules.render;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import dev.burmalda.ui.Gfx;
import dev.burmalda.ui.Render3D;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;

public class TargetEsp extends Module {
    final Setting.Mode style = mode("Style", "Rings", "Rings", "Box", "Spiral", "Marker");

    public TargetEsp() { super("TargetESP", Category.RENDER); }

    @Override
    public void onRender3D(WorldRenderContext ctx) {
        LivingEntity t = TargetHud.current();
        if (t == null || !t.isAlive() || ctx.consumers() == null) return;
        var vc = ctx.consumers().getBuffer(RenderLayer.getLines());
        var e = ctx.matrixStack().peek();
        Vec3d cam = ctx.camera().getPos();
        Vec3d pos = t.getLerpedPos(mc.getRenderTickCounter().getTickDelta(true));
        double h = t.getHeight(), r = t.getWidth() * 0.9 + 0.1, time = System.currentTimeMillis() / 1000.0;
        switch (style.value) {
            case "Box" -> Render3D.box(vc, e, cam, t.getBoundingBox().offset(pos.subtract(t.getPos())), Gfx.accent(0));
            case "Spiral" -> {
                Vec3d prev = null;
                for (int i = 0; i <= 64; i++) {
                    double f = i / 64.0, a = time * 3 + f * Math.PI * 6;
                    Vec3d q = new Vec3d(pos.x + Math.cos(a) * r, pos.y + f * h, pos.z + Math.sin(a) * r);
                    if (prev != null) Render3D.line(vc, e, cam, prev, q, Gfx.accent(i * 0.12));
                    prev = q;
                }
            }
            case "Marker" -> {
                Vec3d c = new Vec3d(pos.x, pos.y + h + 0.55 + Math.sin(time * 3) * 0.08, pos.z);
                double s = 0.2;
                Vec3d top = c.add(0, s * 1.5, 0), bot = c.add(0, -s * 1.5, 0);
                Vec3d[] q = new Vec3d[4];
                for (int i = 0; i < 4; i++) { double a = time * 2.5 + i * Math.PI / 2; q[i] = c.add(Math.cos(a) * s, 0, Math.sin(a) * s); }
                for (int i = 0; i < 4; i++) {
                    int col = Gfx.accent(i);
                    Render3D.line(vc, e, cam, top, q[i], col); Render3D.line(vc, e, cam, bot, q[i], col); Render3D.line(vc, e, cam, q[i], q[(i + 1) % 4], col);
                }
            }
            default -> {
                int seg = 40;
                for (int k = 0; k < 2; k++) {
                    double y = pos.y + (Math.sin(time * 2.2 + k * Math.PI) + 1) / 2 * h;
                    for (int i = 0; i < seg; i++) {
                        double a1 = i * 2 * Math.PI / seg, a2 = (i + 1) * 2 * Math.PI / seg;
                        Render3D.line(vc, e, cam, new Vec3d(pos.x + Math.cos(a1) * r, y, pos.z + Math.sin(a1) * r),
                                new Vec3d(pos.x + Math.cos(a2) * r, y, pos.z + Math.sin(a2) * r), Gfx.accent(i * 0.2 + k));
                    }
                }
            }
        }
    }
}
