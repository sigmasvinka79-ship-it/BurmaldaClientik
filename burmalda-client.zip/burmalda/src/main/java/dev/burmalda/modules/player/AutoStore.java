package dev.burmalda.modules.player;

import dev.burmalda.core.Config;
import dev.burmalda.core.Module;
import dev.burmalda.core.Nav;
import dev.burmalda.core.Setting;
import dev.burmalda.core.Util;
import net.minecraft.block.Blocks;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** When the inventory is nearly full, walks to a saved chest and deposits everything except tools, food and seeds. */
public class AutoStore extends Module {
    /** true while walking to / emptying into the chest; other controller modules pause. */
    public static boolean working;

    final Setting.Bool setChest = bool("Set chest (look at it)", false);
    final Setting.Num free = num("Deposit when free <=", 3, 1, 15, 1);
    private int cd, passes;

    public AutoStore() { super("AutoStore", Category.PLAYER); controller = true; }

    @Override public void onDisable() { working = false; Nav.stop(); }

    private static BlockPos chest() {
        String s = Config.get("chest");
        if (s == null) return null;
        try { String[] a = s.split(","); return new BlockPos(Integer.parseInt(a[0]), Integer.parseInt(a[1]), Integer.parseInt(a[2])); }
        catch (Exception e) { return null; }
    }
    private static boolean container(BlockPos p) {
        var s = Util.state(p);
        return s.isOf(Blocks.CHEST) || s.isOf(Blocks.TRAPPED_CHEST) || s.isOf(Blocks.BARREL);
    }

    private static final List<Item> SEEDS = List.of(Items.WHEAT_SEEDS, Items.BEETROOT_SEEDS, Items.CARROT, Items.POTATO, Items.NETHER_WART);
    private boolean keep(ItemStack s, Map<Item, Integer> seedLeft) {
        if (s.isDamageable() || s.contains(DataComponentTypes.FOOD) && !SEEDS.contains(s.getItem())) return true;
        if (s.isOf(Items.TORCH) || s.isOf(Items.WATER_BUCKET) || s.isOf(Items.BUCKET) || s.isOf(Items.LAVA_BUCKET) || s.isOf(Items.TOTEM_OF_UNDYING)
                || s.isOf(Items.ARROW) || s.isOf(Items.EXPERIENCE_BOTTLE) || s.isOf(Items.SHEARS) || s.isOf(Items.ENDER_PEARL)) return true;
        if (SEEDS.contains(s.getItem()) || s.isIn(ItemTags.SAPLINGS)) {
            int left = seedLeft.getOrDefault(s.getItem(), 1);
            seedLeft.put(s.getItem(), 0);
            return left > 0;
        }
        return false;
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (setChest.get()) {
            setChest.value = false;
            if (mc.crosshairTarget instanceof BlockHitResult bh && bh.getType() == HitResult.Type.BLOCK && container(bh.getBlockPos())) {
                BlockPos b = bh.getBlockPos();
                Config.put("chest", b.getX() + "," + b.getY() + "," + b.getZ());
                Util.msg("Storage chest saved: " + b.getX() + " " + b.getY() + " " + b.getZ());
            } else Util.msg("Look at a chest or barrel first.");
            return;
        }
        if (cd-- > 0) return;
        BlockPos chest = chest();
        if (chest == null) return;

        if (p.currentScreenHandler instanceof GenericContainerScreenHandler h) {
            working = true;
            Map<Item, Integer> seedLeft = new HashMap<>();
            int moved = 0;
            for (int i = h.getRows() * 9; i < h.slots.size() && moved < 6; i++) {
                ItemStack st = h.getSlot(i).getStack();
                if (st.isEmpty() || keep(st, seedLeft)) continue;
                mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, p);
                moved++;
            }
            if (moved == 0 || ++passes > 12) {
                if (passes > 12) Util.msg("Chest is full.");
                p.closeHandledScreen();
                working = false; passes = 0; cd = 200;
            } else cd = 2;
            return;
        }
        if (!working && Util.freeSlots() > free.i()) return;
        if (!container(chest)) { Util.msg("Saved chest is missing."); working = false; cd = 400; return; }
        working = true;
        Vec3d c = Vec3d.ofCenter(chest);
        if (p.getEyePos().distanceTo(c) > 4.2) {
            if (Nav.failed) { Util.msg("Can't reach the chest."); Nav.reset(); working = false; cd = 400; return; }
            if (!Nav.active) Nav.goNear(c, 3.8, true);
            return;
        }
        Nav.stop();
        Util.useOnBlock(chest, Direction.UP);
        cd = 8;
    }
}
