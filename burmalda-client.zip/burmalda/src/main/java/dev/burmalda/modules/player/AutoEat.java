package dev.burmalda.modules.player;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public class AutoEat extends Module {
    final Setting.Num hunger = num("Hunger <=", 14, 1, 19, 1);
    final Setting.Num heal = num("Heal below HP", 12, 2, 20, 1);
    private boolean eating;
    private int prevSlot = -1, ticks;

    public AutoEat() { super("AutoEat", Category.PLAYER); }

    @Override public void onDisable() { stop(); }

    private void stop() {
        mc.options.useKey.setPressed(false);
        if (eating && prevSlot >= 0 && mc.player != null) mc.player.getInventory().selectedSlot = prevSlot;
        eating = false; prevSlot = -1; ticks = 0;
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (eating) {
            ticks++;
            if (!p.isUsingItem() && ticks > 4) stop();
            else mc.options.useKey.setPressed(true);
            return;
        }
        boolean low = p.getHealth() <= heal.get();
        boolean hungry = p.getHungerManager().getFoodLevel() <= hunger.get();
        if (!low && !hungry) return;
        int best = -1, bestScore = -1;
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            var food = s.get(DataComponentTypes.FOOD);
            if (food == null) continue;
            boolean golden = s.isOf(Items.GOLDEN_APPLE) || s.isOf(Items.ENCHANTED_GOLDEN_APPLE);
            if (!food.canAlwaysEat() && p.getHungerManager().getFoodLevel() >= 20) continue;
            int sc = low ? (golden ? 100 : 0) + food.nutrition() : food.nutrition() - (golden ? 50 : 0);
            if (sc > bestScore) { bestScore = sc; best = i; }
        }
        if (best < 0) return;
        prevSlot = p.getInventory().selectedSlot;
        p.getInventory().selectedSlot = best;
        eating = true; ticks = 0;
        mc.options.useKey.setPressed(true);
    }
}
