package dev.burmalda.modules.render;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import dev.burmalda.modules.combat.KillAura;
import dev.burmalda.ui.Gfx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Hit marker, floating damage numbers and an attack-cooldown ring around the crosshair. */
public class CombatFx extends Module {
    private record Dmg(String text, long t, int dx) {}

    final Setting.Bool marker = bool("Hit marker", true);
    final Setting.Bool numbers = bool("Damage numbers", true);
    final Setting.Bool ring = bool("Cooldown ring", true);
    private final Map<Integer, Float> hp = new HashMap<>();
    private final List<Dmg> nums = new ArrayList<>();
    private long hitT;
    private int sweep;

    public CombatFx() { super("CombatFX", Category.RENDER); }

    @Override
    public void onTick() {
        Set<Integer> seen = new HashSet<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == mc.player || mc.player.distanceTo(e) > 16) continue;
            seen.add(e.getId());
            float h = le.getHealth();
            Float old = hp.put(e.getId(), h);
            if (old != null && h < old - 0.01f && (le == KillAura.target || le == mc.targetedEntity)) {
                hitT = System.currentTimeMillis();
                nums.add(new Dmg(String.format("-%.1f", old - h), hitT, (int) (Math.random() * 24) - 8));
            }
        }
        if (++sweep > 100) { sweep = 0; hp.keySet().retainAll(seen); }
    }

    @Override
    public void onRender2D(DrawContext c) {
        long now = System.currentTimeMillis();
        int cx = c.getScaledWindowWidth() / 2, cy = c.getScaledWindowHeight() / 2;
        if (marker.get() && now - hitT < 260) {
            int col = Gfx.alpha(0xFFFFFFFF, (int) (255 * (1 - (now - hitT) / 260.0)));
            for (int i = 4; i <= 9; i++) {
                c.fill(cx - i, cy - i, cx - i + 1, cy - i + 1, col);
                c.fill(cx + i, cy - i, cx + i + 1, cy - i + 1, col);
                c.fill(cx - i, cy + i, cx - i + 1, cy + i + 1, col);
                c.fill(cx + i, cy + i, cx + i + 1, cy + i + 1, col);
            }
        }
        if (numbers.get()) {
            nums.removeIf(d -> now - d.t() > 900);
            for (Dmg d : nums) {
                long age = now - d.t();
                int a = (int) (255 * (1 - age / 900.0));
                Gfx.text(c, d.text(), cx + 14 + d.dx(), cy - 10 - age * 0.03f, Gfx.alpha(Gfx.lerp(0xFFFF4040, 0xFFFFB347, age / 900f), a));
            }
        }
        if (ring.get()) {
            float pr = mc.player.getAttackCooldownProgress(0f);
            if (pr < 1f) {
                for (int i = 0; i < 24; i++) {
                    if (i / 24f >= pr) break;
                    double a = Math.toRadians(-90 + i * 15);
                    int x = cx + (int) Math.round(Math.cos(a) * 11), y = cy + (int) Math.round(Math.sin(a) * 11);
                    c.fill(x, y, x + 2, y + 2, Gfx.accent(i * 0.3));
                }
            }
        }
    }
}
