package dev.burmalda.modules.combat;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import dev.burmalda.core.Util;
import dev.burmalda.modules.player.AutoEat;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.HitResult;

/** Bow / trident aim assist with gravity + target-motion prediction. */
public class AutoShoot extends Module {
    final Setting.Num minRange = num("Min range", 5, 3, 10, 1);
    final Setting.Num maxRange = num("Max range", 32, 10, 60, 1);
    final Setting.Bool players = bool("Players", false);
    final Setting.Bool hostile = bool("Hostile", true);
    final Setting.Bool swap = bool("Auto swap to bow", true);
    private boolean charging;
    private int cd;

    public AutoShoot() { super("AutoShoot", Category.COMBAT); }

    @Override public void onDisable() { if (charging) mc.options.useKey.setPressed(false); charging = false; }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        if (cd > 0) { cd--; return; }
        if (AutoEat.busy) return;
        LivingEntity t = null; double bd = maxRange.get() * maxRange.get();
        for (Entity e : mc.world.getEntities()) {
            if (e == p || !(e instanceof LivingEntity le) || !le.isAlive() || dev.burmalda.core.Friends.is(e)) continue;
            boolean ok = (e instanceof PlayerEntity && players.get()) || (e instanceof Monster && hostile.get());
            if (!ok) continue;
            double d = p.squaredDistanceTo(e);
            if (d < bd && d >= minRange.get() * minRange.get()) {
                Vec3d to = e.getPos().add(0, e.getHeight() * 0.5, 0);
                if (mc.world.raycast(new RaycastContext(p.getEyePos(), to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p)).getType() == HitResult.Type.MISS) { bd = d; t = le; }
            }
        }
        ItemStack hand = p.getMainHandStack();
        boolean bow = hand.isOf(Items.BOW), tri = hand.isOf(Items.TRIDENT);
        if (t == null || (KillAura.target != null && p.distanceTo(KillAura.target) < 4.5)) {
            if (charging) { mc.options.useKey.setPressed(false); charging = false; }
            return;
        }
        if (!bow && !tri) {
            if (swap.get() && !p.isUsingItem()) { int h = Util.findHotbar(s -> s.isOf(Items.BOW)); if (h >= 0) p.getInventory().selectedSlot = h; }
            return;
        }
        double speed = bow ? 3.0 : 2.5;
        int need = bow ? 20 : 10;
        Vec3d pos = t.getPos().add(0, t.getHeight() * 0.5, 0);
        Vec3d vel = t.getPos().subtract(new Vec3d(t.prevX, t.prevY, t.prevZ));
        float[] a = solve(p.getEyePos(), pos, vel, speed);
        if (a == null) return;
        p.setYaw(a[0]); p.setPitch(a[1]);
        mc.options.useKey.setPressed(true);
        charging = true;
        if (p.getItemUseTime() >= need) { mc.options.useKey.setPressed(false); charging = false; cd = 4; }
    }

    /** Returns {yaw, pitch} to hit a target moving with `vel` (blocks/tick), simulating drag 0.99 and gravity 0.05. */
    static float[] solve(Vec3d from, Vec3d pos, Vec3d vel, double speed) {
        Vec3d pred = pos;
        double bestAng = 0;
        for (int it = 0; it < 4; it++) {
            double dxz = Math.hypot(pred.x - from.x, pred.z - from.z), dy = pred.y - from.y;
            double bestErr = 1e9, ang = 0, tt = 0;
            for (double a = -45; a <= 80; a += 0.5) {
                double r = Math.toRadians(a), vx = speed * Math.cos(r), vy = speed * Math.sin(r), x = 0, y = 0;
                int k = 0; boolean hit = false; double yAt = 0;
                while (k < 160) {
                    double nx = x + vx, ny = y + vy; k++;
                    if (nx >= dxz) { double f = (dxz - x) / (nx - x); yAt = y + (ny - y) * f; hit = true; break; }
                    x = nx; y = ny; vx *= 0.99; vy = vy * 0.99 - 0.05;
                }
                if (!hit) continue;
                double err = Math.abs(yAt - dy);
                if (err < bestErr) { bestErr = err; ang = a; tt = k; }
            }
            if (bestErr > 1e8) return null;
            bestAng = ang;
            pred = pos.add(vel.multiply(tt));
        }
        Vec3d d = pred.subtract(from);
        return new float[]{(float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90), (float) -bestAng};
    }
}
