package dev.burmalda.modules.world;

import com.mojang.datafixers.util.Pair;
import dev.burmalda.core.Module;
import dev.burmalda.core.Nav;
import dev.burmalda.core.Setting;
import dev.burmalda.core.Util;
import dev.burmalda.ui.Gfx;
import dev.burmalda.ui.Render3D;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntryList;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.Structure;

import java.util.ArrayList;
import java.util.List;

/**
 * Locates structures through the integrated server (no cheats / commands needed), then shows an arrow,
 * a tracer line and a light beam. Optionally walks there.
 */
public class StructureFinder extends Module {
    final Setting.Mode what = mode("Structure", "Village", "Village", "Stronghold", "Mansion", "Monument", "Fortress", "Bastion",
            "AncientCity", "TrialChambers", "Mineshaft", "Outpost", "DesertTemple", "JungleTemple", "SwampHut", "Igloo", "EndCity");
    final Setting.Bool walk = bool("Walk there", false);

    public static volatile BlockPos found;
    private static volatile boolean searching;
    private String label = "";
    private int announced;

    public StructureFinder() { super("StructureFinder", Category.WORLD); }

    private static String[] ids(String sel) {
        return switch (sel) {
            case "Village" -> new String[]{"village_plains", "village_desert", "village_savanna", "village_snowy", "village_taiga"};
            case "Stronghold" -> new String[]{"stronghold"};
            case "Mansion" -> new String[]{"mansion"};
            case "Monument" -> new String[]{"monument"};
            case "Fortress" -> new String[]{"fortress"};
            case "Bastion" -> new String[]{"bastion_remnant"};
            case "AncientCity" -> new String[]{"ancient_city"};
            case "TrialChambers" -> new String[]{"trial_chambers"};
            case "Mineshaft" -> new String[]{"mineshaft", "mineshaft_mesa"};
            case "Outpost" -> new String[]{"pillager_outpost"};
            case "DesertTemple" -> new String[]{"desert_pyramid"};
            case "JungleTemple" -> new String[]{"jungle_pyramid"};
            case "SwampHut" -> new String[]{"swamp_hut"};
            case "Igloo" -> new String[]{"igloo"};
            default -> new String[]{"end_city"};
        };
    }

    @Override
    public void onEnable() {
        found = null; announced = 0; label = what.value; controller = walk.get();
        var server = mc.getServer();
        if (server == null) { Util.msg("Structure search works in singleplayer worlds only."); enabled = false; return; }
        RegistryKey<World> dim = mc.world.getRegistryKey();
        BlockPos origin = mc.player.getBlockPos();
        String[] ids = ids(what.value);
        searching = true;
        Util.msg("Searching for " + what.value + "...");
        server.execute(() -> {
            try {
                ServerWorld sw = server.getWorld(dim);
                if (sw == null) return;
                Registry<Structure> reg = sw.getRegistryManager().get(RegistryKeys.STRUCTURE);
                List<RegistryEntry<Structure>> entries = new ArrayList<>();
                for (String id : ids) reg.getEntry(RegistryKey.of(RegistryKeys.STRUCTURE, Identifier.of("minecraft", id))).ifPresent(entries::add);
                if (entries.isEmpty()) { mc.execute(() -> Util.msg(what.value + " doesn't generate in this dimension.")); return; }
                Pair<BlockPos, RegistryEntry<Structure>> r = sw.getChunkManager().getChunkGenerator()
                        .locateStructure(sw, RegistryEntryList.of(entries), origin, 100, false);
                if (r == null) { mc.execute(() -> Util.msg("Nothing found within 100 chunks.")); return; }
                found = r.getFirst();
            } catch (Throwable t) {
                t.printStackTrace();
                mc.execute(() -> Util.msg("Search failed: " + t.getClass().getSimpleName()));
            } finally { searching = false; }
        });
    }

    @Override public void onDisable() { found = null; searching = false; if (controller) Nav.stop(); controller = false; }

    public static Vec3d targetPos() {
        BlockPos f = found;
        if (f == null) return null;
        double y = mc.player.getY();
        try { if (Util.loaded(f)) y = mc.world.getTopY(Heightmap.Type.MOTION_BLOCKING, f.getX(), f.getZ()); } catch (Throwable ignored) {}
        return new Vec3d(f.getX() + 0.5, y, f.getZ() + 0.5);
    }

    @Override
    public void onTick() {
        Vec3d t = targetPos();
        if (t == null) return;
        if (announced == 0) {
            announced = 1;
            Util.msg(label + " at X " + (int) t.x + "  Z " + (int) t.z + "  (" + (int) Math.hypot(t.x - mc.player.getX(), t.z - mc.player.getZ()) + " m)");
            if (walk.get()) Nav.travel(t, 6.0);
        }
        if (walk.get()) {
            if (Nav.arrived) { Util.msg("You have arrived."); setEnabled(false); }
            else if (Nav.failed) { Util.msg("Walking stopped: no path found. Follow the arrow."); controller = false; Nav.reset(); }
        } else if (Math.hypot(t.x - mc.player.getX(), t.z - mc.player.getZ()) < 6) { Util.msg("You have arrived."); setEnabled(false); }
    }

    @Override
    public void onRender2D(DrawContext c) {
        Vec3d t = targetPos();
        if (t == null && searching) Gfx.text(c, "Searching " + what.value + "...", c.getScaledWindowWidth() / 2f - 40, 12, 0xFFB5B5C4);
    }

    @Override
    public void onRender3D(WorldRenderContext ctx) {
        Vec3d t = targetPos();
        if (t == null) return;
        Render3D.Through.begin(ctx);
        Render3D.Through.line(t.add(0, -10, 0), t.add(0, 90, 0), Gfx.accent(0));
        Render3D.Through.line(ctx.camera().getPos().add(0, -0.4, 0).add(mc.player.getRotationVec(1f).multiply(0.8)), t.add(0, 1, 0), Gfx.alpha(Gfx.accent(1), 160));
        Render3D.Through.end();
    }
}
