package dev.burmalda.modules.player;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import dev.burmalda.core.Util;
import dev.burmalda.modules.combat.KillAura;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Throws experience bottles at your feet while worn/held Mending items are damaged. */
public class AutoRepair extends Module {
    final Setting.Bool mendingOnly = bool("Only Mending items", true);
    private int cd;

    public AutoRepair() { super("AutoRepair", Category.PLAYER); }

    private boolean needs(ItemStack s) {
        if (!s.isDamaged() || s.isOf(Items.EXPERIENCE_BOTTLE)) return false;
        if (!mendingOnly.get()) return true;
        var e = s.get(DataComponentTypes.ENCHANTMENTS);
        return e != null && e.toString().toLowerCase().contains("mending");
    }

    @Override
    public void onTick() {
        var p = mc.player;
        if (cd-- > 0 || AutoEat.busy || KillAura.target != null) return;
        boolean need = false;
        for (EquipmentSlot sl : EquipmentSlot.values()) if (needs(p.getEquippedStack(sl))) { need = true; break; }
        if (!need) return;
        if (!Util.selectItem(s -> s.isOf(Items.EXPERIENCE_BOTTLE))) return;
        p.setPitch(90);
        mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
        cd = 4;
    }
}
