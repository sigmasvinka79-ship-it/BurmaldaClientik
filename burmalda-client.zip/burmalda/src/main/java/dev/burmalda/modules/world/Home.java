package dev.burmalda.modules.world;

import dev.burmalda.core.Config;
import dev.burmalda.core.Module;
import dev.burmalda.core.Nav;
import dev.burmalda.core.Setting;
import dev.burmalda.core.Util;
import dev.burmalda.ui.Gfx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Vec3d;

/** Enable to walk back to the saved home point. First use (or "Set home here" ON) saves your current position. */
public class Home extends Module {
    final Setting.Bool set = bool("Set home here", false);

    public Home() { super("Home", Category.WORLD); controller = true; }

    private static Vec3d home() {
        String s = Config.get("home");
        if (s == null) return null;
        try { String[] a = s.split(","); return new Vec3d(Double.parseDouble(a[0]), Double.parseDouble(a[1]), Double.parseDouble(a[2])); }
        catch (Exception e) { return null; }
    }

    @Override
    public void onEnable() {
        Vec3d h = home();
        if (set.get() || h == null) {
            var p = mc.player;
            Config.put("home", p.getX() + "," + p.getY() + "," + p.getZ());
            set.value = false;
            Util.msg("Home saved at " + (int) p.getX() + " " + (int) p.getY() + " " + (int) p.getZ());
            enabled = false;
            return;
        }
        Util.msg("Walking home...");
        Nav.travel(h, 2.0);
    }
    @Override public void onDisable() { Nav.stop(); }

    @Override
    public void onTick() {
        if (Nav.arrived) { Util.msg("You are home."); setEnabled(false); }
        else if (Nav.failed) { Util.msg("Can't find a way home."); setEnabled(false); }
    }

    @Override
    public void onRender2D(DrawContext c) {
        Vec3d h = home();
        if (h != null) Gfx.arrow(c, h, "Home");
    }
}
