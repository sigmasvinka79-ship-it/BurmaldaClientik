package dev.burmalda.modules.combat;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import dev.burmalda.core.Util;
import dev.burmalda.modules.player.AutoEat;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** Auto-swap: best hotbar weapon for the current target; mace when falling; axe against raised shields. */
public class AutoWeapon extends Module {
    final Setting.Bool mace = bool("Mace on fall", true);
    final Setting.Num fall = num("Mace min fall", 1.5, 0.5, 6, 0.5);
    final Setting.Bool shield = bool("Shield breaker", true);

    public AutoWeapon() { super("AutoSwap", Category.COMBAT); }

    static double damage(ItemStack s) {
        double d = 0;
        for (var e : s.getOrDefault(DataComponentTypes.ATTRIBUTE_MODIFIERS, AttributeModifiersComponent.DEFAULT).modifiers())
            if (e.attribute().equals(EntityAttributes.GENERIC_ATTACK_DAMAGE) && e.slot() == AttributeModifierSlot.MAINHAND) d += e.modifier().value();
        return d;
    }

    @Override
    public void onTick() {
        if (KillAura.target == null || AutoEat.busy) return;
        var inv = mc.player.getInventory();
        int best = -1; double bestScore = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isEmpty()) continue;
            double sc = damage(s);
            if (mace.get() && s.isOf(Items.MACE)) sc = mc.player.fallDistance >= fall.get() ? 100 : 0;
            if (sc > bestScore) { bestScore = sc; best = i; }
        }
        if (shield.get() && KillAura.target instanceof PlayerEntity pe && pe.isBlocking()) {
            int a = Util.findHotbar(s -> s.getItem() instanceof AxeItem);
            if (a >= 0) best = a;
        }
        if (best >= 0 && inv.selectedSlot != best) inv.selectedSlot = best;
    }
}
