package dev.burmalda.modules.combat;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

/** Auto-swap: selects the best hotbar weapon when KillAura has a target. Mace when falling. */
public class AutoWeapon extends Module {
    final Setting.Bool mace = bool("Mace on fall", true);
    final Setting.Num fall = num("Mace min fall", 1.5, 0.5, 6, 0.5);

    public AutoWeapon() { super("AutoSwap", Category.COMBAT); }

    static double damage(ItemStack s) {
        double d = 0;
        for (var e : s.getOrDefault(DataComponentTypes.ATTRIBUTE_MODIFIERS, AttributeModifiersComponent.DEFAULT).modifiers())
            if (e.attribute().equals(EntityAttributes.GENERIC_ATTACK_DAMAGE)
                    && e.slot() == net.minecraft.component.type.AttributeModifierSlot.MAINHAND) d += e.modifier().value();
        return d;
    }

    @Override
    public void onTick() {
        if (KillAura.target == null) return;
        var inv = mc.player.getInventory();
        int best = -1; double bestScore = 0;
        for (int i = 0; i < 9; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isEmpty()) continue;
            double sc = damage(s);
            if (mace.get() && s.isOf(Items.MACE)) sc = mc.player.fallDistance >= fall.get() ? 100 : 0;
            if (sc > bestScore) { bestScore = sc; best = i; }
        }
        if (best >= 0 && inv.selectedSlot != best) inv.selectedSlot = best;
    }
}
