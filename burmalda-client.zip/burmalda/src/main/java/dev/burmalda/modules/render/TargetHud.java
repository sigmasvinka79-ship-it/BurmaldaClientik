package dev.burmalda.modules.render;

import dev.burmalda.core.Module;
import dev.burmalda.modules.combat.KillAura;
import dev.burmalda.ui.Faces;
import dev.burmalda.ui.Gfx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

import java.util.Locale;

public class TargetHud extends Module {
    private float shown;
    private LivingEntity last;

    public TargetHud() { super("TargetHUD", Category.RENDER); }

    public static LivingEntity current() {
        if (KillAura.target != null) return KillAura.target;
        if (net.minecraft.client.MinecraftClient.getInstance().targetedEntity instanceof LivingEntity le) return le;
        return null;
    }

    @Override
    public void onRender2D(DrawContext c) {
        LivingEntity t = current();
        if (t == null || !t.isAlive()) { last = null; return; }
        if (t != last) { shown = t.getHealth(); last = t; }
        shown = MathHelper.lerp(0.12f, shown, t.getHealth());
        int w = 150, h = 44, x = c.getScaledWindowWidth() / 2 + 28, y = c.getScaledWindowHeight() / 2 + 20;
        Gfx.rrect(c, x - 1, y - 1, w + 2, h + 2, 11, 0x40000000);
        Gfx.rrect(c, x, y, w, h, 10, 0xEB0E0E12);
        Faces.draw(c, t, x + 6, y + 6, 32);
        String name = t.getName().getString();
        Gfx.btext(c, name, x + 44, y + 7, 0xFFFFFFFF);
        String hp = String.format(Locale.ROOT, "%.1f", t.getHealth());
        Gfx.text(c, hp, x + w - 8 - Gfx.w(hp), y + 7, 0xFF9A9AAA);
        float frac = MathHelper.clamp(shown / t.getMaxHealth(), 0, 1);
        Gfx.rrect(c, x + 44, y + 22, w - 52, 6, 3, 0xFF22222B);
        Gfx.rrect(c, x + 44, y + 22, Math.max(6, (int) ((w - 52) * frac)), 6, 3, Gfx.accent(0));
        String d = String.format(Locale.ROOT, "%.1f m", mc.player.distanceTo(t));
        Gfx.text(c, d, x + 44, y + 31, 0xFF7A7A8C);
        if (t.getAbsorptionAmount() > 0) {
            String a = "+" + (int) t.getAbsorptionAmount();
            Gfx.text(c, a, x + w - 8 - Gfx.w(a), y + 31, 0xFFFFD84A);
        }
    }
}
