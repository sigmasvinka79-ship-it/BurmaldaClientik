package dev.burmalda.modules.render;

import dev.burmalda.core.Module;
import dev.burmalda.modules.combat.KillAura;
import dev.burmalda.ui.Gfx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

public class TargetHud extends Module {
    private float shown;
    private LivingEntity last;

    public TargetHud() { super("TargetHUD", Category.RENDER); }

    public static LivingEntity current() {
        if (KillAura.target != null) return KillAura.target;
        if (mc_target() instanceof LivingEntity le) return le;
        return null;
    }
    private static net.minecraft.entity.Entity mc_target() { return net.minecraft.client.MinecraftClient.getInstance().targetedEntity; }

    @Override
    public void onRender2D(DrawContext c) {
        LivingEntity t = current();
        if (t == null || !t.isAlive()) { last = null; return; }
        if (t != last) { shown = t.getHealth(); last = t; }
        shown = MathHelper.lerp(0.12f, shown, t.getHealth());
        int x = c.getScaledWindowWidth() / 2 + 24, y = c.getScaledWindowHeight() / 2 + 24, w = 138, h = 40;
        Gfx.rrect(c, x - 1, y - 1, w + 2, h + 2, 5, 0x55000000);
        Gfx.rrect(c, x, y, w, h, 5, 0xE0121217);
        Gfx.text(c, t.getName().getString(), x + 8, y + 7, 0xFFFFFFFF);
        String hp = String.format("%.1f / %.1f", t.getHealth(), t.getMaxHealth());
        Gfx.text(c, hp, x + w - 8 - Gfx.w(hp), y + 7, 0xFF9A9AAA);
        float frac = MathHelper.clamp(shown / t.getMaxHealth(), 0, 1);
        Gfx.rrect(c, x + 8, y + 22, w - 16, 6, 3, 0xFF22222B);
        int bw = Math.max(4, (int) ((w - 16) * frac));
        Gfx.rrect(c, x + 8, y + 22, bw, 6, 3, Gfx.accent(0));
        if (t.getAbsorptionAmount() > 0) Gfx.text(c, "+" + (int) t.getAbsorptionAmount(), x + 8, y + 30, 0xFFFFD84A);
        String d = String.format("%.1f m", mc.player.distanceTo(t));
        Gfx.text(c, d, x + w - 8 - Gfx.w(d), y + 30, 0xFF7A7A8C);
    }
}
