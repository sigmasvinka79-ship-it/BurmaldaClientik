package dev.burmalda.modules.render;

import dev.burmalda.core.HudLayout;
import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import dev.burmalda.modules.combat.KillAura;
import dev.burmalda.ui.Faces;
import dev.burmalda.ui.Gfx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;

import java.util.Locale;

/** Four target panels: Nursultan-like (Classic), Compact (blue glass bar), Circle (dark card with HP ring + items), Minimal. */
public class TargetHud extends Module {
    final Setting.Mode style = mode("Style", "Classic", "Classic", "Compact", "Circle", "Minimal");
    private float shown;
    private LivingEntity last;

    public TargetHud() { super("TargetHUD", Category.RENDER); }

    public static LivingEntity current() {
        if (KillAura.target != null) return KillAura.target;
        if (net.minecraft.client.MinecraftClient.getInstance().targetedEntity instanceof LivingEntity le) return le;
        return null;
    }

    private static void smallItem(DrawContext c, ItemStack s, int x, int y) {
        c.getMatrices().push();
        c.getMatrices().translate(x, y, 0);
        c.getMatrices().scale(0.75f, 0.75f, 1f);
        c.drawItem(s, 0, 0);
        c.getMatrices().pop();
    }

    @Override
    public void onRender2D(DrawContext c) {
        LivingEntity t = current();
        if (t == null && HudLayout.editing) t = mc.player;
        if (t == null || !t.isAlive()) { last = null; return; }
        if (t != last) { shown = t.getHealth(); last = t; }
        shown = MathHelper.lerp(0.12f, shown, t.getHealth());
        float frac = MathHelper.clamp(shown / t.getMaxHealth(), 0, 1);
        String name = t.getName().getString();
        String hp = String.format(Locale.ROOT, "%.1f", t.getHealth());
        int sw = c.getScaledWindowWidth(), sh = c.getScaledWindowHeight();
        int bx = sw / 2 + 28, by = sh / 2 + 20;

        switch (style.value) {
            case "Compact" -> {
                int w = 150, h = 34;
                x(c, "target", bx, by, w, h);
                int[] o = pos(bx, by);
                Gfx.rrect(c, o[0], o[1], w, h, 10, 0xB0485A78);
                Faces.draw(c, t, o[0] + 4, o[1] + 4, 26);
                Gfx.btext(c, name, o[0] + 36, o[1] + 5, 0xFFFFFFFF);
                Gfx.text(c, hp + " HP", o[0] + 36, o[1] + 16, 0xFFC8D4E8);
                Gfx.rrect(c, o[0] + 36, o[1] + 27, w - 44, 3, 1, 0x55FFFFFF);
                Gfx.rrect(c, o[0] + 36, o[1] + 27, Math.max(3, (int) ((w - 44) * frac)), 3, 1, 0xFFF2F6FF);
            }
            case "Circle" -> {
                int w = 150, h = 50;
                x(c, "target", bx, by, w, h);
                int[] o = pos(bx, by);
                Gfx.rrect(c, o[0] - 1, o[1] - 1, w + 2, h + 2, 11, 0x40000000);
                Gfx.rrect(c, o[0], o[1], w, h, 10, 0xEB17161C);
                Faces.draw(c, t, o[0] + 6, o[1] + 6, 30);
                Gfx.btext(c, name, o[0] + 42, o[1] + 6, 0xFFFFFFFF);
                EquipmentSlot[] sl = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND};
                for (int i = 0; i < 6; i++) {
                    int ix = o[0] + 42 + i * 12, iy = o[1] + 24;
                    Gfx.rrect(c, ix, iy, 11, 11, 3, 0xFF22212A);
                    ItemStack st = t.getEquippedStack(sl[i]);
                    if (!st.isEmpty()) smallItem(c, st, ix, iy - 1);
                }
                int rx = o[0] + w - 22, ry = o[1] + 25;
                for (int i = 0; i < 20; i++) {
                    double a = Math.toRadians(-90 + i * 18);
                    int px = rx + (int) Math.round(Math.cos(a) * 9), py = ry + (int) Math.round(Math.sin(a) * 9);
                    c.fill(px, py, px + 2, py + 2, i / 20f < frac ? Gfx.accent(i * 0.3) : 0xFF2A2933);
                }
                String pc = String.valueOf((int) (frac * 100));
                Gfx.text(c, pc, rx + 1 - Gfx.w(pc) / 2f, ry - 3, 0xFFFFFFFF);
            }
            case "Minimal" -> {
                int w = 120, h = 24;
                x(c, "target", bx, by, w, h);
                int[] o = pos(bx, by);
                Gfx.pill(c, o[0], o[1], w, h);
                Gfx.btext(c, name, o[0] + 10, o[1] + 4, 0xFFFFFFFF);
                Gfx.text(c, hp, o[0] + w - 10 - Gfx.w(hp), o[1] + 4, 0xFF9A9AAA);
                Gfx.rrect(c, o[0] + 10, o[1] + 16, w - 20, 3, 1, 0xFF22222B);
                Gfx.rrect(c, o[0] + 10, o[1] + 16, Math.max(3, (int) ((w - 20) * frac)), 3, 1, Gfx.accent(0));
            }
            default -> {
                int w = 150, h = 44;
                x(c, "target", bx, by, w, h);
                int[] o = pos(bx, by);
                Gfx.rrect(c, o[0] - 1, o[1] - 1, w + 2, h + 2, 11, 0x40000000);
                Gfx.rrect(c, o[0], o[1], w, h, 10, 0xEB0E0E12);
                Faces.draw(c, t, o[0] + 6, o[1] + 6, 32);
                Gfx.btext(c, name, o[0] + 44, o[1] + 7, 0xFFFFFFFF);
                Gfx.text(c, hp, o[0] + w - 8 - Gfx.w(hp), o[1] + 7, 0xFF9A9AAA);
                Gfx.rrect(c, o[0] + 44, o[1] + 22, w - 52, 6, 3, 0xFF22222B);
                Gfx.rrect(c, o[0] + 44, o[1] + 22, Math.max(6, (int) ((w - 52) * frac)), 6, 3, Gfx.accent(0));
                Gfx.text(c, String.format(Locale.ROOT, "%.1f m", mc.player.distanceTo(t)), o[0] + 44, o[1] + 31, 0xFF7A7A8C);
                if (t.getAbsorptionAmount() > 0) {
                    String a = "+" + (int) t.getAbsorptionAmount();
                    Gfx.text(c, a, o[0] + w - 8 - Gfx.w(a), o[1] + 31, 0xFFFFD84A);
                }
            }
        }
    }

    private static void x(DrawContext c, String id, int bx, int by, int w, int h) { HudLayout.reg(id, bx + HudLayout.ox(id), by + HudLayout.oy(id), w, h); }
    private static int[] pos(int bx, int by) { return new int[]{bx + HudLayout.ox("target"), by + HudLayout.oy("target")}; }
}
