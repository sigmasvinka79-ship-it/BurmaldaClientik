package dev.burmalda.modules.render;

import dev.burmalda.core.Module;
import dev.burmalda.core.ModuleManager;
import dev.burmalda.core.Nav;
import dev.burmalda.core.Setting;
import dev.burmalda.modules.world.Home;
import dev.burmalda.modules.world.StructureFinder;
import dev.burmalda.ui.Gfx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

import java.time.LocalTime;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class Hud extends Module {
    final Setting.Bool watermark = bool("Watermark", true);
    final Setting.Bool coords = bool("Coordinates", true);
    final Setting.Bool effects = bool("Effects", true);
    final Setting.Bool compass = bool("Compass", true);
    final Setting.Bool arraylist = bool("Module list", true);
    final Setting.Bool armor = bool("Armor", true);
    final Setting.Bool keys = bool("Keystrokes", true);
    private double bps, tps = 20;
    private Vec3d prev;
    private long lastNs;

    public Hud() { super("HUD", Category.RENDER); enabled = true; }

    @Override
    public void onTick() {
        Vec3d now = mc.player.getPos();
        if (prev != null) bps = bps * 0.8 + Math.hypot(now.x - prev.x, now.z - prev.z) * 20 * 0.2;
        prev = now;
        long ns = System.nanoTime();
        if (lastNs != 0) tps = tps * 0.9 + Math.min(20.0, 1e9 / Math.max(1, ns - lastNs)) * 0.1;
        lastNs = ns;
    }

    private static int segW(String val, String unit) { return 14 + Gfx.bw(val) + (unit.isEmpty() ? 0 : 1 + Gfx.w(unit)); }
    private static void seg(DrawContext c, int x, int y, String icon, String val, String unit) {
        Gfx.icon(c, icon, x, y + 4, 10, 0xFFB0B0BC);
        int tx = x + 14;
        Gfx.btext(c, val, tx, y + 4, 0xFFFFFFFF);
        if (!unit.isEmpty()) Gfx.text(c, unit, tx + Gfx.bw(val) + 1, y + 4, 0xFF8E8E9C);
    }
    private static void row(DrawContext c, int x, int y, String[][] segs) {
        int w = 16;
        for (String[] s : segs) w += segW(s[1], s[2]) + 12;
        w -= 12;
        Gfx.pill(c, x, y, w, 18);
        int cx = x + 8;
        for (String[] s : segs) { seg(c, cx, y, s[0], s[1], s[2]); cx += segW(s[1], s[2]) + 12; }
    }
    private void key(DrawContext c, int x, int y, String s, boolean down) {
        Gfx.rrect(c, x, y, 18, 18, 5, down ? Gfx.alpha(Gfx.accent(x * 0.05), 200) : 0xB00E0E12);
        Gfx.btext(c, s, x + 9 - Gfx.bw(s) / 2f, y + 4, down ? 0xFFFFFFFF : 0xFF9A9AAA);
    }

    @Override
    public void onRender2D(DrawContext c) {
        var p = mc.player;
        if (p == null || mc.options.hudHidden) return;
        int sw = c.getScaledWindowWidth(), sh = c.getScaledWindowHeight();

        if (watermark.get()) {
            int lw = 14 + Gfx.bw("Burmalda") + 16;
            Gfx.pill(c, 6, 6, lw, 18);
            Gfx.icon(c, "logo", 11, 10, 10, Gfx.accent(0));
            Gfx.btext(c, "Burmalda", 25, 10, 0xFFFFFFFF);
            var le = mc.getNetworkHandler() == null ? null : mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
            String ping = String.valueOf(le == null ? 0 : le.getLatency());
            String time = LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss"));
            row(c, 6 + lw + 4, 6, new String[][]{{"user", p.getName().getString(), ""}, {"monitor", String.valueOf(mc.getCurrentFps()), "fps"},
                    {"cloud", ping, "ms"}, {"clock", time, ""}});
        }
        if (coords.get()) {
            row(c, 6, 28, new String[][]{{"pin", String.format(Locale.ROOT, "x%d y%d z%d", (int) Math.floor(p.getX()), (int) Math.floor(p.getY()), (int) Math.floor(p.getZ())), ""},
                    {"speed", String.format(Locale.ROOT, "%.1f", bps), "bps"}, {"gauge", String.format(Locale.ROOT, "%.1f", tps), "tps"}});
        }
        if (compass.get()) {
            Vec3d t = StructureFinder.targetPos();
            if (t == null && Nav.active && Nav.goal != null && ModuleManager.get(Home.class).enabled) t = Nav.goal;
            if (t != null) {
                float rel = MathHelper.wrapDegrees((float) (Math.toDegrees(Math.atan2(t.z - p.getZ(), t.x - p.getX())) - 90) - p.getYaw());
                String d = (int) Math.hypot(t.x - p.getX(), t.z - p.getZ()) + "m";
                String xz = (int) t.x + ", " + (int) t.z;
                int w = 34 + Math.max(Gfx.bw(d), Gfx.w(xz)), x = sw - 6 - w, y = 40;
                Gfx.rrect(c, x - 1, y - 1, w + 2, 30, 10, 0x40000000);
                Gfx.rrect(c, x, y, w, 28, 9, 0xEB0E0E12);
                c.getMatrices().push();
                c.getMatrices().translate(x + 15, y + 14, 0);
                c.getMatrices().multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rel));
                Gfx.icon(c, "arrow", -6, -6, 12, 0xFFFFFFFF);
                c.getMatrices().pop();
                Gfx.btext(c, d, x + 30, y + 5, 0xFFFFFFFF);
                Gfx.text(c, xz, x + 30, y + 15, 0xFF8E8E9C);
            }
        }
        if (keys.get()) {
            int x = 6, y = sh - 66;
            key(c, x + 20, y, "W", mc.options.forwardKey.isPressed());
            key(c, x, y + 20, "A", mc.options.leftKey.isPressed());
            key(c, x + 20, y + 20, "S", mc.options.backKey.isPressed());
            key(c, x + 40, y + 20, "D", mc.options.rightKey.isPressed());
        }
        if (effects.get()) {
            List<StatusEffectInstance> list = p.getStatusEffects().stream()
                    .filter(e -> !(e.getEffectType().equals(StatusEffects.NIGHT_VISION) && ModuleManager.get(Fullbright.class).enabled)).toList();
            if (!list.isEmpty()) {
                int w = 150, h = list.size() * 16 + 8, x = 6, y = sh / 2 - h / 2 + 36;
                Gfx.rrect(c, x - 1, y - 1, w + 2, h + 2, 9, 0x40000000);
                Gfx.rrect(c, x, y, w, h, 8, 0xEB0E0E12);
                Gfx.rrect(c, x, y, 22, h, 8, 0xFF08080B);
                c.fill(x + 12, y, x + 22, y + h, 0xFF08080B);
                Gfx.icon(c, "flask", x + 6, y + h / 2 - 5, 10, 0xFF9A9AAA);
                int ry = y + 6;
                for (StatusEffectInstance e : list) {
                    try {
                        var sprite = mc.getStatusEffectSpriteManager().getSprite(e.getEffectType());
                        c.drawSprite(x + 28, ry, 0, 12, 12, sprite);
                    } catch (Throwable ignored) {
                        Gfx.rect(c, x + 28, ry + 2, 8, 8, 0xFF000000 | e.getEffectType().value().getColor());
                    }
                    String name = e.getEffectType().value().getName().getString();
                    Gfx.btext(c, name, x + 44, ry + 2, 0xFFFFFFFF);
                    if (e.getAmplifier() > 0) Gfx.text(c, String.valueOf(e.getAmplifier() + 1), x + 46 + Gfx.bw(name), ry + 2, 0xFF8E8E9C);
                    int sec = e.getDuration() / 20;
                    String time = e.isInfinite() ? "inf" : String.format(Locale.ROOT, "%02d:%02d", sec / 60, sec % 60);
                    Gfx.text(c, time, x + w - 8 - Gfx.w(time), ry + 2, e.getDuration() < 200 && !e.isInfinite() ? 0xFFFF6A6A : 0xFF8E8E9C);
                    ry += 16;
                }
            }
        }
        if (armor.get()) {
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            int x = sw - 6 - 4 * 20, y = sh - 30;
            for (EquipmentSlot sl : slots) {
                ItemStack st = p.getEquippedStack(sl);
                if (!st.isEmpty()) {
                    c.drawItem(st, x, y);
                    if (st.isDamageable()) {
                        float f = 1f - (float) st.getDamage() / st.getMaxDamage();
                        Gfx.rect(c, x, y + 17, 16, 2, 0xFF1A1A22);
                        Gfx.rect(c, x, y + 17, 16 * f, 2, 0xFF000000 | MathHelper.hsvToRgb(f / 3f, 0.9f, 1f));
                    }
                }
                x += 20;
            }
        }
        if (arraylist.get()) {
            List<Module> on = ModuleManager.ALL.stream().filter(m -> m.enabled && m != this)
                    .sorted(Comparator.comparingInt((Module m) -> Gfx.bw(m.name)).reversed()).toList();
            int y = compass.get() && StructureFinder.targetPos() != null ? 74 : 6;
            for (Module m : on) {
                int w = Gfx.bw(m.name) + 12;
                Gfx.rect(c, sw - w - 6, y, w, 13, 0xB00E0E12);
                Gfx.rect(c, sw - 6, y, 2, 13, Gfx.accent(y * 0.08));
                Gfx.btext(c, m.name, sw - w, y + 2, Gfx.accent(y * 0.08));
                y += 13;
            }
        }
    }
}
