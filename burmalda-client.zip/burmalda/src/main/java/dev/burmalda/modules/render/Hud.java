package dev.burmalda.modules.render;

import dev.burmalda.core.HudLayout;
import dev.burmalda.core.Module;
import dev.burmalda.core.ModuleManager;
import dev.burmalda.core.Nav;
import dev.burmalda.core.Notifications;
import dev.burmalda.core.Setting;
import dev.burmalda.modules.world.Home;
import dev.burmalda.modules.world.StructureFinder;
import dev.burmalda.ui.Gfx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Nursultan-style HUD. Every block is draggable while the menu is open. */
public class Hud extends Module {
    final Setting.Bool watermark = bool("Watermark", true);
    final Setting.Bool coords = bool("Coordinates", true);
    final Setting.Bool effects = bool("Effects", true);
    final Setting.Bool compass = bool("Compass", true);
    final Setting.Bool hotkeys = bool("Hotkeys", true);
    final Setting.Bool cooldowns = bool("Cooldowns", true);
    final Setting.Bool notifs = bool("Notifications", true);
    final Setting.Bool arraylist = bool("Module list", false);
    final Setting.Bool armor = bool("Armor", true);
    final Setting.Bool keys = bool("Keystrokes", true);
    private double bps, tps = 20;
    private Vec3d prev;
    private long lastNs;
    private static final Item[] CD_ITEMS = {Items.ENDER_PEARL, Items.CHORUS_FRUIT, Items.ENCHANTED_GOLDEN_APPLE, Items.GOLDEN_APPLE, Items.SHIELD, Items.WIND_CHARGE};

    public Hud() { super("HUD", Category.RENDER); enabled = true; }

    @Override
    public void onTick() {
        Vec3d now = mc.player.getPos();
        if (prev != null) bps = bps * 0.8 + Math.hypot(now.x - prev.x, now.z - prev.z) * 20 * 0.2;
        prev = now;
        long ns = System.nanoTime();
        if (lastNs != 0) tps = tps * 0.9 + Math.min(20.0, 1e9 / Math.max(1, ns - lastNs)) * 0.1;
        lastNs = ns;
    }

    private static int[] place(String id, int x, int y, int w, int h) {
        x += HudLayout.ox(id); y += HudLayout.oy(id);
        HudLayout.reg(id, x, y, w, h);
        return new int[]{x, y};
    }
    private static int segW(String val, String unit) { return 14 + Gfx.bw(val) + (unit.isEmpty() ? 0 : 2 + Gfx.w(unit)); }
    private static void seg(DrawContext c, int x, int y, String icon, String val, String unit) {
        Gfx.icon(c, icon, x, y + 4, 10, 0xFFB0B0BC);
        Gfx.btext(c, val, x + 14, y + 4, 0xFFFFFFFF);
        if (!unit.isEmpty()) Gfx.text(c, unit, x + 16 + Gfx.bw(val), y + 4, 0xFF8E8E9C);
    }
    private static int rowW(String[][] segs) {
        int w = 16;
        for (String[] s : segs) w += segW(s[1], s[2]) + 12;
        return w - 12;
    }
    private static void row(DrawContext c, int x, int y, String[][] segs) {
        Gfx.pill(c, x, y, rowW(segs), 18);
        int cx = x + 8;
        for (String[] s : segs) { seg(c, cx, y, s[0], s[1], s[2]); cx += segW(s[1], s[2]) + 12; }
    }
    private void key(DrawContext c, int x, int y, String s, boolean down) {
        Gfx.rrect(c, x, y, 18, 18, 5, down ? Gfx.alpha(Gfx.accent(x * 0.05), 200) : 0xB00E0E12);
        Gfx.btext(c, s, x + 9 - Gfx.bw(s) / 2f, y + 4, down ? 0xFFFFFFFF : 0xFF9A9AAA);
    }
    private static String keyLabel(int code) {
        String n = org.lwjgl.glfw.GLFW.glfwGetKeyName(code, 0);
        return n != null ? n.toUpperCase() : "K" + code;
    }

    @Override
    public void onRender2D(DrawContext c) {
        HudLayout.beginFrame();
        var p = mc.player;
        if (p == null || mc.options.hudHidden) return;
        int sw = c.getScaledWindowWidth(), sh = c.getScaledWindowHeight();
        boolean edit = HudLayout.editing;

        if (watermark.get()) {
            int lw = 14 + Gfx.bw("Burmalda") + 16;
            var le = mc.getNetworkHandler() == null ? null : mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
            String[][] segs = {{"user", p.getName().getString(), ""}, {"monitor", String.valueOf(mc.getCurrentFps()), "fps"},
                    {"cloud", String.valueOf(le == null ? 0 : le.getLatency()), "ms"}, {"clock", LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), ""}};
            int[] o = place("watermark", 6, 6, lw + 4 + rowW(segs), 18);
            Gfx.pill(c, o[0], o[1], lw, 18);
            Gfx.icon(c, "logo", o[0] + 5, o[1] + 4, 10, Gfx.accent(0));
            Gfx.btext(c, "Burmalda", o[0] + 19, o[1] + 4, 0xFFFFFFFF);
            row(c, o[0] + lw + 4, o[1], segs);
        }
        if (coords.get()) {
            String[][] segs = {{"pin", String.format(Locale.ROOT, "x%d y%d z%d", (int) Math.floor(p.getX()), (int) Math.floor(p.getY()), (int) Math.floor(p.getZ())), ""},
                    {"speed", String.format(Locale.ROOT, "%.1f", bps), "bps"}, {"gauge", String.format(Locale.ROOT, "%.1f", tps), "tps"}};
            int[] o = place("coords", 6, 28, rowW(segs), 18);
            row(c, o[0], o[1], segs);
        }
        if (compass.get()) {
            Vec3d t = StructureFinder.targetPos();
            if (t == null && Nav.active && Nav.goal != null && ModuleManager.get(Home.class).enabled) t = Nav.goal;
            if (t == null && edit) t = new Vec3d(p.getX() + 47, p.getY(), p.getZ() + 14);
            if (t != null) {
                float rel = MathHelper.wrapDegrees((float) (Math.toDegrees(Math.atan2(t.z - p.getZ(), t.x - p.getX())) - 90) - p.getYaw());
                String d = (int) Math.hypot(t.x - p.getX(), t.z - p.getZ()) + "m";
                String xz = (int) t.x + ", " + (int) t.z;
                int w = 36 + Math.max(Gfx.bw(d), Gfx.w(xz));
                int[] o = place("compass", sw / 2 - w / 2, 6, w, 28);
                Gfx.rrect(c, o[0] - 1, o[1] - 1, w + 2, 30, 10, 0x40000000);
                Gfx.rrect(c, o[0], o[1], w, 28, 9, 0xEB0E0E12);
                c.getMatrices().push();
                c.getMatrices().translate(o[0] + 15, o[1] + 14, 0);
                c.getMatrices().multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rel));
                Gfx.icon(c, "arrow", -6, -6, 12, 0xFFFFFFFF);
                c.getMatrices().pop();
                Gfx.btext(c, d, o[0] + 31, o[1] + 5, 0xFFFFFFFF);
                Gfx.text(c, xz, o[0] + 31, o[1] + 15, 0xFF8E8E9C);
            }
        }
        if (hotkeys.get()) {
            List<Module> bound = new ArrayList<>();
            for (Module m : ModuleManager.ALL) if (m.key >= 0) bound.add(m);
            if (!bound.isEmpty() || edit) {
                int w = 96;
                for (Module m : bound) w = Math.max(w, 24 + Gfx.bw(m.name) + 18 + Gfx.w(keyLabel(m.key)));
                int h = 22 + Math.max(1, bound.size()) * 15 + 4;
                int[] o = place("hotkeys", 6, 52, w, h);
                Gfx.rrect(c, o[0] - 1, o[1] - 1, w + 2, h + 2, 9, 0x40000000);
                Gfx.rrect(c, o[0], o[1], w, h, 8, 0xEB0E0E12);
                Gfx.icon(c, "keyboard", o[0] + 8, o[1] + 6, 10, 0xFFB0B0BC);
                Gfx.btext(c, "Hotkeys", o[0] + 24, o[1] + 6, 0xFFFFFFFF);
                int ry = o[1] + 22;
                for (Module m : bound) {
                    Gfx.text(c, m.name, o[0] + 10, ry + 2, m.enabled ? 0xFFFFFFFF : 0xFF8E8E9C);
                    String k = keyLabel(m.key);
                    Gfx.text(c, k, o[0] + w - 10 - Gfx.w(k), ry + 2, 0xFF8E8E9C);
                    ry += 15;
                }
                if (bound.isEmpty()) Gfx.text(c, ".bind add <модуль> <клавиша>", o[0] + 10, ry + 2, 0xFF6E6E80);
            }
        }
        if (keys.get()) {
            int[] o = place("keys", 6, sh - 66, 58, 38);
            key(c, o[0] + 20, o[1], "W", mc.options.forwardKey.isPressed());
            key(c, o[0], o[1] + 20, "A", mc.options.leftKey.isPressed());
            key(c, o[0] + 20, o[1] + 20, "S", mc.options.backKey.isPressed());
            key(c, o[0] + 40, o[1] + 20, "D", mc.options.rightKey.isPressed());
        }
        if (effects.get()) {
            List<StatusEffectInstance> list = p.getStatusEffects().stream()
                    .filter(e -> !(e.getEffectType().equals(StatusEffects.NIGHT_VISION) && ModuleManager.get(Fullbright.class).enabled)).toList();
            if (!list.isEmpty()) {
                int w = 160;
                for (StatusEffectInstance e : list) {
                    int sec = e.getDuration() / 20;
                    String tm = e.isInfinite() ? "inf" : String.format(Locale.ROOT, "%02d:%02d", sec / 60, sec % 60);
                    int lv = e.getAmplifier() > 0 ? Gfx.w(String.valueOf(e.getAmplifier() + 1)) + 5 : 0;
                    w = Math.max(w, 52 + Gfx.bw(e.getEffectType().value().getName().getString()) + lv + 14 + Gfx.w(tm) + 10);
                }
                int h = list.size() * 18 + 10;
                int[] o = place("effects", 6, sh / 2 - h / 2 + 36, w, h);
                Gfx.rrect(c, o[0] - 1, o[1] - 1, w + 2, h + 2, 9, 0x40000000);
                Gfx.rrect(c, o[0], o[1], w, h, 8, 0xEB0E0E12);
                Gfx.rrect(c, o[0], o[1], 24, h, 8, 0xFF08080B);
                c.fill(o[0] + 14, o[1], o[0] + 24, o[1] + h, 0xFF08080B);
                Gfx.icon(c, "flask", o[0] + 7, o[1] + h / 2 - 5, 10, 0xFF9A9AAA);
                int ry = o[1] + 5;
                for (StatusEffectInstance e : list) {
                    try {
                        c.drawSprite(o[0] + 30, ry + 1, 0, 14, 14, mc.getStatusEffectSpriteManager().getSprite(e.getEffectType()));
                    } catch (Throwable ignored) {
                        Gfx.rrect(c, o[0] + 31, ry + 3, 10, 10, 3, 0xFF000000 | e.getEffectType().value().getColor());
                    }
                    String name = e.getEffectType().value().getName().getString();
                    Gfx.btext(c, name, o[0] + 52, ry + 4, 0xFFFFFFFF);
                    if (e.getAmplifier() > 0) Gfx.text(c, String.valueOf(e.getAmplifier() + 1), o[0] + 57 + Gfx.bw(name), ry + 4, 0xFF8E8E9C);
                    int sec = e.getDuration() / 20;
                    String tm = e.isInfinite() ? "inf" : String.format(Locale.ROOT, "%02d:%02d", sec / 60, sec % 60);
                    Gfx.text(c, tm, o[0] + w - 10 - Gfx.w(tm), ry + 4, e.getDuration() < 200 && !e.isInfinite() ? 0xFFFF6A6A : 0xFF8E8E9C);
                    ry += 18;
                }
            }
        }
        if (cooldowns.get()) {
            List<Item> act = new ArrayList<>();
            for (Item it : CD_ITEMS) if (p.getItemCooldownManager().isCoolingDown(it)) act.add(it);
            if (act.isEmpty() && edit) act.add(Items.ENDER_PEARL);
            if (!act.isEmpty()) {
                int w = 124, h = act.size() * 22 + 4;
                int[] o = place("cooldowns", sw - 6 - w, sh / 2 - 10, w, h);
                int ry = o[1] + 2;
                for (Item it : act) {
                    float pr = 1f - Math.min(1f, p.getItemCooldownManager().getCooldownProgress(it, 0f));
                    if (edit && pr >= 1f) pr = 0.6f;
                    Gfx.pill(c, o[0], ry, w, 18);
                    c.drawItem(new ItemStack(it), o[0] + 4, ry + 1);
                    Gfx.btext(c, it.getName().getString(), o[0] + 24, ry + 4, 0xFFFFFFFF);
                    Gfx.rrect(c, o[0] + 24, ry + 15, w - 36, 2, 1, 0xFF22222B);
                    Gfx.rrect(c, o[0] + 24, ry + 15, Math.max(2, (int) ((w - 36) * pr)), 2, 1, Gfx.accent(ry * 0.05));
                    ry += 22;
                }
            }
        }
        if (armor.get()) {
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            int[] o = place("armor", sw - 6 - 80, sh - 30, 80, 22);
            int x = o[0];
            for (EquipmentSlot sl : slots) {
                ItemStack st = p.getEquippedStack(sl);
                if (!st.isEmpty()) {
                    c.drawItem(st, x, o[1]);
                    if (st.isDamageable()) {
                        float f = 1f - (float) st.getDamage() / st.getMaxDamage();
                        Gfx.rect(c, x, o[1] + 17, 16, 2, 0xFF1A1A22);
                        Gfx.rect(c, x, o[1] + 17, 16 * f, 2, 0xFF000000 | MathHelper.hsvToRgb(f / 3f, 0.9f, 1f));
                    }
                }
                x += 20;
            }
        }
        if (arraylist.get()) {
            List<Module> on = ModuleManager.ALL.stream().filter(m -> m.enabled && m != this)
                    .sorted(Comparator.comparingInt((Module m) -> Gfx.bw(m.name)).reversed()).toList();
            if (!on.isEmpty()) {
                int mw = Gfx.bw(on.get(0).name) + 12;
                int[] o = place("arraylist", sw - 6 - mw, 6, mw, on.size() * 13);
                int y = o[1];
                for (Module m : on) {
                    int w = Gfx.bw(m.name) + 12;
                    Gfx.rect(c, o[0] + mw - w, y, w, 13, 0xB00E0E12);
                    Gfx.rect(c, o[0] + mw - 2, y, 2, 13, Gfx.accent(y * 0.08));
                    Gfx.btext(c, m.name, o[0] + mw - w + 4, y + 2, Gfx.accent(y * 0.08));
                    y += 13;
                }
            }
        }
        if (notifs.get()) {
            long now = System.currentTimeMillis();
            Notifications.LIST.removeIf(n -> now - n.t() > 2800);
            int cnt = Math.max(Notifications.LIST.size(), edit ? 1 : 0);
            if (cnt > 0) {
                int w = 150;
                int[] o = place("notifs", sw - 6 - w, sh - 64 - cnt * 22, w, cnt * 22);
                int y = o[1];
                var list = Notifications.LIST;
                for (int i = 0; i < Math.max(list.size(), cnt); i++) {
                    Notifications.N n = i < list.size() ? list.get(i) : new Notifications.N("KillAura", true, now);
                    long age = now - n.t();
                    int dx = age < 220 ? (int) ((1 - age / 220.0) * 70) : age > 2500 ? (int) ((age - 2500) / 300.0 * 70) : 0;
                    Gfx.pill(c, o[0] + dx, y, w, 18);
                    Gfx.rrect(c, o[0] + dx + 6, y + 6, 6, 6, 3, n.on() ? 0xFF58D68D : 0xFFE05A5A);
                    Gfx.btext(c, n.text(), o[0] + dx + 18, y + 4, 0xFFFFFFFF);
                    String st = n.on() ? "включён" : "выключен";
                    Gfx.text(c, st, o[0] + dx + w - 8 - Gfx.w(st), y + 4, 0xFF8E8E9C);
                    y += 22;
                }
            }
        }
    }
}
