package dev.burmalda.modules.render;

import dev.burmalda.core.Module;
import dev.burmalda.core.ModuleManager;
import dev.burmalda.core.Setting;
import dev.burmalda.ui.Gfx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.List;

public class Hud extends Module {
    final Setting.Bool watermark = bool("Watermark", true);
    final Setting.Bool coords = bool("Coordinates", true);
    final Setting.Bool effects = bool("Effects", true);
    final Setting.Bool arraylist = bool("Module list", true);
    final Setting.Bool armor = bool("Armor", true);
    final Setting.Bool keys = bool("Keystrokes", true);
    private double bps;
    private Vec3d prev;

    public Hud() { super("HUD", Category.RENDER); enabled = true; }

    @Override
    public void onTick() {
        Vec3d now = mc.player.getPos();
        if (prev != null) bps = bps * 0.8 + Math.hypot(now.x - prev.x, now.z - prev.z) * 20 * 0.2;
        prev = now;
    }

    private void key(DrawContext c, int x, int y, String s, boolean down) {
        Gfx.rrect(c, x, y, 18, 18, 3, down ? Gfx.alpha(Gfx.accent(x * 0.05), 190) : 0xA0121217);
        Gfx.text(c, s, x + 9 - Gfx.w(s) / 2f, y + 5, down ? 0xFFFFFFFF : 0xFF9A9AAA);
    }

    @Override
    public void onRender2D(DrawContext c) {
        var p = mc.player;
        if (p == null || mc.options.hudHidden) return;
        int sw = c.getScaledWindowWidth(), sh = c.getScaledWindowHeight();

        if (watermark.get()) {
            String s = String.format("Burmalda  |  %d fps  |  %s  |  %.1f b/s", mc.getCurrentFps(), p.getName().getString(), bps);
            int w = Gfx.w(s) + 14;
            Gfx.rrect(c, 6, 6, w, 17, 4, 0xD0121217);
            Gfx.hgrad(c, 8, 6, w - 4, 1, 0);
            Gfx.text(c, s, 13, 11, 0xFFEDEDF5);
        }
        if (coords.get()) {
            String s = String.format("XYZ  %.1f  %.1f  %.1f", p.getX(), p.getY(), p.getZ());
            String dim = mc.world.getRegistryKey().getValue().getPath();
            String other = dim.equals("overworld") ? String.format("Nether  %.0f  %.0f", p.getX() / 8, p.getZ() / 8)
                    : dim.equals("the_nether") ? String.format("Overworld  %.0f  %.0f", p.getX() * 8, p.getZ() * 8) : "";
            int w = Math.max(Gfx.w(s), Gfx.w(other)) + 14, h = other.isEmpty() ? 17 : 29;
            Gfx.rrect(c, 6, sh - h - 6, w, h, 4, 0xD0121217);
            Gfx.text(c, s, 13, sh - h - 1, 0xFFEDEDF5);
            if (!other.isEmpty()) Gfx.text(c, other, 13, sh - 18, 0xFF8A8A99);
        }
        if (keys.get()) {
            int x = 6, y = sh - 112;
            key(c, x + 20, y, "W", mc.options.forwardKey.isPressed());
            key(c, x, y + 20, "A", mc.options.leftKey.isPressed());
            key(c, x + 20, y + 20, "S", mc.options.backKey.isPressed());
            key(c, x + 40, y + 20, "D", mc.options.rightKey.isPressed());
        }
        if (effects.get()) {
            int y = sh / 2 - p.getStatusEffects().size() * 9;
            for (StatusEffectInstance e : p.getStatusEffects()) {
                if (e.getEffectType().equals(StatusEffects.NIGHT_VISION) && ModuleManager.get(Fullbright.class).enabled) continue;
                String name = e.getEffectType().value().getName().getString() + (e.getAmplifier() > 0 ? " " + (e.getAmplifier() + 1) : "");
                int sec = e.getDuration() / 20;
                String time = e.isInfinite() ? "inf" : String.format("%d:%02d", sec / 60, sec % 60);
                int col = 0xFF000000 | e.getEffectType().value().getColor();
                int w = Gfx.w(name) + Gfx.w(time) + 24;
                Gfx.rrect(c, 6, y, w, 16, 4, 0xB0121217);
                Gfx.rect(c, 6, y + 3, 2, 10, col);
                Gfx.text(c, name, 13, y + 4, 0xFFEDEDF5);
                Gfx.text(c, time, 6 + w - 7 - Gfx.w(time), y + 4, e.getDuration() < 200 && !e.isInfinite() ? 0xFFFF6A6A : 0xFF9A9AAA);
                y += 18;
            }
        }
        if (armor.get()) {
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            int x = sw - 6 - 4 * 20, y = sh - 30;
            for (EquipmentSlot sl : slots) {
                ItemStack st = p.getEquippedStack(sl);
                if (!st.isEmpty()) {
                    c.drawItem(st, x, y);
                    if (st.isDamageable()) {
                        float f = 1f - (float) st.getDamage() / st.getMaxDamage();
                        Gfx.rect(c, x, y + 17, 16, 2, 0xFF1A1A22);
                        Gfx.rect(c, x, y + 17, 16 * f, 2, 0xFF000000 | MathHelper.hsvToRgb(f / 3f, 0.9f, 1f));
                    }
                }
                x += 20;
            }
        }
        if (arraylist.get()) {
            List<Module> on = ModuleManager.ALL.stream().filter(m -> m.enabled && m != this)
                    .sorted(Comparator.comparingInt((Module m) -> Gfx.w(m.name)).reversed()).toList();
            int y = 6;
            for (Module m : on) {
                int w = Gfx.w(m.name) + 10;
                Gfx.rect(c, sw - w - 6, y, w, 13, 0xA0121217);
                Gfx.rect(c, sw - 6, y, 2, 13, Gfx.accent(y * 0.08));
                Gfx.text(c, m.name, sw - w - 1, y + 3, Gfx.accent(y * 0.08));
                y += 13;
            }
        }
    }
}
