package dev.burmalda.modules.player;

import dev.burmalda.core.Module;

public class Sprint extends Module {
    public Sprint() { super("Sprint", Category.PLAYER); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (mc.options.forwardKey.isPressed() && !p.isSneaking() && !p.isUsingItem() && !p.horizontalCollision && p.getHungerManager().getFoodLevel() > 6)
            p.setSprinting(true);
    }
}
