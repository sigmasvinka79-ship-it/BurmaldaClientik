package dev.burmalda.modules.farm;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import net.minecraft.text.Text;

import java.util.ArrayDeque;
import java.util.List;

/** Uses the integrated server's /locate (needs cheats enabled in the world). Enabling the module runs the search. */
public class StructureFinder extends Module {
    private static final List<String> ALL = List.of("#minecraft:village", "minecraft:stronghold", "minecraft:mansion",
            "minecraft:monument", "minecraft:fortress", "minecraft:bastion_remnant", "minecraft:ancient_city",
            "minecraft:trial_chambers", "minecraft:mineshaft", "minecraft:ruined_portal");
    final Setting.Mode what = mode("Structure", "Village", "Village", "Stronghold", "Mansion", "Monument", "Fortress",
            "Bastion", "AncientCity", "TrialChambers", "Mineshaft", "All");
    private final ArrayDeque<String> queue = new ArrayDeque<>();
    private int cd;

    public StructureFinder() { super("StructureFinder", Category.FARM); }

    private String id() {
        return switch (what.value) {
            case "Village" -> ALL.get(0); case "Stronghold" -> ALL.get(1); case "Mansion" -> ALL.get(2);
            case "Monument" -> ALL.get(3); case "Fortress" -> ALL.get(4); case "Bastion" -> ALL.get(5);
            case "AncientCity" -> ALL.get(6); case "TrialChambers" -> ALL.get(7); default -> ALL.get(8);
        };
    }

    @Override
    public void onEnable() {
        queue.clear();
        if (what.is("All")) queue.addAll(ALL); else queue.add(id());
        cd = 0;
        mc.player.sendMessage(Text.literal("[Burmalda] Searching... (cheats must be enabled)"), false);
    }

    @Override
    public void onTick() {
        if (cd-- > 0) return;
        if (queue.isEmpty()) { setEnabled(false); return; }
        mc.player.networkHandler.sendChatCommand("locate structure " + queue.poll());
        cd = 15;
    }
}
