package dev.burmalda.modules.farm;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.nbt.NbtSizeTracker;
import net.minecraft.registry.Registries;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Blueprints: built-in farms / shelter and a loader for vanilla structure .nbt files. y = 0 is the ground layer. */
public final class Plans {
    private Plans() {}
    public record Entry(BlockPos pos, BlockState state) {}

    public static final class Blueprint {
        public final List<Entry> list = new ArrayList<>();
        public int sx, sy, sz;
        public void set(int x, int y, int z, BlockState s) {
            list.add(new Entry(new BlockPos(x, y, z), s));
            sx = Math.max(sx, x + 1); sy = Math.max(sy, y + 1); sz = Math.max(sz, z + 1);
        }
        public void set(int x, int y, int z, Block b) { set(x, y, z, b.getDefaultState()); }

        public Blueprint rotated(int q) {
            q = ((q % 4) + 4) % 4;
            if (q == 0) return this;
            BlockRotation rot = BlockRotation.values()[q];
            int minX = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
            List<int[]> pts = new ArrayList<>();
            for (Entry e : list) {
                int x = e.pos().getX(), z = e.pos().getZ();
                for (int k = 0; k < q; k++) { int nx = -z; z = x; x = nx; }
                pts.add(new int[]{x, z});
                minX = Math.min(minX, x); minZ = Math.min(minZ, z);
            }
            Blueprint out = new Blueprint();
            for (int i = 0; i < list.size(); i++)
                out.set(pts.get(i)[0] - minX, list.get(i).pos().getY(), pts.get(i)[1] - minZ, list.get(i).state().rotate(rot));
            return out;
        }
    }

    public static Blueprint builtin(String name) {
        return switch (name) {
            case "Carrot farm" -> cropFarm(Blocks.CARROTS);
            case "Potato farm" -> cropFarm(Blocks.POTATOES);
            case "Beetroot farm" -> cropFarm(Blocks.BEETROOTS);
            case "Sugar cane farm" -> caneFarm();
            case "Shelter" -> shelter();
            default -> cropFarm(Blocks.WHEAT);
        };
    }

    /** 9x9 plot: water in the middle, farmland + crops everywhere else, fence ring with a gap, torches on the corners. */
    private static Blueprint cropFarm(Block crop) {
        Blueprint b = new Blueprint();
        for (int x = 1; x <= 9; x++) for (int z = 1; z <= 9; z++) {
            if (x == 5 && z == 5) { b.set(x, 0, z, Blocks.WATER); continue; }
            b.set(x, 0, z, Blocks.FARMLAND);
            b.set(x, 1, z, crop);
        }
        for (int i = 0; i <= 10; i++) for (int[] e : new int[][]{{i, 0}, {i, 10}, {0, i}, {10, i}}) {
            if (e[0] == 5 && e[1] == 0) continue;
            b.set(e[0], 1, e[1], Blocks.OAK_FENCE);
        }
        for (int[] c : new int[][]{{0, 0}, {10, 0}, {0, 10}, {10, 10}}) b.set(c[0], 2, c[1], Blocks.TORCH);
        return b;
    }

    /** 3 x 9: sand / water / sand with cane on both sand strips (water on every second block fills the rest). */
    private static Blueprint caneFarm() {
        Blueprint b = new Blueprint();
        for (int z = 0; z < 9; z++) {
            b.set(0, 0, z, Blocks.SAND); b.set(2, 0, z, Blocks.SAND);
            if (z % 2 == 0) b.set(1, 0, z, Blocks.WATER);
            b.set(0, 1, z, Blocks.SUGAR_CANE); b.set(2, 1, z, Blocks.SUGAR_CANE);
        }
        return b;
    }

    /** 5x5 cobblestone box, 2 high, door gap in front, torch inside. */
    private static Blueprint shelter() {
        Blueprint b = new Blueprint();
        for (int x = 0; x < 5; x++) for (int z = 0; z < 5; z++) {
            b.set(x, 0, z, Blocks.COBBLESTONE);
            b.set(x, 3, z, Blocks.COBBLESTONE);
            boolean wall = x == 0 || x == 4 || z == 0 || z == 4;
            if (wall && !(x == 2 && z == 0)) { b.set(x, 1, z, Blocks.COBBLESTONE); b.set(x, 2, z, Blocks.COBBLESTONE); }
        }
        b.set(2, 1, 2, Blocks.TORCH);
        return b;
    }

    public static Path dir() { return FabricLoader.getInstance().getGameDir().resolve("burmalda").resolve("schematics"); }

    /** Loads a vanilla structure .nbt (Structure Block export / many downloadable farm designs). */
    public static Blueprint load(String name) throws Exception {
        Path p = dir().resolve(name.endsWith(".nbt") ? name : name + ".nbt");
        NbtCompound root = NbtIo.readCompressed(p, NbtSizeTracker.ofUnlimitedBytes());
        NbtList palette = root.getList("palette", NbtElement.COMPOUND_TYPE);
        List<BlockState> states = new ArrayList<>();
        for (int i = 0; i < palette.size(); i++) states.add(NbtHelper.toBlockState(Registries.BLOCK.getReadOnlyWrapper(), palette.getCompound(i)));
        NbtList blocks = root.getList("blocks", NbtElement.COMPOUND_TYPE);
        Blueprint bp = new Blueprint();
        for (int i = 0; i < blocks.size(); i++) {
            NbtCompound e = blocks.getCompound(i);
            NbtList pos = e.getList("pos", NbtElement.INT_TYPE);
            BlockState s = states.get(e.getInt("state"));
            if (s.isAir() || s.isOf(Blocks.STRUCTURE_VOID)) continue;
            bp.set(pos.getInt(0), pos.getInt(1), pos.getInt(2), s);
        }
        return bp;
    }
}
