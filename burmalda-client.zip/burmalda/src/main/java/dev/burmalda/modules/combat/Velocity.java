package dev.burmalda.modules.combat;

import dev.burmalda.core.Module;
import dev.burmalda.core.Setting;
import net.minecraft.util.math.Vec3d;

/** Reduces the knockback you take. */
public class Velocity extends Module {
    final Setting.Num h = num("Horizontal", 20, 0, 100, 5);
    final Setting.Num v = num("Vertical", 100, 0, 100, 5);
    private int prev;

    public Velocity() { super("Velocity", Category.COMBAT); }

    @Override
    public void onTick() {
        var p = mc.player;
        if (p.hurtTime > 0 && prev == 0) {
            Vec3d vel = p.getVelocity();
            p.setVelocity(vel.x * h.get() / 100.0, vel.y * v.get() / 100.0, vel.z * h.get() / 100.0);
        }
        prev = p.hurtTime;
    }
}
