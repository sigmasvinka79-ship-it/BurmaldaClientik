package dev.burmalda.ui;

import net.minecraft.client.gui.DrawContext;

import java.util.Random;

/** Tiny allocation-free 2D particle system (bursts on click + floating ambient specks). */
public final class Particles2D {
    private static final int MAX = 140;
    private final float[] x = new float[MAX], y = new float[MAX], vx = new float[MAX], vy = new float[MAX], life = new float[MAX], max = new float[MAX], sz = new float[MAX];
    private final int[] col = new int[MAX];
    private int n;
    private final Random r = new Random();

    private void add(float px, float py, float sx, float sy, float l, float s, int c) {
        if (n >= MAX) return;
        x[n] = px; y[n] = py; vx[n] = sx; vy[n] = sy; life[n] = l; max[n] = l; sz[n] = s; col[n] = c; n++;
    }
    public void burst(float px, float py, int count) {
        for (int i = 0; i < count; i++) {
            double a = r.nextDouble() * Math.PI * 2, sp = 25 + r.nextDouble() * 90;
            add(px, py, (float) Math.cos(a) * (float) sp, (float) Math.sin(a) * (float) sp, 0.5f + r.nextFloat() * 0.5f, 1 + r.nextInt(2), Gfx.accent(i * 0.4));
        }
    }
    public void ambient(int w, int h) {
        while (n < 55) add(r.nextFloat() * w, r.nextFloat() * h, (r.nextFloat() - 0.5f) * 6, -3 - r.nextFloat() * 8, 4 + r.nextFloat() * 6, 1 + r.nextInt(2), 0xFFFFFFFF);
    }
    public void update(float dt) {
        for (int i = 0; i < n; ) {
            life[i] -= dt; x[i] += vx[i] * dt; y[i] += vy[i] * dt; vx[i] *= 0.985f; vy[i] *= 0.985f;
            if (life[i] <= 0) { n--; x[i] = x[n]; y[i] = y[n]; vx[i] = vx[n]; vy[i] = vy[n]; life[i] = life[n]; max[i] = max[n]; sz[i] = sz[n]; col[i] = col[n]; }
            else i++;
        }
    }
    public void render(DrawContext c) {
        for (int i = 0; i < n; i++) {
            float f = Math.min(1f, life[i] / max[i]);
            int a = (int) (200 * Math.min(f * 2f, 1f));
            int px = (int) x[i], py = (int) y[i], s = (int) sz[i];
            c.fill(px, py, px + s, py + s, Gfx.alpha(col[i], a));
        }
    }
}
