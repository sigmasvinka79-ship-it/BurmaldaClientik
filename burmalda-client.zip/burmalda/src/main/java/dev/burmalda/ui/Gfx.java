package dev.burmalda.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Gfx {
    private Gfx() {}
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public static final Identifier FONT = Identifier.of("burmalda", "main");

    public static int c1 = 0xFF8A5CFF, c2 = 0xFF3CC8FF;
    public static boolean rainbow;
    public static double speed = 700.0;

    public static Text t(String s) { return Text.literal(s).setStyle(Style.EMPTY.withFont(FONT)); }
    public static int w(String s) { return mc.textRenderer.getWidth(t(s)); }
    public static void text(DrawContext c, String s, float x, float y, int col) { c.drawText(mc.textRenderer, t(s), (int) x, (int) y, col, false); }

    public static int lerp(int a, int b, float t) {
        int ar = a >> 24 & 255, rr = a >> 16 & 255, gr = a >> 8 & 255, br = a & 255;
        int a2 = b >> 24 & 255, r2 = b >> 16 & 255, g2 = b >> 8 & 255, b2 = b & 255;
        return (int) (ar + (a2 - ar) * t) << 24 | (int) (rr + (r2 - rr) * t) << 16 | (int) (gr + (g2 - gr) * t) << 8 | (int) (br + (b2 - br) * t);
    }
    public static void setTheme(String name) {
        rainbow = false;
        switch (name) {
            case "Ocean" -> { c1 = 0xFF1E6BFF; c2 = 0xFF2EF2D0; }
            case "Sunset" -> { c1 = 0xFFFF4D6D; c2 = 0xFFFFB347; }
            case "Mint" -> { c1 = 0xFF2EE59D; c2 = 0xFFB8F7D4; }
            case "Blood" -> { c1 = 0xFFB0102A; c2 = 0xFFFF5470; }
            case "Rainbow" -> rainbow = true;
            default -> { c1 = 0xFF8A5CFF; c2 = 0xFF3CC8FF; }
        }
    }
    /** Animated gradient colour, `off` shifts the phase. */
    public static int accent(double off) {
        if (rainbow) return 0xFF000000 | MathHelper.hsvToRgb((float) (((System.currentTimeMillis() / (speed * 6) + off * 0.08) % 1.0 + 1.0) % 1.0), 0.65f, 1f);
        float t = (float) ((Math.sin(System.currentTimeMillis() / speed + off) + 1) / 2);
        return lerp(c1, c2, t);
    }
    public static int alpha(int col, int a) { return (col & 0xFFFFFF) | (MathHelper.clamp(a, 0, 255) << 24); }

    public static void rect(DrawContext c, float x, float y, float w, float h, int col) { c.fill((int) x, (int) y, (int) (x + w), (int) (y + h), col); }
    public static void hgrad(DrawContext c, int x, int y, int w, int h, double off) {
        for (int i = 0; i < w; i += 2) c.fill(x + i, y, Math.min(x + i + 2, x + w), y + h, accent(off + i * 0.02));
    }
    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int col) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int i = 0; i < r; i++) {
            int inset = (int) Math.round(r - Math.sqrt(r * r - (r - i - 0.5) * (r - i - 0.5)));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, col);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, col);
        }
        c.fill(x, y + r, x + w, y + h - r, col);
    }

    private static final String[] ARROWS = {"\u2191", "\u2197", "\u2192", "\u2198", "\u2193", "\u2199", "\u2190", "\u2196"};
    /** Top-centre direction hint: arrow + label + distance. */
    public static void arrow(DrawContext c, Vec3d target, String label) {
        var p = mc.player;
        float rel = MathHelper.wrapDegrees((float) (Math.toDegrees(Math.atan2(target.z - p.getZ(), target.x - p.getX())) - 90) - p.getYaw());
        String a = ARROWS[((int) Math.round(rel / 45.0) + 8) % 8];
        String s = a + "  " + label + "  " + (int) Math.hypot(target.x - p.getX(), target.z - p.getZ()) + " m";
        int w = w(s) + 16, x = c.getScaledWindowWidth() / 2 - w / 2;
        rrect(c, x, 8, w, 18, 5, 0xD0121217);
        hgrad(c, x + 3, 8, w - 6, 1, 1);
        text(c, s, x + 8, 13, 0xFFEDEDF5);
    }
}
