package dev.burmalda.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

public final class Gfx {
    private Gfx() {}
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public static final Identifier FONT = Identifier.of("burmalda", "main");

    public static Text t(String s) { return Text.literal(s).setStyle(Style.EMPTY.withFont(FONT)); }
    public static int w(String s) { return mc.textRenderer.getWidth(t(s)); }
    public static void text(DrawContext c, String s, float x, float y, int col) { c.drawText(mc.textRenderer, t(s), (int) x, (int) y, col, false); }

    public static int lerp(int a, int b, float t) {
        int ar = a >> 24 & 255, rr = a >> 16 & 255, gr = a >> 8 & 255, br = a & 255;
        int a2 = b >> 24 & 255, r2 = b >> 16 & 255, g2 = b >> 8 & 255, b2 = b & 255;
        return (int) (ar + (a2 - ar) * t) << 24 | (int) (rr + (r2 - rr) * t) << 16 | (int) (gr + (g2 - gr) * t) << 8 | (int) (br + (b2 - br) * t);
    }
    /** Animated purple <-> cyan flowing gradient. */
    public static int accent(double off) {
        float t = (float) ((Math.sin(System.currentTimeMillis() / 700.0 + off) + 1) / 2);
        return lerp(0xFF8A5CFF, 0xFF3CC8FF, t);
    }
    public static int alpha(int col, int a) { return (col & 0xFFFFFF) | (MathHelper.clamp(a, 0, 255) << 24); }

    public static void rect(DrawContext c, float x, float y, float w, float h, int col) { c.fill((int) x, (int) y, (int) (x + w), (int) (y + h), col); }
    public static void hgrad(DrawContext c, int x, int y, int w, int h, double off) {
        for (int i = 0; i < w; i += 2) c.fill(x + i, y, Math.min(x + i + 2, x + w), y + h, accent(off + i * 0.02));
    }
    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int col) {
        r = Math.min(r, Math.min(w, h) / 2);
        for (int i = 0; i < r; i++) {
            int inset = (int) Math.round(r - Math.sqrt(r * r - (r - i - 0.5) * (r - i - 0.5)));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, col);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, col);
        }
        c.fill(x, y + r, x + w, y + h - r, col);
    }
}
