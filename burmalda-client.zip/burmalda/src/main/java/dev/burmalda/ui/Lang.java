package dev.burmalda.ui;

import java.util.HashMap;
import java.util.Map;

/** Russian labels for setting names and mode values (module names stay English). */
public final class Lang {
    private Lang() {}
    private static final Map<String, String> M = new HashMap<>();
    private static void a(String... kv) { for (int i = 0; i + 1 < kv.length; i += 2) M.put(kv[i], kv[i + 1]); }
    static {
        a("Timing", "Тайминг", "Cooldown", "Кулдаун", "CPS", "CPS", "Targets", "Цели", "Single", "Одна", "Switch", "Переключать",
          "Shield breaker", "Ломать щиты", "Hit particles", "Частицы при ударе", "Crit", "Крит", "Hearts", "Сердца", "Flames", "Огонь", "Stars", "Звёзды",
          "Snow", "Снег", "Magic", "Магия", "Spiral", "Спираль", "Marker", "Маркер", "Line", "Линия", "Ribbon", "Лента", "Dots", "Точки", "Corners", "Углы",
          "Sky", "Небо", "Pink", "Розовое", "Blue", "Синее", "Teal", "Бирюзовое", "Vanilla", "Ванильное", "Time", "Время", "Dusk", "Закат", "Day", "День",
          "Night", "Ночь", "Server", "Как в мире", "Brightness", "Яркость", "Clouds", "Облака", "Target FPS", "Целевой FPS", "Smart particles", "Умные частицы",
          "Entity scaling", "Дальность сущностей", "Horizontal", "По горизонтали", "Vertical", "По вертикали", "Packet", "Пакетный", "Auto firework", "Авто-фейерверк",
          "Amount", "Количество", "Behind you", "Позади игрока", "Type", "Тип", "Lilac", "Сирень", "Hotkeys", "Бинды", "Cooldowns", "Кулдауны", "Notifications", "Уведомления",
          "Classic", "Классик", "Compact", "Компакт", "Circle", "Круг", "Minimal", "Минимал", "Preview", "Предпросмотр", "Corner boxes", "Угловые боксы", "Hitbox", "Хитбокс",
          "Bright", "Яркость", "Ground ring", "Кольцо на земле", "Dist", "Дист.",
          "Range", "Дистанция", "FOV", "Угол обзора", "Sharpness", "Резкость (кулдаун)", "Delay jitter", "Разброс задержки", "Rot speed", "Скорость наводки",
          "Rotation", "Наводка", "Smooth", "Плавная", "Snap", "Резкая", "Off", "Выкл", "Aim point", "Точка прицела", "Center", "Центр", "Nearest", "Ближайшая",
          "Priority", "Приоритет", "Distance", "Дистанция", "Health", "Здоровье", "Angle", "Угол", "Sticky target", "Липкая цель", "Through walls", "Через стены",
          "Crits", "Криты", "Wait fall", "Ждать падения", "Auto jump", "Авто-прыжок", "Sprint reset", "Сброс спринта", "Weapon only", "Только с оружием",
          "Players", "Игроки", "Hostile", "Враждебные", "Passive", "Мирные", "Ignore pets/villagers", "Не бить питомцев/жителей",
          "Mace on fall", "Булава при падении", "Mace min fall", "Мин. падение для булавы", "Health <=", "ХП не больше",
          "Min range", "Мин. дистанция", "Max range", "Макс. дистанция", "Auto swap to bow", "Авто-смена на лук",
          "Watermark", "Верхние плашки", "Coordinates", "Координаты", "Effects", "Эффекты", "Module list", "Список модулей", "Armor", "Броня",
          "Keystrokes", "Клавиши", "Compass", "Компас цели", "Style", "Стиль", "Rings", "Кольца", "Box", "Бокс", "Length", "Длина",
          "Target", "Цель", "All ores", "Все руды", "Diamond", "Алмаз", "Iron", "Железо", "Gold", "Золото", "Copper", "Медь", "Coal", "Уголь",
          "Redstone", "Редстоун", "Lapis", "Лазурит", "Emerald", "Изумруд", "Debris", "Незерит", "Quartz", "Кварц", "Chests", "Сундуки", "Spawners", "Спавнеры",
          "Logs", "Дерево", "Sand", "Песок", "Radius", "Радиус", "Items", "Предметы", "Boxes", "Боксы", "Tracers", "Трейсеры",
          "Hit marker", "Хитмаркер", "Damage numbers", "Цифры урона", "Cooldown ring", "Кольцо кулдауна",
          "Theme", "Тема", "Purple", "Фиолетовая", "Ocean", "Океан", "Sunset", "Закат", "Mint", "Мята", "Blood", "Кровь", "Rainbow", "Радуга", "Anim speed", "Скорость анимации",
          "Hunger <=", "Голод не больше", "Heal below HP", "Лечить ниже ХП", "Drop junk", "Выбрасывать мусор", "Drop when free <=", "Выбрасывать при свободных ≤",
          "Set chest (look at it)", "Задать сундук (смотри на него)", "Deposit when free <=", "Сдавать при свободных ≤",
          "Water MLG", "Водный MLG", "Lava escape", "Побег из лавы", "Auto respawn", "Авто-респавн", "Option (1-3)", "Вариант (1-3)", "Delay", "Задержка",
          "Only Mending items", "Только Mending", "Tunnel to buried", "Копать к скрытым", "Pick up drops", "Подбирать дроп", "Replant saplings", "Сажать саженцы",
          "Avoid water", "Избегать воды", "Mode", "Режим", "Straight", "Прямо", "Stairs down", "Лестница вниз", "Stairs up", "Лестница вверх",
          "Target Y", "Целевой Y", "Torches", "Факелы", "Torch gap", "Шаг факелов", "Structure", "Структура", "Village", "Деревня", "Stronghold", "Крепость",
          "Mansion", "Особняк", "Monument", "Монумент", "Fortress", "Адская крепость", "Bastion", "Бастион", "AncientCity", "Древний город",
          "TrialChambers", "Камеры испытаний", "Mineshaft", "Шахта", "Outpost", "Аванпост", "DesertTemple", "Пустынный храм", "JungleTemple", "Храм джунглей",
          "SwampHut", "Хижина ведьмы", "Igloo", "Иглу", "EndCity", "Город Края", "Walk there", "Идти туда", "Set home here", "Задать дом здесь",
          "Retreat HP", "ХП для отступления", "Resume HP", "ХП для возврата", "Scan range", "Радиус поиска", "Leash (0 = off)", "Привязка к точке (0 = выкл)",
          "Loot", "Лут", "Gunpowder", "Порох", "Bone", "Кость", "String", "Нить", "Any", "Всё", "Creeper spacing", "Дистанция от криперов", "Use bow", "Использовать лук",
          "Crop", "Культура", "All", "Все", "Wheat", "Пшеница", "Carrots", "Морковь", "Potatoes", "Картофель", "Beetroot", "Свёкла", "Nether wart", "Адский нарост",
          "Sugar cane", "Тростник", "Melon/Pumpkin", "Арбуз/Тыква", "Replant", "Пересаживать",
          "Max adults/species", "Макс. взрослых на вид", "Shear sheep", "Стричь овец", "Cull extras", "Резать лишних",
          "Speed", "Скорость", "Only while attacking", "Только при зажатой ЛКМ", "Fall distance", "Дистанция падения", "Only in combat", "Только в бою",
          "Plan", "План", "Wheat farm", "Ферма пшеницы", "Carrot farm", "Ферма моркови", "Potato farm", "Ферма картофеля", "Beetroot farm", "Ферма свёклы",
          "Sugar cane farm", "Ферма тростника", "Shelter", "Убежище", "File", "Файл схемы", "Auto start", "Автостарт", "Creative fill", "Выдача в креативе", "Clear area", "Расчистка");
    }
    public static String tr(String s) { return M.getOrDefault(s, s); }
}
