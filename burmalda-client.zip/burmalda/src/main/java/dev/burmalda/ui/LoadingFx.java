package dev.burmalda.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.DownloadingTerrainScreen;
import net.minecraft.client.gui.screen.ProgressScreen;
import net.minecraft.client.gui.screen.Screen;

/** Replaces the vanilla world loading / saving screens with an animated, cheap one. */
public final class LoadingFx {
    private LoadingFx() {}
    private static final Particles2D ps = new Particles2D();
    private static long last;

    public static boolean applies(Screen s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (s instanceof BurmaldaTitle || s instanceof ClickGui) return false;
        return s instanceof DownloadingTerrainScreen || s instanceof ProgressScreen || (mc.getServer() != null && mc.world == null);
    }

    public static void render(DrawContext c, int w, int h) {
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        c.fillGradient(0, 0, w, h, 0xFF150C26, 0xFF45306E);
        ps.ambient(w, h); ps.update(dt); ps.render(c);
        c.getMatrices().push();
        c.getMatrices().translate(w / 2f, h / 2f - 34, 0);
        c.getMatrices().scale(2.4f, 2.4f, 1f);
        Gfx.btext(c, "Burmalda", -Gfx.bw("Burmalda") / 2f, 0, 0xFFFFFFFF);
        c.getMatrices().pop();
        String s = "Загрузка мира...";
        Gfx.text(c, s, w / 2f - Gfx.w(s) / 2f, h / 2f + 4, 0xFFB8A8DC);
        int bw = 160, bx = w / 2 - bw / 2, by = h / 2 + 22;
        Gfx.rrect(c, bx, by, bw, 4, 2, 0xFF2A2140);
        float t = (System.currentTimeMillis() % 1400) / 1400f;
        int seg = 50, sx = bx + (int) ((bw + seg) * t) - seg;
        int x1 = Math.max(bx, sx), x2 = Math.min(bx + bw, sx + seg);
        if (x2 > x1) Gfx.rrect(c, x1, by, x2 - x1, 4, 2, Gfx.accent(0));
    }
}
