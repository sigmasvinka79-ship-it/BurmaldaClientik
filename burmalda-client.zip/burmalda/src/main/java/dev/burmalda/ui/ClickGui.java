package dev.burmalda.ui;

import dev.burmalda.core.Config;
import dev.burmalda.core.Module;
import dev.burmalda.core.Module.Category;
import dev.burmalda.core.ModuleManager;
import dev.burmalda.core.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class ClickGui extends Screen {
    private static final int SB = 100, SH = 17, CH = 22;
    private static final int RENDER = 0, CLICK = 1, DRAG = 2;
    private static Category sel = Category.COMBAT;
    private static int scroll;

    private final long opened = System.currentTimeMillis();
    private int x0, y0, W, H, contentH;
    private Module binding;
    private Setting.Num dragNum;

    public ClickGui() { super(Text.literal("Burmalda")); }

    @Override public boolean shouldPause() { return false; }
    @Override public void removed() { Config.save(); }

    private double ease() {
        double t = Math.min(1.0, (System.currentTimeMillis() - opened) / 240.0);
        return 1 - Math.pow(1 - t, 3);
    }
    private void layout() {
        W = Math.min(470, width - 16);
        H = Math.min(300, height - 16);
        x0 = (width - W) / 2;
        y0 = (height - H) / 2 + (int) ((1 - ease()) * -26);
    }
    private static boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    private static String icon(Category c) {
        return switch (c) { case COMBAT -> "c_combat"; case RENDER -> "c_render"; case PLAYER -> "c_player"; case WORLD -> "c_world"; default -> "c_farm"; };
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        layout();
        c.fill(0, 0, width, height, Gfx.alpha(0x050508, (int) (0xB0 * ease())));
        Gfx.rrect(c, x0 - 2, y0 - 2, W + 4, H + 4, 12, 0x50000000);
        Gfx.rrect(c, x0, y0, W, H, 10, 0xFF111116);
        Gfx.rrect(c, x0, y0, SB, H, 10, 0xFF0A0A0E);
        c.fill(x0 + SB - 10, y0, x0 + SB, y0 + H, 0xFF0A0A0E);
        Gfx.icon(c, "logo", x0 + 10, y0 + 10, 18, Gfx.accent(0));
        Gfx.btext(c, "Burmalda", x0 + 33, y0 + 9, 0xFFFFFFFF);
        Gfx.text(c, "1.2 beta", x0 + 33, y0 + 20, 0xFF7A7A8C);
        int cy = y0 + 46;
        for (Category cat : Category.values()) {
            boolean s = cat == sel;
            if (s) Gfx.rrect(c, x0 + 7, cy, SB - 14, 24, 7, Gfx.alpha(Gfx.accent(cy * 0.04), 80));
            Gfx.icon(c, icon(cat), x0 + 15, cy + 6, 12, s ? 0xFFFFFFFF : 0xFF8E8E9C);
            Gfx.btext(c, cat.label, x0 + 34, cy + 7, s ? 0xFFFFFFFF : 0xFF9A9AA8);
            cy += 28;
        }
        Gfx.text(c, "Меню: Right Shift", x0 + 10, y0 + H - 22, 0xFF55556A);
        Gfx.text(c, ".help — команды", x0 + 10, y0 + H - 12, 0xFF55556A);

        int cx = x0 + SB + 12;
        Gfx.btext(c, sel.label, cx, y0 + 12, 0xFFFFFFFF);
        Gfx.text(c, ModuleManager.of(sel).size() + " модулей  |  ЛКМ — вкл/выкл, ПКМ — настройки, СКМ — бинд", cx + Gfx.bw(sel.label) + 8, y0 + 13, 0xFF6A6A7C);
        Gfx.hgrad(c, cx, y0 + 28, W - SB - 24, 1, 2);
        c.enableScissor(cx - 4, y0 + 32, x0 + W - 4, y0 + H - 6);
        walk(c, mx, my, RENDER, 0);
        c.disableScissor();
    }

    private void walk(DrawContext c, double mx, double my, int mode, int btn) {
        int cx = x0 + SB + 12, cw = W - SB - 24, colW = (cw - 8) / 2, top = y0 + 36, bottom = y0 + H - 8;
        if (mode == CLICK && !in(mx, my, cx, top, cw, bottom - top)) return;
        int[] colY = {0, 0};
        for (Module m : ModuleManager.of(sel)) {
            int col = colY[0] <= colY[1] ? 0 : 1;
            int x = cx + col * (colW + 8), y = top + colY[col] - scroll;
            int h = CH + (m.expanded ? m.settings.size() * SH + 4 : 0);
            boolean hover = in(mx, my, x, y, colW, CH);
            if (mode == RENDER) {
                Gfx.rrect(c, x, y, colW, h, 7, 0xFF18181F);
                if (m.enabled) Gfx.rrect(c, x, y, colW, h, 7, Gfx.alpha(Gfx.accent(y * 0.03), 38));
                else if (hover) Gfx.rrect(c, x, y, colW, h, 7, 0x18FFFFFF);
                Gfx.btext(c, m.name, x + 9, y + 7, m.enabled ? 0xFFFFFFFF : 0xFFA4A4B4);
                Gfx.rrect(c, x + colW - 27, y + 7, 19, 9, 4, m.enabled ? Gfx.accent(y * 0.05) : 0xFF2A2A33);
                Gfx.rrect(c, x + colW - (m.enabled ? 17 : 26), y + 8, 7, 7, 3, 0xFFFFFFFF);
                String r = binding == m ? "..." : m.key >= 0 ? "[" + keyName(m.key) + "]" : "";
                if (!r.isEmpty()) Gfx.text(c, r, x + colW - 33 - Gfx.w(r), y + 7, 0xFF7A7A8C);
            } else if (mode == CLICK && hover) {
                if (btn == 0) m.toggle();
                else if (btn == 1) m.expanded = !m.expanded;
                else if (btn == 2) binding = m;
            }
            int sy = y + CH + 2;
            if (m.expanded) for (Setting<?> s : m.settings) { settingRow(c, s, x, sy, colW, mx, my, mode, btn); sy += SH; }
            colY[col] += h + 6;
        }
        if (mode == RENDER) contentH = Math.max(colY[0], colY[1]);
    }

    private void settingRow(DrawContext c, Setting<?> s, int x, int cy, int w, double mx, double my, int mode, int btn) {
        boolean hover = in(mx, my, x, cy, w, SH);
        String label = Lang.tr(s.name);
        if (s instanceof Setting.Bool b) {
            if (mode == RENDER) {
                Gfx.text(c, label, x + 10, cy + 4, 0xFFB5B5C4);
                Gfx.rrect(c, x + w - 28, cy + 3, 19, 9, 4, b.get() ? Gfx.accent(cy * 0.05) : 0xFF2A2A33);
                Gfx.rrect(c, x + w - (b.get() ? 18 : 27), cy + 4, 7, 7, 3, 0xFFFFFFFF);
            } else if (mode == CLICK && hover && btn == 0) b.value = !b.get();
        } else if (s instanceof Setting.Num n) {
            double frac = (n.get() - n.min) / (n.max - n.min);
            if (mode == RENDER) {
                Gfx.rrect(c, x + 8, cy + SH - 4, w - 16, 3, 1, 0xFF2A2A33);
                Gfx.hgrad(c, x + 8, cy + SH - 4, Math.max(2, (int) ((w - 16) * frac)), 3, cy * 0.05);
                Gfx.text(c, label, x + 10, cy, 0xFFB5B5C4);
                String v = n.step >= 1 ? String.valueOf(n.i()) : String.format(java.util.Locale.ROOT, "%.2f", n.get());
                Gfx.text(c, v, x + w - 10 - Gfx.w(v), cy, 0xFFE0E0EE);
            } else if (mode == CLICK && hover && btn == 0) { dragNum = n; n.set(n.min + (mx - (x + 8)) / (w - 16) * (n.max - n.min)); }
            else if (mode == DRAG && dragNum == n) n.set(n.min + (mx - (x + 8)) / (w - 16) * (n.max - n.min));
        } else if (s instanceof Setting.Mode md) {
            if (mode == RENDER) {
                Gfx.text(c, label, x + 10, cy + 4, 0xFFB5B5C4);
                String v = Lang.tr(md.value);
                Gfx.text(c, v, x + w - 10 - Gfx.w(v), cy + 4, Gfx.accent(cy * 0.05));
            } else if (mode == CLICK && hover) md.cycle(btn == 1 ? -1 : 1);
        }
    }

    private static String keyName(int k) {
        String n = GLFW.glfwGetKeyName(k, 0);
        return n != null ? n.toUpperCase() : "K" + k;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        layout();
        int cy = y0 + 46;
        for (Category cat : Category.values()) {
            if (in(mx, my, x0 + 7, cy, SB - 14, 24)) { sel = cat; scroll = 0; return true; }
            cy += 28;
        }
        walk(null, mx, my, CLICK, btn);
        return true;
    }
    @Override public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) { layout(); walk(null, mx, my, DRAG, btn); return true; }
    @Override public boolean mouseReleased(double mx, double my, int btn) { dragNum = null; return true; }
    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        int max = Math.max(0, contentH - (H - 44));
        scroll = Math.max(0, Math.min(max, scroll - (int) (v * 22)));
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (binding != null) {
            binding.key = key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_DELETE ? -1 : key;
            binding = null;
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }
}
