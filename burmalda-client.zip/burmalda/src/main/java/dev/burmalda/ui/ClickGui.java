package dev.burmalda.ui;

import dev.burmalda.core.Config;
import dev.burmalda.core.HudLayout;
import dev.burmalda.core.Module;
import dev.burmalda.core.Module.Category;
import dev.burmalda.core.ModuleManager;
import dev.burmalda.core.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ClickGui extends Screen {
    private static final int SB = 112, SH = 17, RH = 21;
    private static final int RENDER = 0, CLICK = 1, DRAG = 2;
    private static Category sel = Category.COMBAT;
    private static int scroll;

    private final long opened = System.currentTimeMillis();
    private final Particles2D ps = new Particles2D();
    private long last;
    private int x0, y0, W, H, contentH;
    private Module binding;
    private Setting.Num dragNum;
    private String search = "";
    private boolean searchFocus;

    public ClickGui() { super(Text.literal("Burmalda")); }

    @Override public boolean shouldPause() { return false; }
    @Override protected void init() { HudLayout.editing = true; }
    @Override public void removed() { HudLayout.editing = false; HudLayout.release(); Config.save(); }

    private double ease() {
        double t = Math.min(1.0, (System.currentTimeMillis() - opened) / 240.0);
        return 1 - Math.pow(1 - t, 3);
    }
    private void layout() {
        W = Math.min(540, width - 16);
        H = Math.min(340, height - 16);
        x0 = (width - W) / 2;
        y0 = (height - H) / 2 + (int) ((1 - ease()) * -26);
    }
    private static boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    private static String icon(Category c) {
        return switch (c) { case COMBAT -> "c_combat"; case MOVEMENT -> "c_move"; case RENDER -> "c_render"; case PLAYER -> "c_player";
            case WORLD -> "c_world"; case FARM -> "c_farm"; default -> "c_misc"; };
    }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        layout();
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        c.fill(0, 0, width, height, Gfx.alpha(0x000000, (int) (0x70 * ease())));
        for (Map.Entry<String, int[]> e : HudLayout.bounds().entrySet()) { // drag outlines
            int[] b = e.getValue();
            int col = e.getKey().equals(HudLayout.dragging()) ? Gfx.alpha(Gfx.accent(0), 230) : Gfx.alpha(Gfx.accent(0), 90);
            c.fill(b[0] - 1, b[1] - 1, b[0] + b[2] + 1, b[1], col); c.fill(b[0] - 1, b[1] + b[3], b[0] + b[2] + 1, b[1] + b[3] + 1, col);
            c.fill(b[0] - 1, b[1], b[0], b[1] + b[3], col); c.fill(b[0] + b[2], b[1], b[0] + b[2] + 1, b[1] + b[3], col);
        }
        Gfx.rrect(c, x0 - 2, y0 - 2, W + 4, H + 4, 14, 0x50000000);
        Gfx.rrect(c, x0, y0, W, H, 12, 0xF4100F14);
        Gfx.rrect(c, x0, y0, SB, H, 12, 0xF40B0A0E);
        c.fill(x0 + SB - 12, y0, x0 + SB, y0 + H, 0xF40B0A0E);
        Gfx.icon(c, "logo", x0 + 14, y0 + 13, 20, Gfx.accent(0));
        Gfx.btext(c, "Burmalda", x0 + 40, y0 + 14, 0xFFFFFFFF);
        Gfx.text(c, "FEATURES", x0 + 14, y0 + 48, 0xFF50505F);
        int cy = y0 + 62;
        for (Category cat : Category.values()) {
            boolean s = cat == sel && search.isEmpty();
            if (s) Gfx.rrect(c, x0 + 8, cy, SB - 16, 22, 7, 0x22FFFFFF);
            Gfx.icon(c, icon(cat), x0 + 16, cy + 5, 12, s ? Gfx.accent(0) : 0xFF7E7E8E);
            Gfx.btext(c, cat.label, x0 + 36, cy + 5, s ? 0xFFFFFFFF : 0xFF8E8E9E);
            cy += 25;
        }
        Gfx.text(c, ".help — команды чата", x0 + 14, y0 + H - 24, 0xFF50505F);
        Gfx.text(c, "Тяни элементы HUD мышью", x0 + 14, y0 + H - 13, 0xFF50505F);

        int cx = x0 + SB + 14;
        try {
            c.drawTexture(mc().player.getSkinTextures().texture(), cx, y0 + 10, 22, 22, 8f, 8f, 8, 8, 64, 64);
        } catch (Throwable t) { Gfx.rrect(c, cx, y0 + 10, 22, 22, 11, 0xFF2A2A33); }
        Gfx.btext(c, mc().getSession().getUsername(), cx + 29, y0 + 11, 0xFFFFFFFF);
        Gfx.text(c, "Burmalda 1.2 release", cx + 29, y0 + 22, 0xFF6E6E80);
        int sbx = x0 + W - 190, sby = y0 + 11;
        Gfx.rrect(c, sbx, sby, 150, 20, 7, searchFocus ? 0xFF1E1B28 : 0xFF17151D);
        Gfx.icon(c, "search", sbx + 7, sby + 5, 10, 0xFF7E7E8E);
        String st = search.isEmpty() ? "Search something" : search + (searchFocus && System.currentTimeMillis() / 400 % 2 == 0 ? "|" : "");
        Gfx.text(c, st, sbx + 22, sby + 6, search.isEmpty() ? 0xFF55556A : 0xFFE0E0EE);
        if (search.isEmpty()) Gfx.text(c, "CTRL+F", sbx + 150 - 8 - Gfx.w("CTRL+F"), sby + 6, 0xFF444455);
        Gfx.icon(c, "gear", x0 + W - 28, y0 + 14, 14, 0xFF7E7E8E);

        c.enableScissor(cx - 4, y0 + 40, x0 + W - 4, y0 + H - 6);
        walk(c, mx, my, RENDER, 0);
        c.disableScissor();
        ps.update(dt); ps.render(c);
    }

    private static net.minecraft.client.MinecraftClient mc() { return net.minecraft.client.MinecraftClient.getInstance(); }

    private Map<String, List<Module>> groups() {
        Map<String, List<Module>> g = new LinkedHashMap<>();
        if (!search.isEmpty()) {
            List<Module> r = new ArrayList<>();
            for (Module m : ModuleManager.ALL) if (m.name.toLowerCase().contains(search.toLowerCase())) r.add(m);
            g.put("Результаты", r);
            return g;
        }
        for (Module m : ModuleManager.of(sel)) g.computeIfAbsent(m.group.isEmpty() ? sel.label : m.group, k -> new ArrayList<>()).add(m);
        return g;
    }

    private void walk(DrawContext c, double mx, double my, int mode, int btn) {
        int cx = x0 + SB + 14, cw = W - SB - 28, colW = (cw - 12) / 2, top = y0 + 44, bottom = y0 + H - 8;
        if (mode == CLICK && !in(mx, my, cx, top, cw, bottom - top)) return;
        int[] colY = {0, 0};
        int gi = 0;
        for (Map.Entry<String, List<Module>> ge : groups().entrySet()) {
            boolean flat = !search.isEmpty();
            List<Module> list = ge.getValue();
            for (int pass = 0; pass < (flat ? 2 : 1); pass++) {
                int col = flat ? pass : gi % 2;
                int x = cx + col * (colW + 12), y = top + colY[col] - scroll;
                if (mode == RENDER) {
                    Gfx.rrect(c, x, y, colW, 22, 8, 0xFF16141C);
                    Gfx.btext(c, ge.getKey(), x + 10, y + 6, 0xFFFFFFFF);
                    Gfx.icon(c, "chev", x + colW - 20, y + 6, 10, 0xFF7E7E8E);
                }
                colY[col] += 26;
                for (int mi = pass; mi < list.size(); mi += flat ? 2 : 1) colY[col] += row(c, list.get(mi), x, top + colY[col] - scroll, colW, mx, my, mode, btn);
            }
            gi++;
        }
        if (mode == RENDER) contentH = Math.max(colY[0], colY[1]);
    }

    /** draws one module row (+ expanded settings); returns the consumed height */
    private int row(DrawContext c, Module m, int x, int y, int w, double mx, double my, int mode, int btn) {
        int h = RH + (m.expanded ? m.settings.size() * SH + 4 : 0);
        boolean hover = in(mx, my, x, y, w, RH);
        if (mode == RENDER) {
            if (hover) Gfx.rrect(c, x, y, w, RH, 7, 0x14FFFFFF);
            Gfx.btext(c, m.name, x + 10, y + 6, m.enabled ? 0xFFFFFFFF : 0xFFC0C0CE);
            Gfx.rrect(c, x + w - 30, y + 6, 22, 10, 5, m.enabled ? Gfx.accent(y * 0.03) : 0xFF2A2A31);
            Gfx.rrect(c, x + w - (m.enabled ? 19 : 28), y + 7, 8, 8, 4, m.enabled ? 0xFFFFFFFF : 0xFF77778A);
            int rx = x + w - 38;
            if (!m.settings.isEmpty()) { Gfx.icon(c, "dots", rx - 12, y + 6, 12, 0xFF7E7E8E); rx -= 18; }
            String r = binding == m ? "..." : m.key >= 0 ? "[" + keyName(m.key) + "]" : "";
            if (!r.isEmpty()) Gfx.text(c, r, rx - Gfx.w(r), y + 6, 0xFF7A7A8C);
        } else if (mode == CLICK && hover) {
            if (btn == 0) { if (mx > x + w - 62 && !m.settings.isEmpty() && mx < x + w - 34) m.expanded = !m.expanded; else m.toggle(); }
            else if (btn == 1) m.expanded = !m.expanded;
            else if (btn == 2) binding = m;
        }
        int sy = y + RH + 2;
        if (m.expanded) for (Setting<?> s : m.settings) { settingRow(c, s, x + 8, sy, w - 8, mx, my, mode, btn); sy += SH; }
        return h + 3;
    }

    private void settingRow(DrawContext c, Setting<?> s, int x, int cy, int w, double mx, double my, int mode, int btn) {
        boolean hover = in(mx, my, x, cy, w, SH);
        String label = Lang.tr(s.name);
        if (s instanceof Setting.Bool b) {
            if (mode == RENDER) {
                Gfx.text(c, label, x + 6, cy + 4, 0xFFB5B5C4);
                Gfx.rrect(c, x + w - 28, cy + 3, 20, 9, 4, b.get() ? Gfx.accent(cy * 0.05) : 0xFF2A2A31);
                Gfx.rrect(c, x + w - (b.get() ? 17 : 26), cy + 4, 7, 7, 3, 0xFFFFFFFF);
            } else if (mode == CLICK && hover && btn == 0) b.value = !b.get();
        } else if (s instanceof Setting.Num n) {
            double frac = (n.get() - n.min) / (n.max - n.min);
            if (mode == RENDER) {
                Gfx.rrect(c, x + 6, cy + SH - 4, w - 12, 3, 1, 0xFF2A2A31);
                Gfx.hgrad(c, x + 6, cy + SH - 4, Math.max(2, (int) ((w - 12) * frac)), 3, cy * 0.05);
                Gfx.text(c, label, x + 6, cy, 0xFFB5B5C4);
                String v = n.step >= 1 ? String.valueOf(n.i()) : String.format(java.util.Locale.ROOT, "%.2f", n.get());
                Gfx.text(c, v, x + w - 8 - Gfx.w(v), cy, 0xFFE0E0EE);
            } else if (mode == CLICK && hover && btn == 0) { dragNum = n; n.set(n.min + (mx - (x + 6)) / (w - 12) * (n.max - n.min)); }
            else if (mode == DRAG && dragNum == n) n.set(n.min + (mx - (x + 6)) / (w - 12) * (n.max - n.min));
        } else if (s instanceof Setting.Mode md) {
            if (mode == RENDER) {
                Gfx.text(c, label, x + 6, cy + 4, 0xFFB5B5C4);
                String v = Lang.tr(md.value);
                Gfx.text(c, v, x + w - 8 - Gfx.w(v), cy + 4, Gfx.accent(cy * 0.05));
            } else if (mode == CLICK && hover) md.cycle(btn == 1 ? -1 : 1);
        }
    }

    private static String keyName(int k) {
        String n = GLFW.glfwGetKeyName(k, 0);
        return n != null ? n.toUpperCase() : "K" + k;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        layout();
        ps.burst((float) mx, (float) my, 12);
        if (!in(mx, my, x0, y0, W, H)) { HudLayout.press(mx, my); return true; }
        int sbx = x0 + W - 190, sby = y0 + 11;
        searchFocus = in(mx, my, sbx, sby, 150, 20);
        if (in(mx, my, x0 + W - 30, y0 + 12, 18, 18)) { HudLayout.reset(); return true; }
        int cy = y0 + 62;
        for (Category cat : Category.values()) {
            if (in(mx, my, x0 + 8, cy, SB - 16, 22)) { sel = cat; scroll = 0; search = ""; return true; }
            cy += 25;
        }
        walk(null, mx, my, CLICK, btn);
        return true;
    }
    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        layout();
        if (HudLayout.dragging() != null) { HudLayout.dragTo(mx, my); return true; }
        walk(null, mx, my, DRAG, btn);
        return true;
    }
    @Override public boolean mouseReleased(double mx, double my, int btn) { dragNum = null; HudLayout.release(); Config.save(); return true; }
    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        int max = Math.max(0, contentH - (H - 52));
        scroll = Math.max(0, Math.min(max, scroll - (int) (v * 22)));
        return true;
    }
    @Override
    public boolean charTyped(char chr, int mods) {
        if (searchFocus && chr >= 32) { search += chr; scroll = 0; return true; }
        return super.charTyped(chr, mods);
    }
    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (binding != null) {
            binding.key = key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_DELETE ? -1 : key;
            binding = null;
            return true;
        }
        if (key == GLFW.GLFW_KEY_F && (mods & GLFW.GLFW_MOD_CONTROL) != 0) { searchFocus = true; return true; }
        if (searchFocus && key == GLFW.GLFW_KEY_BACKSPACE) { if (!search.isEmpty()) search = search.substring(0, search.length() - 1); return true; }
        if (key == GLFW.GLFW_KEY_ESCAPE && (searchFocus || !search.isEmpty())) { search = ""; searchFocus = false; return true; }
        return super.keyPressed(key, scan, mods);
    }
}
