package dev.burmalda.ui;

import dev.burmalda.core.Config;
import dev.burmalda.core.Module;
import dev.burmalda.core.Module.Category;
import dev.burmalda.core.ModuleManager;
import dev.burmalda.core.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.EnumMap;
import java.util.Map;

public class ClickGui extends Screen {
    private static final int W = 116, HH = 22, MH = 18, SH = 16;
    private static final int RENDER = 0, CLICK = 1, DRAG = 2;
    private static final Map<Category, int[]> POS = new EnumMap<>(Category.class);
    private static int scroll;

    private final long opened = System.currentTimeMillis();
    private Module binding;
    private Setting.Num dragNum;
    private Category dragPanel;
    private double dox, doy;

    public ClickGui() { super(Text.literal("Burmalda")); }

    private int[] pos(Category c) {
        return POS.computeIfAbsent(c, k -> new int[]{10 + k.ordinal() * (W + 8), 24});
    }
    @Override public boolean shouldPause() { return false; }
    @Override public void removed() { Config.save(); }

    private double ease() {
        double t = Math.min(1.0, (System.currentTimeMillis() - opened) / 220.0);
        return 1 - Math.pow(1 - t, 3);
    }
    private int panelHeight(Category cat) {
        int h = HH + 4;
        for (Module m : ModuleManager.of(cat)) {
            h += MH;
            if (m.expanded) h += SH * m.settings.size();
        }
        return h;
    }
    private static boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        c.fill(0, 0, width, height, Gfx.alpha(0x050508, (int) (0x99 * ease())));
        walk(c, mx, my, RENDER, 0);
        Gfx.text(c, "Burmalda Client 1.1  |  LMB toggle  RMB settings  MMB bind  Scroll move", 8, height - 14, 0xFF8A8A99);
    }

    private void walk(DrawContext c, double mx, double my, int mode, int btn) {
        int anim = (int) ((1 - ease()) * -40);
        for (Category cat : Category.values()) {
            int[] p = pos(cat);
            int x = p[0], y = p[1] + scroll + anim;
            if (mode == RENDER) {
                Gfx.rrect(c, x - 1, y - 1, W + 2, panelHeight(cat) + 2, 5, 0x55000000);
                Gfx.rrect(c, x, y, W, panelHeight(cat), 5, 0xF0121217);
                Gfx.hgrad(c, x + 4, y + HH - 2, W - 8, 1, cat.ordinal());
                Gfx.text(c, cat.label, x + 8, y + 7, 0xFFEDEDF5);
            } else if (mode == CLICK && btn == 0 && in(mx, my, x, y, W, HH)) {
                dragPanel = cat; dox = mx - x; doy = my - y;
            } else if (mode == DRAG && dragPanel == cat) {
                p[0] = (int) (mx - dox); p[1] = (int) (my - doy) - scroll - anim;
            }
            int cy = y + HH + 2;
            for (Module m : ModuleManager.of(cat)) {
                boolean hover = in(mx, my, x, cy, W, MH);
                if (mode == RENDER) {
                    if (m.enabled) Gfx.rrect(c, x + 3, cy, W - 6, MH - 1, 3, Gfx.alpha(Gfx.accent(cy * 0.03), 90));
                    else if (hover) Gfx.rrect(c, x + 3, cy, W - 6, MH - 1, 3, 0x30FFFFFF);
                    Gfx.text(c, m.name, x + 9, cy + 5, m.enabled ? 0xFFFFFFFF : 0xFFA9A9B8);
                    String r = binding == m ? "..." : m.key >= 0 ? "[" + keyName(m.key) + "]" : (m.settings.isEmpty() ? "" : (m.expanded ? "-" : "+"));
                    Gfx.text(c, r, x + W - 9 - Gfx.w(r), cy + 5, 0xFF7A7A8C);
                } else if (mode == CLICK && hover) {
                    if (btn == 0) m.toggle();
                    else if (btn == 1) m.expanded = !m.expanded;
                    else if (btn == 2) binding = m;
                }
                cy += MH;
                if (m.expanded) for (Setting<?> s : m.settings) { settingRow(c, s, x, cy, mx, my, mode, btn); cy += SH; }
            }
        }
    }

    private void settingRow(DrawContext c, Setting<?> s, int x, int cy, double mx, double my, int mode, int btn) {
        boolean hover = in(mx, my, x, cy, W, SH);
        if (s instanceof Setting.Bool b) {
            if (mode == RENDER) {
                Gfx.text(c, s.name, x + 10, cy + 4, 0xFFB5B5C4);
                Gfx.rrect(c, x + W - 28, cy + 3, 18, 9, 4, b.get() ? Gfx.accent(cy * 0.05) : 0xFF2A2A33);
                Gfx.rrect(c, x + W - (b.get() ? 21 : 27), cy + 4, 7, 7, 3, 0xFFFFFFFF);
            } else if (mode == CLICK && hover && btn == 0) b.value = !b.get();
        } else if (s instanceof Setting.Num n) {
            double frac = (n.get() - n.min) / (n.max - n.min);
            if (mode == RENDER) {
                Gfx.rect(c, x + 8, cy + SH - 4, W - 16, 2, 0xFF2A2A33);
                Gfx.hgrad(c, x + 8, cy + SH - 4, (int) ((W - 16) * frac), 2, cy * 0.05);
                Gfx.text(c, s.name, x + 10, cy + 1, 0xFFB5B5C4);
                String v = n.step >= 1 ? String.valueOf(n.i()) : String.format("%.2f", n.get());
                Gfx.text(c, v, x + W - 10 - Gfx.w(v), cy + 1, 0xFFE0E0EE);
            } else if (mode == CLICK && hover && btn == 0) { dragNum = n; n.set(n.min + (mx - (x + 8)) / (W - 16) * (n.max - n.min)); }
            else if (mode == DRAG && dragNum == n) n.set(n.min + (mx - (x + 8)) / (W - 16) * (n.max - n.min));
        } else if (s instanceof Setting.Mode md) {
            if (mode == RENDER) {
                Gfx.text(c, s.name, x + 10, cy + 4, 0xFFB5B5C4);
                Gfx.text(c, md.value, x + W - 10 - Gfx.w(md.value), cy + 4, Gfx.accent(cy * 0.05));
            } else if (mode == CLICK && hover) md.cycle(btn == 1 ? -1 : 1);
        }
    }

    private static String keyName(int k) {
        String n = GLFW.glfwGetKeyName(k, 0);
        return n != null ? n.toUpperCase() : "K" + k;
    }

    @Override public boolean mouseClicked(double mx, double my, int btn) { walk(null, mx, my, CLICK, btn); return true; }
    @Override public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) { walk(null, mx, my, DRAG, btn); return true; }
    @Override public boolean mouseReleased(double mx, double my, int btn) { dragPanel = null; dragNum = null; return true; }
    @Override public boolean mouseScrolled(double mx, double my, double h, double v) { scroll += (int) (v * 24); return true; }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (binding != null) {
            binding.key = key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_DELETE ? -1 : key;
            binding = null;
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }
}
