package dev.burmalda.ui;

import net.minecraft.client.render.VertexConsumer;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.util.math.MatrixStack;

public final class Render3D {
    private Render3D() {}

    public static void line(VertexConsumer vc, MatrixStack.Entry e, Vec3d cam, Vec3d a, Vec3d b, int col) {
        int al = col >> 24 & 255, r = col >> 16 & 255, g = col >> 8 & 255, bl = col & 255;
        Vec3d n = b.subtract(a);
        n = n.lengthSquared() < 1e-9 ? new Vec3d(0, 1, 0) : n.normalize();
        vc.vertex(e, (float) (a.x - cam.x), (float) (a.y - cam.y), (float) (a.z - cam.z)).color(r, g, bl, al).normal(e, (float) n.x, (float) n.y, (float) n.z);
        vc.vertex(e, (float) (b.x - cam.x), (float) (b.y - cam.y), (float) (b.z - cam.z)).color(r, g, bl, al).normal(e, (float) n.x, (float) n.y, (float) n.z);
    }

    public static void box(VertexConsumer vc, MatrixStack.Entry e, Vec3d cam, Box b, int col) {
        Vec3d[] v = {
            new Vec3d(b.minX, b.minY, b.minZ), new Vec3d(b.maxX, b.minY, b.minZ), new Vec3d(b.maxX, b.minY, b.maxZ), new Vec3d(b.minX, b.minY, b.maxZ),
            new Vec3d(b.minX, b.maxY, b.minZ), new Vec3d(b.maxX, b.maxY, b.minZ), new Vec3d(b.maxX, b.maxY, b.maxZ), new Vec3d(b.minX, b.maxY, b.maxZ)};
        int[][] edges = {{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
        for (int[] ed : edges) line(vc, e, cam, v[ed[0]], v[ed[1]], col);
    }
}
