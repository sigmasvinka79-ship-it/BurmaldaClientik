package dev.burmalda.ui;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public final class Render3D {
    private Render3D() {}

    // ---------- depth-tested lines through the vanilla buffer ----------
    public static void line(VertexConsumer vc, MatrixStack.Entry e, Vec3d cam, Vec3d a, Vec3d b, int col) {
        int al = col >> 24 & 255, r = col >> 16 & 255, g = col >> 8 & 255, bl = col & 255;
        Vec3d n = b.subtract(a);
        n = n.lengthSquared() < 1e-9 ? new Vec3d(0, 1, 0) : n.normalize();
        vc.vertex(e, (float) (a.x - cam.x), (float) (a.y - cam.y), (float) (a.z - cam.z)).color(r, g, bl, al).normal(e, (float) n.x, (float) n.y, (float) n.z);
        vc.vertex(e, (float) (b.x - cam.x), (float) (b.y - cam.y), (float) (b.z - cam.z)).color(r, g, bl, al).normal(e, (float) n.x, (float) n.y, (float) n.z);
    }
    public static void box(VertexConsumer vc, MatrixStack.Entry e, Vec3d cam, Box b, int col) {
        Vec3d[] v = corners(b);
        for (int[] ed : EDGES) line(vc, e, cam, v[ed[0]], v[ed[1]], col);
    }

    private static final int[][] EDGES = {{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
    private static Vec3d[] corners(Box b) {
        return new Vec3d[]{
            new Vec3d(b.minX, b.minY, b.minZ), new Vec3d(b.maxX, b.minY, b.minZ), new Vec3d(b.maxX, b.minY, b.maxZ), new Vec3d(b.minX, b.minY, b.maxZ),
            new Vec3d(b.minX, b.maxY, b.minZ), new Vec3d(b.maxX, b.maxY, b.minZ), new Vec3d(b.maxX, b.maxY, b.maxZ), new Vec3d(b.minX, b.maxY, b.maxZ)};
    }

    /** Lines drawn without depth test (visible through walls). Usage: begin(ctx); line/box...; end(). */
    public static final class Through {
        private Through() {}
        private static BufferBuilder bb;
        private static Matrix4f m;
        private static Vec3d cam;
        private static int n;

        public static void begin(WorldRenderContext ctx) {
            m = ctx.matrixStack().peek().getPositionMatrix();
            cam = ctx.camera().getPos();
            bb = null; n = 0;
        }
        private static void v(Vec3d p, int col) {
            if (bb == null) bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
            bb.vertex(m, (float) (p.x - cam.x), (float) (p.y - cam.y), (float) (p.z - cam.z))
                    .color(col >> 16 & 255, col >> 8 & 255, col & 255, col >> 24 & 255);
            n++;
        }
        public static void line(Vec3d a, Vec3d b, int col) { v(a, col); v(b, col); }
        public static void box(Box b, int col) {
            Vec3d[] c = corners(b);
            for (int[] ed : EDGES) line(c[ed[0]], c[ed[1]], col);
        }
        public static void end() {
            if (bb == null || n == 0) { bb = null; return; }
            RenderSystem.disableDepthTest();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShader(GameRenderer::getPositionColorProgram);
            RenderSystem.lineWidth(1.5f);
            BufferRenderer.drawWithGlobalProgram(bb.end());
            RenderSystem.lineWidth(1.0f);
            RenderSystem.enableDepthTest();
            RenderSystem.disableBlend();
            bb = null; n = 0;
        }
    }
}
