package dev.burmalda.ui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;

/** Custom main menu (singleplayer only) with particles that burst on click. */
public class BurmaldaTitle extends Screen {
    private final Particles2D ps = new Particles2D();
    private long last;
    private static final String[] LABELS = {"Одиночная игра", "Настройки", "Выход"};

    public BurmaldaTitle() { super(Text.literal("Burmalda")); }

    @Override public boolean shouldCloseOnEsc() { return false; }

    private int bx() { return width / 2 - 100; }
    private int by(int i) { return height / 2 - 6 + i * 32; }

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        long now = System.nanoTime();
        float dt = last == 0 ? 0.016f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        c.fillGradient(0, 0, width, height, 0xFF150C26, 0xFF4A3478);
        ps.ambient(width, height); ps.update(dt); ps.render(c);
        c.getMatrices().push();
        c.getMatrices().translate(width / 2f, height / 2f - 64, 0);
        c.getMatrices().scale(3f, 3f, 1f);
        Gfx.btext(c, "Burmalda", -Gfx.bw("Burmalda") / 2f, 0, 0xFFFFFFFF);
        c.getMatrices().pop();
        String v = "1.2 release  |  только одиночная игра";
        Gfx.text(c, v, width / 2f - Gfx.w(v) / 2f, height / 2f - 34, 0xFFB8A8DC);
        for (int i = 0; i < 3; i++) {
            int x = bx(), y = by(i);
            boolean hov = mx >= x && mx < x + 200 && my >= y && my < y + 26;
            Gfx.rrect(c, x - 1, y - 1, 202, 28, 10, 0x40000000);
            Gfx.rrect(c, x, y, 200, 26, 9, hov ? Gfx.alpha(Gfx.accent(i), 150) : 0xD00E0B16);
            Gfx.btext(c, LABELS[i], x + 100 - Gfx.bw(LABELS[i]) / 2f, y + 8, 0xFFFFFFFF);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        ps.burst((float) mx, (float) my, 18);
        for (int i = 0; i < 3; i++) {
            if (mx >= bx() && mx < bx() + 200 && my >= by(i) && my < by(i) + 26) {
                if (i == 0) client.setScreen(new SelectWorldScreen(this));
                else if (i == 1) client.setScreen(new OptionsScreen(this, client.options));
                else client.scheduleStop();
                return true;
            }
        }
        return true;
    }
}
