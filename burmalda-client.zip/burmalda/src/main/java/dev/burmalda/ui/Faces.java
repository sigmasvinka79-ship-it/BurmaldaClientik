package dev.burmalda.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

/** Mob "face" icons cut from vanilla entity textures. */
public final class Faces {
    private Faces() {}
    private record F(String tex, int u, int v, int w, int h, int tw, int th) {}
    private static final Map<String, F> M = new HashMap<>();
    private static void a(String id, String tex, int u, int v, int w, int h, int tw, int th) { M.put(id, new F(tex, u, v, w, h, tw, th)); }
    static {
        a("creeper", "entity/creeper/creeper", 8, 8, 8, 8, 64, 32);
        a("zombie", "entity/zombie/zombie", 8, 8, 8, 8, 64, 64);
        a("husk", "entity/zombie/husk", 8, 8, 8, 8, 64, 64);
        a("drowned", "entity/zombie/drowned", 8, 8, 8, 8, 64, 64);
        a("skeleton", "entity/skeleton/skeleton", 8, 8, 8, 8, 64, 32);
        a("stray", "entity/skeleton/stray", 8, 8, 8, 8, 64, 32);
        a("wither_skeleton", "entity/skeleton/wither_skeleton", 8, 8, 8, 8, 64, 32);
        a("enderman", "entity/enderman/enderman", 8, 8, 8, 8, 64, 32);
        a("spider", "entity/spider/spider", 40, 12, 8, 8, 64, 32);
        a("cave_spider", "entity/spider/cave_spider", 40, 12, 8, 8, 64, 32);
        a("slime", "entity/slime/slime", 8, 8, 8, 8, 64, 32);
        a("magma_cube", "entity/slime/magmacube", 8, 8, 8, 8, 64, 32);
        a("blaze", "entity/blaze", 8, 8, 8, 8, 64, 32);
        a("ghast", "entity/ghast/ghast", 16, 16, 16, 16, 64, 32);
        a("pig", "entity/pig/pig", 8, 8, 8, 8, 64, 32);
        a("cow", "entity/cow/cow", 6, 6, 8, 8, 64, 32);
        a("sheep", "entity/sheep/sheep", 8, 8, 6, 6, 64, 32);
        a("chicken", "entity/chicken", 3, 3, 4, 6, 64, 32);
        a("wolf", "entity/wolf/wolf", 4, 4, 6, 6, 64, 32);
        a("villager", "entity/villager/villager", 8, 8, 8, 10, 64, 64);
        a("pillager", "entity/illager/pillager", 8, 8, 8, 10, 64, 64);
        a("vindicator", "entity/illager/vindicator", 8, 8, 8, 10, 64, 64);
        a("evoker", "entity/illager/evoker", 8, 8, 8, 10, 64, 64);
        a("witch", "entity/witch", 8, 8, 8, 10, 64, 128);
        a("iron_golem", "entity/iron_golem/iron_golem", 8, 8, 8, 10, 128, 128);
        a("zombified_piglin", "entity/piglin/zombified_piglin", 8, 8, 10, 8, 64, 64);
        a("piglin", "entity/piglin/piglin", 8, 8, 10, 8, 64, 64);
        a("phantom", "entity/phantom", 5, 5, 7, 3, 64, 64);
        a("guardian", "entity/guardian", 16, 16, 12, 12, 64, 64);
    }

    public static void draw(DrawContext c, LivingEntity e, int x, int y, int size) {
        Gfx.rrect(c, x, y, size, size, 5, 0xFF1A1A22);
        int in = 3, s = size - in * 2;
        try {
            if (e instanceof AbstractClientPlayerEntity pl) {
                Identifier skin = pl.getSkinTextures().texture();
                c.drawTexture(skin, x + in, y + in, s, s, 8f, 8f, 8, 8, 64, 64);
                c.drawTexture(skin, x + in, y + in, s, s, 40f, 8f, 8, 8, 64, 64);
                return;
            }
            F f = M.get(Registries.ENTITY_TYPE.getId(e.getType()).getPath());
            if (f != null) {
                int w = s, h = s;
                if (f.w() > f.h()) h = s * f.h() / f.w(); else if (f.h() > f.w()) w = s * f.w() / f.h();
                c.drawTexture(Identifier.of("minecraft", "textures/" + f.tex() + ".png"), x + in + (s - w) / 2, y + in + (s - h) / 2, w, h,
                        (float) f.u(), (float) f.v(), f.w(), f.h(), f.tw(), f.th());
                return;
            }
        } catch (Throwable ignored) {}
        String l = e.getName().getString();
        l = l.isEmpty() ? "?" : l.substring(0, 1).toUpperCase();
        Gfx.btext(c, l, x + size / 2f - Gfx.bw(l) / 2f, y + size / 2f - 4, Gfx.accent(0));
    }
}
