package dev.burmalda.mixin;

import dev.burmalda.modules.render.Ambience;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Custom sky / cloud colour and stars (Ambience). All injections are optional: a missing target is skipped. */
@Mixin(ClientWorld.class)
public class ClientWorldMixin {
    @Inject(method = "getSkyColor", at = @At("HEAD"), cancellable = true, require = 0)
    private void burmalda$sky(Vec3d cameraPos, float tickDelta, CallbackInfoReturnable<Vec3d> cir) {
        Vec3d c = Ambience.sky();
        if (c != null) cir.setReturnValue(c);
    }
    @Inject(method = "getCloudsColor", at = @At("HEAD"), cancellable = true, require = 0)
    private void burmalda$clouds(float tickDelta, CallbackInfoReturnable<Vec3d> cir) {
        Vec3d c = Ambience.clouds();
        if (c != null) cir.setReturnValue(c);
    }
    @Inject(method = "getStarBrightness", at = @At("HEAD"), cancellable = true, require = 0)
    private void burmalda$stars(float tickDelta, CallbackInfoReturnable<Float> cir) {
        float s = Ambience.stars();
        if (s >= 0) cir.setReturnValue(s);
    }
}
