package dev.burmalda;

import dev.burmalda.core.Commands;
import dev.burmalda.core.Config;
import dev.burmalda.core.ModuleManager;
import dev.burmalda.modules.combat.Criticals;
import dev.burmalda.ui.BurmaldaTitle;
import dev.burmalda.ui.ClickGui;
import dev.burmalda.ui.LoadingFx;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

public class BurmaldaClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        KeyBinding open = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("Open Burmalda menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "Burmalda Client"));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.currentScreen instanceof TitleScreen) mc.setScreen(new BurmaldaTitle());
            ModuleManager.tick();
            while (open.wasPressed()) if (mc.world != null && mc.isInSingleplayer()) mc.setScreen(new ClickGui());
        });
        HudRenderCallback.EVENT.register((ctx, tc) -> ModuleManager.render2d(ctx));
        WorldRenderEvents.AFTER_ENTITIES.register(ModuleManager::render3d);
        ClientSendMessageEvents.ALLOW_CHAT.register(msg -> !Commands.handle(msg));
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) ->
                ScreenEvents.afterRender(screen).register((s, ctx, mx, my, td) -> { if (LoadingFx.applies(s)) LoadingFx.render(ctx, s.width, s.height); }));
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            Criticals c = ModuleManager.get(Criticals.class);
            if (c != null && c.enabled && world.isClient) c.pre(player);
            return ActionResult.PASS;
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> Config.save());
    }
}
