package dev.burmalda;

import dev.burmalda.core.ModuleManager;
import dev.burmalda.ui.ClickGui;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class BurmaldaClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        KeyBinding open = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("Open Burmalda menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "Burmalda Client"));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            ModuleManager.tick();
            while (open.wasPressed()) if (mc.world != null && mc.isInSingleplayer()) mc.setScreen(new ClickGui());
        });
        HudRenderCallback.EVENT.register((ctx, tc) -> ModuleManager.render2d(ctx));
        WorldRenderEvents.AFTER_ENTITIES.register(ModuleManager::render3d);
    }
}
