# Burmalda Client 1.1 (Fabric 1.21.1, singleplayer only)

## Build via GitHub
Upload this zip (or the folder) to a repo; Actions builds the jar -> Artifacts -> `burmalda-client`.
Needs Fabric Loader 0.16.10+, Fabric API 0.102.0+1.21.1, Java 21.

## Controls
Right Shift - menu (scroll = move panels). LMB toggle, RMB settings, MMB bind a key (Esc/Del clears).
Settings, binds and HUD/visual toggles are saved to `.minecraft/config/burmalda.properties`.

## Modules
Combat: KillAura, AutoSwap (mace aware), AutoTotem, AutoShoot (bow/trident prediction)
Render: HUD, TargetHUD, TargetESP, Trails, OreESP, ESP, CombatFX, JumpCircles, PathESP, Fullbright, Zoom, Interface (themes)
Player: AutoEat, AutoFish, AutoLoot, AutoStore, AutoTool, Safety, AutoEnchant, AutoRepair
World: AutoMine, Tunnel, StructureFinder, Home
Farm: MobFarm, AutoFarm, AutoBreed

## Singleplayer only
`core/Guard.java` disables everything and disconnects if the world is not a local integrated server.
