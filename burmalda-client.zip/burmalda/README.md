# Burmalda Client 1.2 beta (Fabric 1.21.1, singleplayer only)

Build: upload the zip to GitHub, Actions builds the jar (Artifacts -> burmalda-client).
Needs Fabric Loader 0.16.10+, Fabric API 0.102.0+1.21.1, Java 21.

Menu: Right Shift. Chat commands (prefix "."): .help, .bind add <module> <key>, .bind remove <module>, .bind list,
.bind clear, .toggle <module>, .panic, .build list|load <file>|start|stop.
Schematics (vanilla structure .nbt) go to .minecraft/burmalda/schematics.
Settings are saved to .minecraft/config/burmalda.properties.

Singleplayer only: core/Guard.java disables everything and disconnects on non-local worlds.
