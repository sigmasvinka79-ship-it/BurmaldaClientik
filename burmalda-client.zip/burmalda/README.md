# Burmalda Client (Fabric 1.21.1, singleplayer only)

## Build via GitHub
1. Create a repo and push this folder.
2. Open **Actions → build → Run workflow** (or just push). The jar appears under *Artifacts* as `burmalda-client`.
3. Put the jar + Fabric API 0.102.0+1.21.1 into `.minecraft/mods` (Fabric Loader 0.16.10+, Java 21).

## Font
Drop any TTF (Inter, Montserrat, ...) as `src/main/resources/assets/burmalda/font/inter.ttf`.
Without it the vanilla font is used.

## Controls
Right Shift - menu. LMB toggle module, RMB open settings, MMB bind a key (Esc/Del clears).

## Singleplayer only
`core/Guard.java`: modules refuse to run, and the client disconnects, whenever the world is not a local integrated server (LAN-published worlds included).
