# Burmalda Client 1.2 release (Fabric 1.21.1, singleplayer only)

Build: upload the zip to GitHub, Actions builds the jar (Artifacts -> burmalda-client).
Needs Fabric Loader 0.16.10+, Fabric API 0.102.0+1.21.1, Java 21.

Menu: Right Shift (drag HUD blocks with the mouse while it is open, Ctrl+F = search).
Chat commands: .help, .bind add|remove|list|clear, .toggle, .panic, .friend, .config save|load <name>, .hud reset, .build ...
Schematics (vanilla structure .nbt): .minecraft/burmalda/schematics

## Performance (recommended mods, all Fabric 1.21.1)
Sodium, Lithium, FerriteCore, ImmediatelyFast, Entity Culling, ModernFix. They give the big FPS gains without hurting quality.
The built-in Performance module only fine-tunes particles / entity distance adaptively.
Suggested JVM args (launcher): -Xms2G -Xmx4G -XX:+UseG1GC -XX:MaxGCPauseMillis=50 -XX:+UseStringDeduplication

Singleplayer only: core/Guard.java disables everything and disconnects on non-local worlds.
